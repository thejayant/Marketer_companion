// popup.js — stable init + visual render; now mirrors signed-in email in sidebar credits.

const $ = id => document.getElementById(id);
const qsa = sel => Array.from(document.querySelectorAll(sel));
// safe binder
const on = (id, evt, fn) => {
  const el = $(id);
  if (el) el.addEventListener(evt, fn);
};


function surfaceError(e){
  console.error(e);
  clearResult(`❌ ${e?.message || e}`);
}
function safe(fn){ try { return fn(); } catch(e){ surfaceError(e); } }


const SIDEBAR_STATE_KEY = 'mc_sidebar_collapsed';
function isCompactPopup(){
  const root = document.documentElement;
  if (!root || root.dataset.mode !== 'popup') return false;
  const width = window.innerWidth || root.clientWidth || 0;
  const height = window.innerHeight || root.clientHeight || 0;
  return width <= 800 && height <= 600;
}
function shouldPersistSidebarState(){
  return !isCompactPopup();
}
function setSidebarCollapsed(collapsed, persist=true){
  const shell = document.querySelector('.shell');
  if(!shell) return;
  shell.classList.toggle('sidebar-collapsed', !!collapsed);
  if(persist && chrome?.storage?.local){ chrome.storage.local.set({[SIDEBAR_STATE_KEY]: !!collapsed}); }
}
async function initSidebarUX(){
  if (isCompactPopup()) {
    setSidebarCollapsed(true, false);
  } else {
    try{
      const v = await chrome.storage.local.get(SIDEBAR_STATE_KEY);
      setSidebarCollapsed(!!v[SIDEBAR_STATE_KEY], false);
    }catch(e){ /* ignore */ }
  }
  on('collapseSidebar','click', ()=> {
    const shell = document.querySelector('.shell');
    setSidebarCollapsed(!shell?.classList.contains('sidebar-collapsed'), shouldPersistSidebarState());
  });
  on('sidebarFab','click', ()=>setSidebarCollapsed(false, shouldPersistSidebarState()));
}

const state = {
  sites: [],
  perf: { range:'30', wholeProperty:false, cache:null },
  callrail: { inited:false, last:null },
  ui: {
    siteFilter:'',
    sitesCache:null,
    panelLoads: {
      tags: false,
      onPage: false,
      structuredData: false
    }
  }
};

function formatRelativeTime(ts){
  const value = Number(ts || 0);
  if (!value) return '';
  const diff = Math.max(0, Date.now() - value);
  if (diff < 45000) return 'just now';
  const minutes = Math.round(diff / 60000);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.round(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.round(hours / 24);
  return `${days}d ago`;
}
function buildCacheText(cache, labels={}){
  if (!cache) return '';
  const when = formatRelativeTime(cache.fetchedAt);
  const suffix = when ? ` ${when}` : '';
  if (cache.stale) return `${labels.stale || 'Refresh failed. Showing cached data'}${suffix}.`;
  if (cache.source === 'cache') return `${labels.cached || 'Using cached data'}${suffix}.`;
  if (cache.source === 'mixed') return `${labels.mixed || 'Using a mix of fresh and cached data'}${suffix}.`;
  return `${labels.network || 'Updated'}${suffix}.`;
}
function setCacheNote(id, cache, labels={}){
  const el = $(id);
  if (!el) return;
  const text = buildCacheText(cache, labels);
  el.textContent = text;
  el.classList.toggle('hidden', !text);
  el.classList.toggle('is-stale', !!cache?.stale);
}
function combineCacheMeta(items){
  const list = (items || []).filter(Boolean);
  if (!list.length) return null;
  const source = list.every(item => item.source === 'network')
    ? 'network'
    : list.every(item => item.source === 'cache')
      ? 'cache'
      : 'mixed';
  const fetchedAt = list.reduce((max, item) => Math.max(max, Number(item?.fetchedAt || 0)), 0);
  return {
    source,
    fetchedAt,
    stale: list.some(item => item.stale)
  };
}

function kv(k,v){ return `<div class="row kv"><div class="k">${k}</div><div>${v}</div></div>`; }
function badge(s, cls=''){ return `<span class="badge ${cls}">${s}</span>`; }
function stateBadge(s){
  const t = String(s||'').toLowerCase();
  if(/(valid|passed|ok|good|on google|submitted|success|100|90|allowed)/.test(t)) return badge(s,'good');
  if(/(warning|partial|unknown|needs|medium)/.test(t)) return badge(s,'ok');
  if(/(error|fail|not on google|blocked|denied|slow|poor|noindex)/.test(t)) return badge(s,'bad');
  return badge(s);
}
function escapeHtml(s){
  return String(s).replace(/[&<>"']/g, m => (
    { '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[m]
  ));
}
function formatDurationShort(seconds){
  const total = Math.max(0, Math.round(Number(seconds || 0)));
  if (!total) return '0s';
  const hours = Math.floor(total / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  const secs = total % 60;
  if (hours) return `${hours}h ${minutes}m`;
  if (minutes) return `${minutes}m ${secs}s`;
  return `${secs}s`;
}
function formatMetricValue(value, type='number', digits=0){
  const num = Number(value || 0);
  if (!Number.isFinite(num)) return '0';
  if (type === 'percent') return `${(num * 100).toFixed(digits)}%`;
  if (type === 'decimal') return num.toFixed(digits);
  if (type === 'duration') return formatDurationShort(num);
  if (digits > 0) {
    return num.toLocaleString(undefined, {
      minimumFractionDigits: digits,
      maximumFractionDigits: digits
    });
  }
  return num.toLocaleString();
}
function metricDelta(curr, prev, { inverse=false, digits=1 } = {}){
  const currentValue = Number(curr);
  const prevValue = Number(prev);
  if (!Number.isFinite(currentValue) || !Number.isFinite(prevValue) || prevValue === 0) {
    return { text:'—', cls:'' };
  }
  const delta = ((currentValue - prevValue) / prevValue) * 100;
  const isPositive = delta >= 0;
  const cls = delta === 0 ? '' : ((inverse ? !isPositive : isPositive) ? 'up' : 'down');
  return {
    text: `${delta > 0 ? '+' : ''}${delta.toFixed(digits)}%`,
    cls
  };
}
function buildTrendSVG(values, { width=220, height=44, padding=2 } = {}){
  const nums = (values || []).map(value => Number(value || 0)).filter(value => Number.isFinite(value));
  if (!nums.length) return '';
  const min = Math.min(...nums);
  const max = Math.max(...nums);
  const sx = index => padding + (index * (width - padding * 2) / Math.max(1, nums.length - 1));
  const sy = value => max === min
    ? height / 2
    : padding + (height - padding * 2) * (1 - (value - min) / (max - min));
  let linePath = '';
  nums.forEach((value, index) => {
    linePath += `${index ? ' L' : 'M'}${sx(index).toFixed(1)} ${sy(value).toFixed(1)}`;
  });
  const lastX = sx(nums.length - 1).toFixed(1);
  const areaPath = `${linePath} L${lastX} ${(height - padding).toFixed(1)} L${sx(0).toFixed(1)} ${(height - padding).toFixed(1)} Z`;
  return `
    <svg class="insight-spark" viewBox="0 0 ${width} ${height}" preserveAspectRatio="none" aria-hidden="true">
      <path d="${areaPath}" fill="rgba(57,224,122,.08)"></path>
      <path d="${linePath}" fill="none" stroke="rgba(57,224,122,.95)" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"></path>
    </svg>
  `;
}
function buildInsightTableSection(section){
  if (!section || !Array.isArray(section.columns) || !section.columns.length || !Array.isArray(section.rows) || !section.rows.length) {
    return '';
  }
  const head = section.columns.map(column => `<th class="${column.numeric ? 'num' : ''}">${escapeHtml(column.label)}</th>`).join('');
  const body = section.rows.map(row => `
    <tr>
      ${section.columns.map((column, index) => {
        const value = row[index] == null || row[index] === '' ? '—' : row[index];
        return `<td class="${column.numeric ? 'num' : ''}">${escapeHtml(value)}</td>`;
      }).join('')}
    </tr>
  `).join('');
  return `
    <section class="insight-block">
      <h4>${escapeHtml(section.title)}</h4>
      <div class="insight-table-shell">
        <table class="insight-table">
          <thead><tr>${head}</tr></thead>
          <tbody>${body}</tbody>
        </table>
      </div>
    </section>
  `;
}
function buildInsightBarSection(section){
  if (!section || !Array.isArray(section.items) || !section.items.length) return '';
  const max = Math.max(1, ...section.items.map(item => Number(item?.value || 0)));
  return `
    <section class="insight-block">
      <h4>${escapeHtml(section.title)}</h4>
      <div class="insight-bars">
        ${section.items.map(item => {
          const value = Number(item?.value || 0);
          const width = Math.max(2, Math.round((value / max) * 100));
          return `
            <div class="insight-bar-row">
              <span class="insight-bar-label">${escapeHtml(item.label || '—')}</span>
              <div class="insight-bar-track">
                <span class="insight-bar-fill" style="width:${width}%"></span>
              </div>
              <strong class="insight-bar-value">${escapeHtml(item.displayValue || formatMetricValue(value))}</strong>
            </div>
          `;
        }).join('')}
      </div>
    </section>
  `;
}
function buildInsightStage({ eyebrow='', title='', rangeLabel='', subtitle='', badges=[], kpis=[], sparklineValues=[], sparklineLabel='', tableSections=[], barSections=[] }){
  const titleMarkup = rangeLabel
    ? `${escapeHtml(title)} <span class="insight-range">(${escapeHtml(rangeLabel)})</span>`
    : escapeHtml(title);
  return `
    <div class="result-stage insight-stage">
      <div class="result-stage__head">
        <div>
          ${eyebrow ? `<span class="eyebrow">${escapeHtml(eyebrow)}</span>` : ''}
          <h3 class="insight-title">${titleMarkup}</h3>
          ${subtitle ? `<p>${escapeHtml(subtitle)}</p>` : ''}
        </div>
        ${badges.length ? `
          <div class="meta-line insight-meta">
            ${badges.map(text => badge(escapeHtml(text))).join('')}
          </div>
        ` : ''}
      </div>
      ${kpis.length ? `
        <div class="insight-kpi-grid">
          ${kpis.map(item => {
            const delta = item.delta || { text:'—', cls:'' };
            return `
              <article class="insight-kpi">
                <span class="insight-kpi__label">${escapeHtml(item.label)}</span>
                <div class="insight-kpi__value">
                  <strong>${escapeHtml(item.value)}</strong>
                  <span class="insight-kpi__delta ${escapeHtml(delta.cls || '')}">${escapeHtml(delta.text || '—')}</span>
                </div>
              </article>
            `;
          }).join('')}
        </div>
      ` : ''}
      ${sparklineValues.length ? `
        <div class="insight-spark-wrap">
          ${buildTrendSVG(sparklineValues)}
          ${sparklineLabel ? `<span class="insight-spark-label">${escapeHtml(sparklineLabel)}</span>` : ''}
        </div>
      ` : ''}
      ${tableSections.map(buildInsightTableSection).join('')}
      ${barSections.map(buildInsightBarSection).join('')}
    </div>
  `;
}
const MAIN_EMPTY_STATE = `
  <div class="empty-state">
    <span class="empty-state__icon">↗</span>
    <div>
      <strong>Pick a workflow and run a check.</strong>
      <p>Indexing, Tag Assistant, performance, and on-page audits render here after each action.</p>
    </div>
  </div>
`;
const PANEL_STATE = {
  navIndex: {
    showSCContext: true
  },
  navTags: {
    showSCContext: false
  },
  navAnalytics: {
    showSCContext: false
  },
  navPerf: {
    showSCContext: true
  },
  navCallRail: {
    showSCContext: false
  },
  navOnPage: {
    showSCContext: false
  },
  navStructuredData: {
    showSCContext: false
  },
  navSettings: {
    showSCContext: false
  }
};
const RESULT_TARGETS = {
  navIndex: 'indexResult',
  navTags: 'tagResult',
  navPerf: 'perfResult',
  navOnPage: 'onPageResult',
  navStructuredData: 'structuredDataResult',
  navAnalytics: 'gaResult',
  navCallRail: 'crResult'
};
function animateIn(el){
  if (!el) return;
  el.classList.remove('is-entering');
  void el.offsetWidth;
  el.classList.add('is-entering');
}
function inferStatusTone(msg=''){
  const text = String(msg).toLowerCase();
  if (/(❌|error|failed|denied|invalid|could not|not available)/.test(text)) return 'error';
  if (/(⚠️|warning|pick|select|enter|sign in|no data)/.test(text)) return 'warn';
  return 'info';
}
function statusCard(msg){
  const tone = inferStatusTone(msg);
  const icon = tone === 'error' ? '!' : tone === 'warn' ? '•' : 'i';
  return `
    <div class="status-card ${tone}">
      <span class="status-card__icon">${icon}</span>
      <div>
        <strong>${tone === 'error' ? 'Something needs attention' : tone === 'warn' ? 'Action needed' : 'Status update'}</strong>
        <p>${escapeHtml(msg)}</p>
      </div>
    </div>
  `;
}
function renderHtml(targetId, html){
  const resolvedId = targetId === 'result' ? (RESULT_TARGETS[document.querySelector('.nav button.active')?.id || 'navPerf'] || 'perfResult') : targetId;
  const el = $(resolvedId);
  if (!el) return;
  el.innerHTML = html;
  animateIn(el);
}
function setPropertyMatch(title, message){
  const el = $('propertyMatch');
  if (!el) return;
  el.innerHTML = `<strong>${escapeHtml(title)}</strong>${escapeHtml(message)}`;
}
function setPanelContext(navId){
  const copy = PANEL_STATE[navId] || PANEL_STATE.navPerf;
  $('scContext')?.classList.toggle('hidden', !copy.showSCContext);
}
function clearResult(msg, targetId){
  const resolvedId = targetId || RESULT_TARGETS[document.querySelector('.nav button.active')?.id || 'navPerf'] || 'perfResult';
  const el = $(resolvedId); if (!el) return;
  if (!msg) {
    el.innerHTML = '';
  } else {
    el.innerHTML = statusCard(msg);
  }
  animateIn(el);
}

/* ---------- URL & property helpers ---------- */
function normalizeUrl(raw){
  if (!raw) return null;
  let u = String(raw).trim();
  if (!/^https?:\/\//i.test(u)) u = 'https://' + u;
  try {
    const p = new URL(u);
    if (!/^https?:$/.test(p.protocol)) return null;
    p.hash=''; p.username=''; p.password='';
    const host = p.hostname;
    if (host === 'localhost' || host.endsWith('.local') ||
        /^127\./.test(host) || /^10\./.test(host) ||
        /^192\.168\./.test(host) || /^172\.(1[6-9]|2\d|3[0-1])\./.test(host)) return null;
    return p.toString();
  } catch { return null; }
}
function propertyCoversUrl(siteUrl, url){
  try{
    if(siteUrl.startsWith('sc-domain:')){
      const domain = siteUrl.split(':')[1];
      const u = new URL(url);
      return u.hostname === domain || u.hostname.endsWith('.'+domain);
    }
    return url.startsWith(siteUrl);
  }catch{ return false; }
}
function setSites(sites){
  state.sites = sites || [];
  const sel = $('sites'); if(!sel) return;
  sel.innerHTML = '';
  for(const s of state.sites){
    const opt = document.createElement('option');
    opt.value = s.siteUrl;
    opt.textContent = s.siteUrl + (s.permissionLevel ? `  (${s.permissionLevel})` : '');
    sel.appendChild(opt);
  }
  syncSitePickerLabel();
  renderSitePicker();
  autoSelectPropertyForUrl();
}
function syncSitePickerLabel(){
  const label = $('sitePickerLabel');
  const sel = $('sites');
  if (!label || !sel) return;
  label.textContent = sel.options.length ? (sel.selectedOptions?.[0]?.textContent || 'Select property') : 'No properties';
}
function renderSitePicker(filterText=''){
  const list = $('sitePickerList');
  const sel = $('sites');
  if (!list || !sel) return;
  const current = sel.value || '';
  const needle = String(filterText || state.ui.siteFilter || '').trim().toLowerCase();
  const items = state.sites.filter(site => {
    if (!needle) return true;
    const hay = `${site.siteUrl} ${site.permissionLevel || ''}`.toLowerCase();
    return hay.includes(needle);
  });
  if (!items.length){
    list.innerHTML = `<div class="picker-empty">No matches.</div>`;
    return;
  }
  list.innerHTML = items.map(site => {
    const active = site.siteUrl === current ? ' active' : '';
    return `
      <button class="picker-option${active}" type="button" data-site-value="${escapeHtml(site.siteUrl)}">
        <span>${escapeHtml(site.siteUrl)}</span>
        <small>${escapeHtml(site.permissionLevel || 'Unknown')}</small>
      </button>
    `;
  }).join('');
  qsa('.picker-option').forEach(btn => {
    btn.addEventListener('click', ()=>{
      const value = btn.dataset.siteValue || '';
      setSelectedSite(value, 'manual');
      closeSitePicker();
    });
  });
}
function openSitePicker(){
  $('sitePickerMenu')?.classList.remove('hidden');
  $('sitePickerToggle')?.setAttribute('aria-expanded', 'true');
  const search = $('sitePickerSearch');
  if (search){
    search.value = state.ui.siteFilter || '';
    search.focus();
    search.select();
  }
}
function closeSitePicker(){
  $('sitePickerMenu')?.classList.add('hidden');
  $('sitePickerToggle')?.setAttribute('aria-expanded', 'false');
}
function setSelectedSite(siteUrl, mode='manual'){
  const sel = $('sites');
  if (!sel || !siteUrl) return;
  sel.value = siteUrl;
  syncSitePickerLabel();
  renderSitePicker(state.ui.siteFilter || '');
  updatePropertyMeta(mode, mode === 'auto' ? siteUrl : '');
  setEnabled();
}
function getPermissionFor(siteUrl){
  const entry = (state.sites || []).find(s => s.siteUrl === siteUrl);
  return entry?.permissionLevel || '';
}
function isOwner(siteUrl){ return /owner/i.test(getPermissionFor(siteUrl)); }
function updatePropertyMeta(mode='auto', matchedSite=''){
  const current = matchedSite || $('sites')?.value || '';
  const permission = getPermissionFor(current) || '—';
  const badge = $('propertyPermission');
  if (badge) badge.textContent = `Permission: ${permission}`;

  const url = normalizeUrl($('inspectUrl')?.value || '');
  if (!url){
    setPropertyMatch('Match', 'Enter a URL.');
  } else if (matchedSite){
    setPropertyMatch('Matched', matchedSite);
  } else if (mode === 'auto'){
    setPropertyMatch('No match', 'Pick a property.');
  } else if (mode === 'manual' && current){
    setPropertyMatch('Manual', current);
  } else {
    setPropertyMatch('No match', 'Pick a property.');
  }
}
function autoSelectPropertyForUrl(){
  const sel = $('sites');
  if (!sel) return;
  const url = normalizeUrl($('inspectUrl')?.value || '');
  let matched = '';
  if (url){
    matched = chooseBestProperty(state.sites, url) || '';
    if (matched) setSelectedSite(matched, 'auto');
  }
  if (!matched) {
    syncSitePickerLabel();
    renderSitePicker(state.ui.siteFilter || '');
    updatePropertyMeta('auto', '');
  }
  setEnabled();
}
function setEnabled(){
  const sitesSel = $('sites'); const urlInp = $('inspectUrl');
  if (!sitesSel || !urlInp) return;
  const siteUrl = sitesSel.value || '';
  const url = normalizeUrl(urlInp.value || '');
  const covers = siteUrl && url && propertyCoversUrl(siteUrl, url);
  const owner = isOwner(siteUrl);
  const setDis = (id, on) => { const el = $(id); if (el) el.disabled = on; };
  setDis('inspect', !covers);
  const whole = state.perf.wholeProperty;
  setDis('loadPerf', !(siteUrl && (whole ? true : covers)));
  setDis('runOnPage', false);
  setDis('runTags', false);
  const indexingAllowed = covers && owner;
  setDis('notifyUpdate', !indexingAllowed);
  setDis('notifyRemove', !indexingAllowed);
  setDis('checkStatus', !indexingAllowed);
}

async function loadSites({ forceRefresh=false } = {}){
  const response = await send({ type:'listSites', forceRefresh: !!forceRefresh }).catch(e => ({ ok:false, error:String(e)}));
  if (!response.ok) throw new Error(response.error || 'Failed to load properties');
  state.ui.sitesCache = response.cache || null;
  setSites(response.data || []);
  setCacheNote('sitesCacheStatus', state.ui.sitesCache, {
    network: 'Properties refreshed',
    cached: 'Cached properties',
    mixed: 'Mixed property cache',
    stale: 'Stale property cache'
  });
  return response.data || [];
}
async function perfFetchReport(payload){
  const response = await send(Object.assign({ type:'perf' }, payload));
  if (!response.ok) throw new Error(response.error || 'Search Console error');
  return {
    data: response.data || {},
    cache: response.cache || null
  };
}
async function loadPerfReport({ forceRefresh=false } = {}){
  const siteUrl = $('sites')?.value?.trim();
  const whole = state.perf.wholeProperty;
  if(!siteUrl) return clearResult('Pick a property.');
  const url = normalizeUrl($('inspectUrl')?.value?.trim() || '');
  if(!whole){
    if(!url) return clearResult('Enter a valid URL.');
    if(!propertyCoversUrl(siteUrl, url)) return clearResult(`Property doesn't cover this URL.`);
  }
  let startDate, endDate;
  const today = new Date();
  const clampTo = new Date(today.getFullYear(), today.getMonth(), today.getDate() - 2);
  const clampISO = (d)=> `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;

  if(state.perf.range === 'custom'){
    startDate = $('dateStart')?.value || '';
    endDate = $('dateEnd')?.value || clampISO(clampTo);
    if(!startDate) return clearResult('Pick a start date.');
    if(startDate > endDate) return clearResult('Start must be before end.');
    if (endDate > clampISO(clampTo)) endDate = clampISO(clampTo);
  } else {
    const days = Number(state.perf.range || 30);
    endDate = clampISO(clampTo);
    startDate = toISO(days + 2);
  }
  clearResult(forceRefresh ? 'Refreshing…' : 'Loading…');
  const prevRange = gaPreviousRange(startDate, endDate);
  const basePayload = {
    siteUrl,
    url: whole ? null : url,
    pageOnly: !whole,
    forceRefresh: !!forceRefresh
  };
  const breakdownDim = whole ? 'page' : 'query';

  try{
    const [summaryResult, trendResult, breakdownResult, prevSummaryResult] = await Promise.allSettled([
      perfFetchReport(Object.assign({}, basePayload, {
        startDate,
        endDate
      })),
      perfFetchReport(Object.assign({}, basePayload, {
        startDate,
        endDate,
        dimensions: ['date'],
        rowLimit: 1000
      })),
      perfFetchReport(Object.assign({}, basePayload, {
        startDate,
        endDate,
        dimensions: [breakdownDim],
        rowLimit: 8
      })),
      perfFetchReport(Object.assign({}, basePayload, {
        startDate: prevRange.start,
        endDate: prevRange.end
      }))
    ]);

    if (summaryResult.status !== 'fulfilled') throw summaryResult.reason;

    const trend = trendResult.status === 'fulfilled' ? trendResult.value : { data:{ rows:[] }, cache:null };
    const breakdown = breakdownResult.status === 'fulfilled' ? breakdownResult.value : { data:{ rows:[] }, cache:null };
    const prevSummary = prevSummaryResult.status === 'fulfilled' ? prevSummaryResult.value : null;

    state.perf.cache = combineCacheMeta([
      summaryResult.value.cache,
      trend.cache,
      breakdown.cache,
      prevSummary?.cache || null
    ]);

    renderPerf({
      summary: summaryResult.value.data,
      trend: trend.data,
      breakdown: breakdown.data
    }, {
      start: startDate,
      end: endDate,
      wholeProperty: whole,
      breakdownDim
    }, prevSummary?.data || null);

    setCacheNote('perfCacheStatus', state.perf.cache, {
      network: 'Performance refreshed',
      cached: 'Cached performance',
      mixed: 'Mixed performance cache',
      stale: 'Stale performance cache'
    });
  }catch(e){
    clearResult('❌ ' + (e?.message || e));
  }
}
// ===== Google Analytics (GA4) =====
const GA_STORAGE_KEYS = {
  selections: 'gaKeyEventSelections',
  mode: 'gaAnalyticsMode',
  breakdown: 'gaKeyEventBreakdown'
};
const GA_OVERVIEW_METRICS = ['activeUsers', 'sessions', 'screenPageViews', 'eventCount'];
const GA_KEY_EVENT_METRICS = ['keyEvents', 'eventCount', 'activeUsers', 'sessions'];
const GA_DEFAULT_BREAKDOWN = 'sessionDefaultChannelGroup';
const GA_DIM_LABELS = {
  date: "Date",
  eventName: "Event name",
  sessionDefaultChannelGroup: "Default Channel Group",
  country: "Country",
  deviceCategory: "Device category",
  pagePathPlusQueryString: "Page"
};
const GA_METRIC_LABELS = {
  activeUsers: "Active users",
  sessions: "Sessions",
  screenPageViews: "Views",
  eventCount: "Event count",
  keyEvents: "Key events"
};
const GA = {
  props: null,
  keyEventsByProperty: {},
  keyEventSelections: {},
  keyEventNotices: {},
  keyEventCacheByProperty: {},
  mode: 'overview',
  breakdown: GA_DEFAULT_BREAKDOWN,
  lastExport: null,
  propFilter: '',
  keyEventFilter: '',
  loadingPropertyId: '',
  propCacheMeta: null,
  reportCacheMeta: null,
  generalNotice: ''
};

async function gaGetStored(){
  return await new Promise(resolve => chrome.storage.local.get([
    GA_STORAGE_KEYS.selections,
    GA_STORAGE_KEYS.mode,
    GA_STORAGE_KEYS.breakdown
  ], resolve));
}
async function gaSetStored(obj){
  return await new Promise(resolve => chrome.storage.local.set(obj, resolve));
}
async function gaHydrateState(){
  const stored = await gaGetStored().catch(() => ({}));
  GA.keyEventSelections = stored?.[GA_STORAGE_KEYS.selections] && typeof stored[GA_STORAGE_KEYS.selections] === 'object'
    ? stored[GA_STORAGE_KEYS.selections]
    : {};
  GA.mode = stored?.[GA_STORAGE_KEYS.mode] === 'keyEvents' ? 'keyEvents' : 'overview';
  GA.breakdown = stored?.[GA_STORAGE_KEYS.breakdown] || GA_DEFAULT_BREAKDOWN;
  const breakdown = $('gaKeyBreakdown');
  if (breakdown) breakdown.value = GA.breakdown;
  gaSyncModeUi();
  gaResetExport();
}
function gaCurrentPropertyId(){
  return $('gaProps')?.value || '';
}
function isoDaysAgo(n){
  const d = new Date();
  d.setDate(d.getDate() - n);
  return d.toISOString().slice(0,10);
}
function ensureLaggedEnd(endIso){
  const t = todayISO();
  return endIso > t ? t : endIso;
}
function gaResolveDateRange(){
  let start, end;
  const rng = $('gaRange')?.value || '28';
  if (rng === 'custom'){
    start = $('gaStart')?.value || '';
    end = $('gaEnd')?.value || todayISO();
    if (!start) throw new Error('Pick a start date.');
    if (start > end) throw new Error('Start must be before end.');
  } else {
    const days = Number(rng);
    end = todayISO();
    start = isoDaysAgo(days);
  }
  return { start, end: ensureLaggedEnd(end) };
}
function gaPreviousRange(start, end){
  const msPerDay = 86400000;
  const s = new Date(start + "T00:00:00");
  const e = new Date(end + "T00:00:00");
  const spanDays = Math.max(1, Math.round((e - s)/msPerDay) + 1);
  const prevEnd = new Date(s.getTime() - msPerDay);
  const prevStart = new Date(prevEnd.getTime() - (spanDays - 1) * msPerDay);
  return {
    start: prevStart.toISOString().slice(0,10),
    end: prevEnd.toISOString().slice(0,10)
  };
}
function gaHasRows(report){
  return !!(report && Array.isArray(report.rows) && report.rows.length);
}
function gaMetricLabel(name){
  return GA_METRIC_LABELS[name] || name;
}
function gaSyncPropPickerLabel(){
  const label = $('gaPropLabel');
  const sel = $('gaProps');
  if (!label || !sel) return;
  label.textContent = sel.options.length ? (sel.selectedOptions?.[0]?.textContent || 'Select GA4 property') : 'No GA4 properties';
}
function gaRenderPropPicker(filterText=''){
  const list = $('gaPropList');
  const sel = $('gaProps');
  if (!list || !sel) return;
  if (!(GA.props || []).length){
    list.innerHTML = `<div class="picker-empty">No GA4 properties.</div>`;
    return;
  }
  const current = sel.value || '';
  const needle = String(filterText || GA.propFilter || '').trim().toLowerCase();
  const items = (GA.props || []).filter(prop => {
    if (!needle) return true;
    const hay = `${prop.account} ${prop.displayName} ${prop.id}`.toLowerCase();
    return hay.includes(needle);
  });
  if (!items.length){
    list.innerHTML = `<div class="picker-empty">No matches.</div>`;
    return;
  }
  list.innerHTML = items.map(prop => {
    const active = prop.id === current ? ' active' : '';
    return `
      <button class="picker-option ga-prop-option${active}" type="button" data-ga-prop-value="${escapeHtml(prop.id)}">
        <span>${escapeHtml(`${prop.account} • ${prop.displayName}`)}</span>
        <small>p:${escapeHtml(prop.id)}</small>
      </button>
    `;
  }).join('');
  qsa('#gaPropList [data-ga-prop-value]').forEach(btn => {
    btn.addEventListener('click', async ()=>{
      await gaSetSelectedProperty(btn.dataset.gaPropValue || '');
      gaClosePropPicker();
    });
  });
}
function gaOpenPropPicker(){
  $('gaPropMenu')?.classList.remove('hidden');
  $('gaPropToggle')?.setAttribute('aria-expanded', 'true');
  const search = $('gaPropSearch');
  if (search){
    search.value = GA.propFilter || '';
    search.focus();
    search.select();
  }
}
function gaClosePropPicker(){
  $('gaPropMenu')?.classList.add('hidden');
  $('gaPropToggle')?.setAttribute('aria-expanded', 'false');
}
async function gaSetSelectedProperty(propertyId){
  const sel = $('gaProps');
  if (!sel || !propertyId) return;
  sel.value = propertyId;
  gaSyncPropPickerLabel();
  gaRenderPropPicker(GA.propFilter || '');
  await gaHandlePropertyChange();
}

function gaSetPropertyNotice(propertyId, msg=''){
  if (!propertyId) return;
  if (msg) GA.keyEventNotices[propertyId] = msg;
  else delete GA.keyEventNotices[propertyId];
}
function gaSetGeneralNotice(msg=''){
  GA.generalNotice = msg || '';
}
function gaGetPropertyNotice(propertyId=gaCurrentPropertyId()){
  return propertyId ? (GA.keyEventNotices[propertyId] || '') : (GA.generalNotice || '');
}
function gaGetCurrentKeyEvents(propertyId=gaCurrentPropertyId()){
  return GA.keyEventsByProperty[propertyId] || [];
}
function gaGetSelectedKeyEvents(propertyId=gaCurrentPropertyId()){
  const raw = Array.isArray(GA.keyEventSelections[propertyId]) ? GA.keyEventSelections[propertyId] : [];
  const available = new Set(gaGetCurrentKeyEvents(propertyId).map(item => item.eventName));
  return raw.filter(name => available.has(name));
}
function gaCurrentSelectionLabel(propertyId=gaCurrentPropertyId()){
  if (!propertyId) return 'Pick a GA4 property';
  if (GA.loadingPropertyId === propertyId) return 'Loading…';
  const selected = gaGetSelectedKeyEvents(propertyId);
  if (!selected.length){
    return gaGetCurrentKeyEvents(propertyId).length ? 'Select events' : 'No events';
  }
  if (selected.length === 1) return selected[0];
  return `${selected.length} events selected`;
}
function gaRenderKeyEventNotice(){
  const el = $('gaKeyEventNotice');
  if (!el) return;
  const msg = gaGetPropertyNotice();
  el.textContent = msg;
  el.classList.toggle('hidden', !msg);
}
function gaRenderPropertyCacheNote(){
  setCacheNote('gaPropCacheStatus', GA.propCacheMeta, {
    network: 'Properties refreshed',
    cached: 'Cached properties',
    mixed: 'Mixed property cache',
    stale: 'Stale property cache'
  });
}
function gaRenderKeyEventCacheNote(){
  setCacheNote('gaKeyEventCacheStatus', GA.keyEventCacheByProperty[gaCurrentPropertyId()] || null, {
    network: 'Events refreshed',
    cached: 'Cached events',
    mixed: 'Mixed event cache',
    stale: 'Stale event cache'
  });
}
function gaRenderReportCacheNote(){
  setCacheNote('gaReportCacheStatus', GA.reportCacheMeta, {
    network: 'Report refreshed',
    cached: 'Cached report',
    mixed: 'Mixed report cache',
    stale: 'Stale report cache'
  });
}
function gaRenderKeyEventLabel(){
  const label = $('gaKeyEventLabel');
  if (label) label.textContent = gaCurrentSelectionLabel();
}
function gaRenderKeyEventPicker(){
  const list = $('gaKeyEventList');
  const actions = $('gaKeyEventActions');
  if (!list) return;
  const propertyId = gaCurrentPropertyId();
  const available = gaGetCurrentKeyEvents(propertyId);
  const selected = new Set(gaGetSelectedKeyEvents(propertyId));
  const needle = String(GA.keyEventFilter || '').trim().toLowerCase();
  const hideActions = () => {
    if (!actions) return;
    actions.innerHTML = '';
    actions.classList.add('hidden');
  };

  if (!propertyId){
    hideActions();
    list.innerHTML = `<div class="picker-empty">Pick a GA4 property.</div>`;
    return;
  }
  if (GA.loadingPropertyId === propertyId){
    hideActions();
    list.innerHTML = `<div class="picker-empty">Loading events…</div>`;
    return;
  }
  if (!available.length){
    hideActions();
    list.innerHTML = `<div class="picker-empty">No key events.</div>`;
    return;
  }

  const items = available.filter(item => item.eventName.toLowerCase().includes(needle));
  if (!items.length){
    hideActions();
    list.innerHTML = `<div class="picker-empty">No matches.</div>`;
    return;
  }

  const visibleNames = items.map(item => item.eventName);
  const selectedVisibleCount = visibleNames.filter(name => selected.has(name)).length;
  const allVisibleSelected = visibleNames.length > 0 && selectedVisibleCount === visibleNames.length;
  const someVisibleSelected = selectedVisibleCount > 0 && !allVisibleSelected;

  if (actions){
    actions.classList.remove('hidden');
    actions.innerHTML = `
      <label class="ga-picker-bulk">
        <input type="checkbox" data-ga-select-all${allVisibleSelected ? ' checked' : ''}>
        <span>Select all</span>
      </label>
      <button type="button" class="ga-picker-clear" data-ga-clear-events${selected.size ? '' : ' disabled'}>Clear</button>
    `;
  }

  list.innerHTML = items.map(item => {
    const active = selected.has(item.eventName) ? ' active' : '';
    return `
      <label class="picker-option ga-picker-option${active}">
        <input type="checkbox" data-ga-event="${escapeHtml(item.eventName)}"${selected.has(item.eventName) ? ' checked' : ''}>
        <span class="ga-picker-name">${escapeHtml(item.eventName)}</span>
      </label>
    `;
  }).join('');

  const selectAll = actions?.querySelector('[data-ga-select-all]');
  if (selectAll){
    selectAll.indeterminate = someVisibleSelected;
    selectAll.addEventListener('change', async ()=>{
      const current = new Set(gaGetSelectedKeyEvents());
      if (selectAll.checked) visibleNames.forEach(name => current.add(name));
      else visibleNames.forEach(name => current.delete(name));
      await gaSetSelectedKeyEvents(Array.from(current));
    });
  }

  actions?.querySelector('[data-ga-clear-events]')?.addEventListener('click', async ()=>{
    await gaSetSelectedKeyEvents([]);
  });

  qsa('#gaKeyEventList input[data-ga-event]').forEach(input => {
    input.addEventListener('change', async ()=>{
      const name = input.dataset.gaEvent || '';
      if (!name) return;
      const current = new Set(gaGetSelectedKeyEvents());
      if (current.has(name)) current.delete(name);
      else current.add(name);
      await gaSetSelectedKeyEvents(Array.from(current));
    });
  });
}
function gaResetExport(){
  GA.lastExport = null;
  GA.reportCacheMeta = null;
  const btn = $('gaExport');
  if (btn) btn.disabled = true;
  gaRenderReportCacheNote();
}
function gaSetExport(filename, csv){
  GA.lastExport = filename && csv ? { filename, csv } : null;
  const btn = $('gaExport');
  if (btn) btn.disabled = !GA.lastExport;
}
function gaSyncGaActions(){
  const load = $('gaLoad');
  const prop = gaCurrentPropertyId();
  if (load){
    const hasKeySelection = gaGetSelectedKeyEvents().length > 0;
    const hasKeyEvents = gaGetCurrentKeyEvents().length > 0;
    load.disabled = !prop || (GA.mode === 'keyEvents' && (!hasKeySelection || !hasKeyEvents || GA.loadingPropertyId === prop));
    load.textContent = GA.mode === 'keyEvents' ? 'Load events' : 'Load';
  }
  const refresh = $('gaRefreshData');
  if (refresh) refresh.disabled = !prop;
  const exportBtn = $('gaExport');
  if (exportBtn) exportBtn.disabled = !GA.lastExport;
}
function gaRenderKeyEventState(){
  gaRenderKeyEventLabel();
  gaRenderKeyEventPicker();
  gaRenderKeyEventNotice();
  gaRenderPropertyCacheNote();
  gaRenderKeyEventCacheNote();
  gaSyncGaActions();
}
function gaOpenKeyEventPicker(){
  if (!gaCurrentPropertyId()) return;
  $('gaKeyEventMenu')?.classList.remove('hidden');
  $('gaKeyEventToggle')?.setAttribute('aria-expanded', 'true');
  const search = $('gaKeyEventSearch');
  if (search){
    search.value = GA.keyEventFilter || '';
    search.focus();
    search.select();
  }
}
function gaCloseKeyEventPicker(){
  $('gaKeyEventMenu')?.classList.add('hidden');
  $('gaKeyEventToggle')?.setAttribute('aria-expanded', 'false');
}
function gaSyncModeUi(){
  const isKeyEvents = GA.mode === 'keyEvents';
  qsa('.ga-mode-overview').forEach(el => el.classList.toggle('hidden', isKeyEvents));
  qsa('.ga-mode-keyevents').forEach(el => el.classList.toggle('hidden', !isKeyEvents));
  $('gaModeOverview')?.classList.toggle('active', !isKeyEvents);
  $('gaModeKeyEvents')?.classList.toggle('active', isKeyEvents);
  $('gaModeOverview')?.setAttribute('aria-pressed', String(!isKeyEvents));
  $('gaModeKeyEvents')?.setAttribute('aria-pressed', String(isKeyEvents));
  const breakdown = $('gaKeyBreakdown');
  if (breakdown) breakdown.value = GA.breakdown;
  if (!isKeyEvents) gaCloseKeyEventPicker();
  gaRenderKeyEventState();
}
function gaSetMode(mode){
  GA.mode = mode === 'keyEvents' ? 'keyEvents' : 'overview';
  void gaSetStored({ [GA_STORAGE_KEYS.mode]: GA.mode });
  gaSyncModeUi();
  if (GA.mode === 'keyEvents'){
    const propertyId = gaCurrentPropertyId();
    if (propertyId && !GA.keyEventsByProperty[propertyId]){
      gaLoadKeyEvents(propertyId).catch(e => clearResult('❌ ' + (e?.message || e), 'gaResult'));
    }
  }
}
async function gaSetSelectedKeyEvents(names){
  const propertyId = gaCurrentPropertyId();
  if (!propertyId) return [];
  const order = new Map(gaGetCurrentKeyEvents(propertyId).map((item, index) => [item.eventName, index]));
  const next = Array.from(new Set((names || []).filter(name => order.has(name))))
    .sort((a, b) => (order.get(a) ?? 0) - (order.get(b) ?? 0));
  GA.keyEventSelections[propertyId] = next;
  await gaSetStored({ [GA_STORAGE_KEYS.selections]: GA.keyEventSelections });
  gaRenderKeyEventState();
  return next;
}
async function gaLoadKeyEvents(propertyId, { force=false } = {}){
  if (!propertyId){
    gaRenderKeyEventState();
    return [];
  }
  if (!force && GA.keyEventsByProperty[propertyId]){
    gaRenderKeyEventCacheNote();
    gaRenderKeyEventState();
    return GA.keyEventsByProperty[propertyId];
  }

  GA.loadingPropertyId = propertyId;
  gaRenderKeyEventState();
  try{
    const r = await send({ type:'gaListKeyEvents', propertyId, forceRefresh: !!force });
    if (!r.ok) throw new Error(r.error || 'Failed to load key events');

    const items = (r.data || [])
      .map(item => ({
        eventName: item.eventName || '',
        custom: !!item.custom,
        countingMethod: item.countingMethod || '',
        createTime: item.createTime || ''
      }))
      .filter(item => item.eventName)
      .sort((a, b) => a.eventName.localeCompare(b.eventName));

    GA.keyEventsByProperty[propertyId] = items;
    GA.keyEventCacheByProperty[propertyId] = r.cache || null;
    const raw = Array.isArray(GA.keyEventSelections[propertyId]) ? GA.keyEventSelections[propertyId] : [];
    const available = new Set(items.map(item => item.eventName));
    const next = raw.filter(name => available.has(name));
    const removed = raw.length - next.length;
    GA.keyEventSelections[propertyId] = next;

    if (removed > 0){
      await gaSetStored({ [GA_STORAGE_KEYS.selections]: GA.keyEventSelections });
      gaSetPropertyNotice(propertyId, `Removed ${removed} unavailable saved event${removed === 1 ? '' : 's'}.`);
    } else if (!items.length){
      gaSetPropertyNotice(propertyId, 'No key events found.');
    } else {
      gaSetPropertyNotice(propertyId, '');
      gaSetGeneralNotice('');
    }

    return items;
  } catch (e){
    delete GA.keyEventsByProperty[propertyId];
    delete GA.keyEventCacheByProperty[propertyId];
    gaSetPropertyNotice(propertyId, `Load failed: ${e?.message || e}`);
    throw e;
  } finally {
    if (GA.loadingPropertyId === propertyId) GA.loadingPropertyId = '';
    gaRenderKeyEventState();
  }
}
async function gaHandlePropertyChange({ forceReload=false } = {}){
  const propertyId = gaCurrentPropertyId();
  GA.keyEventFilter = '';
  gaSyncPropPickerLabel();
  gaRenderPropPicker(GA.propFilter || '');
  gaCloseKeyEventPicker();
  gaResetExport();
  if (!propertyId){
    gaRenderKeyEventState();
    return;
  }
  gaSetGeneralNotice('');
  try{
    await gaLoadKeyEvents(propertyId, { force: forceReload });
  } catch (e){
    if (GA.mode === 'keyEvents') clearResult('❌ ' + (e?.message || e), 'gaResult');
  }
}
async function loadGaPropsOnce({ forceRefresh=false } = {}){
  const sel = $('gaProps');
  if (!sel) return;
  if (GA.props && sel.options.length && !forceRefresh){
    gaSyncPropPickerLabel();
    gaRenderPropPicker(GA.propFilter || '');
    gaRenderPropertyCacheNote();
    return;
  }

  const currentValue = sel.value || '';
  const r = await send({ type:"gaListProperties", forceRefresh: !!forceRefresh });
  if (!r.ok) throw new Error(r.error || "Failed to list GA properties");
  GA.propCacheMeta = r.cache || null;
  GA.props = r.data || [];
  sel.innerHTML = "";

  const placeholder = document.createElement('option');
  placeholder.value = '';
  placeholder.textContent = GA.props.length ? 'Select GA4 property' : 'No GA4 properties';
  sel.appendChild(placeholder);

  GA.props.forEach(p => {
    const opt = document.createElement('option');
    opt.value = p.id;
    opt.textContent = `${p.account} • ${p.displayName} (p:${p.id})`;
    sel.appendChild(opt);
  });

  const hasCurrent = !!currentValue && Array.from(sel.options).some(opt => opt.value === currentValue);
  sel.value = hasCurrent ? currentValue : '';
  if (currentValue && !hasCurrent){
    gaSetGeneralNotice('Saved GA4 property is unavailable.');
  } else if (!sel.value && !GA.props.length){
    gaSetGeneralNotice('No GA4 properties found.');
  } else if (sel.value){
    gaSetGeneralNotice('');
  }
  gaSyncPropPickerLabel();
  gaRenderPropPicker();
  gaRenderPropertyCacheNote();
  await gaHandlePropertyChange({ forceReload: !!sel.value && !!forceRefresh });
}
async function gaFetchReport(payload){
  const r = await send(Object.assign({ type:'gaReport' }, payload));
  if (!r.ok) throw new Error(r.error || 'GA4 error');
  return { data: r.data, cache: r.cache || null };
}
async function gaFetchKeyEventBundle({ propertyId, startDate, endDate, eventNames, breakdown, forceRefresh=false }){
  const base = {
    propertyId,
    startDate,
    endDate,
    metrics: GA_KEY_EVENT_METRICS,
    inListFilter: {
      fieldName: 'eventName',
      values: eventNames
    }
  };
  const [eventTotals, trend, breakdownData] = await Promise.all([
    gaFetchReport(Object.assign({}, base, {
      dimensions: ['eventName'],
      rowLimit: Math.max(eventNames.length, 25),
      orderByMetric: 'keyEvents',
      forceRefresh
    })),
    gaFetchReport(Object.assign({}, base, { dimensions: ['date'], forceRefresh })),
    gaFetchReport(Object.assign({}, base, {
      dimensions: [breakdown],
      rowLimit: 50,
      orderByMetric: 'keyEvents',
      forceRefresh
    }))
  ]);
  return {
    eventTotals: eventTotals.data,
    trend: trend.data,
    breakdown: breakdownData.data,
    cache: combineCacheMeta([eventTotals.cache, trend.cache, breakdownData.cache])
  };
}

async function gaLoadActiveReport({ forceRefresh=false } = {}){
  const prop = gaCurrentPropertyId();
  if (!prop) return clearResult("Pick a GA4 property.", 'gaResult');

  let range;
  try{
    range = gaResolveDateRange();
  }catch(e){
    return clearResult(e?.message || String(e), 'gaResult');
  }

  gaResetExport();
  if (GA.mode === 'keyEvents'){
    const eventNames = gaGetSelectedKeyEvents(prop);
    if (!eventNames.length) return clearResult('Pick at least one event.', 'gaResult');

    clearResult(forceRefresh ? 'Refreshing…' : 'Loading…', 'gaResult');
    try{
      const breakdown = $('gaKeyBreakdown')?.value || GA.breakdown;
      GA.breakdown = breakdown;
      void gaSetStored({ [GA_STORAGE_KEYS.breakdown]: GA.breakdown });
      const currData = await gaFetchKeyEventBundle({
        propertyId: prop,
        startDate: range.start,
        endDate: range.end,
        eventNames,
        breakdown,
        forceRefresh
      });

      let prevData = null;
      const cacheBits = [currData.cache];
      if ($('gaCompare')?.checked){
        const prevRange = gaPreviousRange(range.start, range.end);
        prevData = await gaFetchKeyEventBundle({
          propertyId: prop,
          startDate: prevRange.start,
          endDate: prevRange.end,
          eventNames,
          breakdown,
          forceRefresh
        });
        cacheBits.push(prevData.cache);
      }

      GA.reportCacheMeta = combineCacheMeta(cacheBits);
      renderGaKeyEventsReport(currData, {
        start: range.start,
        end: range.end,
        breakdown,
        prop,
        eventNames
      }, prevData);
      gaRenderReportCacheNote();
    }catch(e){
      clearResult('❌ ' + (e?.message || e), 'gaResult');
    }
    return;
  }

  const dim = $('gaDim')?.value || 'date';
  clearResult(forceRefresh ? 'Refreshing…' : 'Loading…', 'gaResult');
  try{
    const currData = await gaFetchReport({
      propertyId: prop,
      startDate: range.start,
      endDate: range.end,
      dimension: dim,
      forceRefresh
    });

    let prevData = null;
    const cacheBits = [currData.cache];
    if ($('gaCompare')?.checked){
      const prevRange = gaPreviousRange(range.start, range.end);
      prevData = await gaFetchReport({
        propertyId: prop,
        startDate: prevRange.start,
        endDate: prevRange.end,
        dimension: dim,
        forceRefresh
      });
      cacheBits.push(prevData.cache);
    }

    GA.reportCacheMeta = combineCacheMeta(cacheBits);
    renderGaReport(currData.data, { start: range.start, end: range.end, dim, prop }, prevData?.data || null);
    gaRenderReportCacheNote();
  }catch(e){
    clearResult('❌ ' + (e?.message || e), 'gaResult');
  }
}

on('gaModeOverview', 'click', ()=> gaSetMode('overview'));
on('gaModeKeyEvents', 'click', ()=> gaSetMode('keyEvents'));
on('gaProps', 'change', ()=>{ gaHandlePropertyChange().catch(e => clearResult('❌ ' + (e?.message || e), 'gaResult')); });
on('gaPropToggle', 'click', (e)=>{
  e.preventDefault();
  $('gaPropMenu')?.classList.contains('hidden') ? gaOpenPropPicker() : gaClosePropPicker();
});
on('gaPropSearch', 'input', (e)=>{
  GA.propFilter = e.target?.value || '';
  gaRenderPropPicker(GA.propFilter);
});
on('gaPropSearch', 'keydown', (e)=>{
  if (e.key === 'Escape') gaClosePropPicker();
});
on('gaKeyBreakdown', 'change', ()=>{
  GA.breakdown = $('gaKeyBreakdown')?.value || GA_DEFAULT_BREAKDOWN;
  void gaSetStored({ [GA_STORAGE_KEYS.breakdown]: GA.breakdown });
});
on('gaKeyEventToggle', 'click', (e)=>{
  e.preventDefault();
  $('gaKeyEventMenu')?.classList.contains('hidden') ? gaOpenKeyEventPicker() : gaCloseKeyEventPicker();
});
on('gaKeyEventSearch', 'input', (e)=>{
  GA.keyEventFilter = e.target?.value || '';
  gaRenderKeyEventPicker();
});
on('gaKeyEventSearch', 'keydown', (e)=>{
  if (e.key === 'Escape') gaCloseKeyEventPicker();
});
document.addEventListener('click', (e)=>{
  const gaPropShell = e.target?.closest?.('.ga-prop-shell');
  if (!gaPropShell) gaClosePropPicker();
  const shell = e.target?.closest?.('.ga-picker-shell');
  if (!shell) gaCloseKeyEventPicker();
});
on('navAnalytics','click', async ()=>{
  try{
    await loadGaPropsOnce();
    const r = await send({ type: "gaDetectFromTab" });
    if (r.ok && r.data && r.data.propertyId){
      const sel = $('gaProps');
      if (sel && Array.from(sel.options).some(o => o.value === r.data.propertyId)){
        await gaSetSelectedProperty(r.data.propertyId);
        clearResult(`Matched property: ${r.data.propertyName} (${r.data.measurementId || '—'})`, 'gaResult');
      }
    } else if (r.ok && r.data?.foundGIds?.length){
      clearResult(`Found IDs: ${r.data.foundGIds.join(', ')}. No matching property.`, 'gaResult');
    } else {
      await gaHandlePropertyChange();
    }
  }catch(e){
    // non-fatal; keep UI usable
  }
});
$('gaRange').addEventListener('change', ()=>{
  const custom = $('gaRange').value === 'custom';
  $('gaCustom').style.display = custom ? 'grid' : 'none';
});
$('gaLoad').addEventListener('click', ()=>{ gaLoadActiveReport({ forceRefresh:false }); });
on('gaRefreshProps', 'click', async ()=>{
  const btn = $('gaRefreshProps');
  if (btn?.disabled) return;
  if (btn){
    btn.disabled = true;
    btn.setAttribute('aria-busy', 'true');
  }
  try{
    await loadGaPropsOnce({ forceRefresh:true });
  }catch(e){
    clearResult('❌ ' + (e?.message || e), 'gaResult');
  }finally{
    if (btn){
      btn.disabled = false;
      btn.removeAttribute('aria-busy');
    }
  }
});
on('settingsRefreshGa', 'click', async ()=>{
  try{
    await loadGaPropsOnce({ forceRefresh:true });
  }catch(e){
    clearResult('❌ ' + (e?.message || e), 'gaResult');
  }
});
on('gaRefreshData', 'click', ()=>{ gaLoadActiveReport({ forceRefresh:true }); });
$('gaExport').addEventListener('click', ()=>{
  if (!GA.lastExport) return clearResult('Load data first.', 'gaResult');
  const blob = new Blob([GA.lastExport.csv], { type:'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = GA.lastExport.filename;
  a.click();
  URL.revokeObjectURL(url);
});

// Renderers
function renderGaReport(currData, meta, prevData){
  if (!gaHasRows(currData)){
    gaResetExport();
    renderHtml('gaResult', `<div class="card">No data for ${meta.start} → ${meta.end}.</div>`);
    return;
  }

  const metricIndexByName = Object.fromEntries((currData.metricHeaders || []).map((h, i) => [h.name, i]));
  const dimLabel = GA_DIM_LABELS[meta.dim] || meta.dim;
  const sums = gaSummarizeReport(currData);
  const prevSums = gaHasRows(prevData) ? gaSummarizeReport(prevData) : null;

  const metric = $('gaMetric')?.value || 'activeUsers';
  const mIdx = metricIndexByName[metric] ?? 0;
  const series = currData.rows.map(r => Number(r.metricValues?.[mIdx]?.value || 0));
  renderHtml('gaResult', buildInsightStage({
    eyebrow: 'GA4',
    title: 'Overview',
    rangeLabel: `${meta.start} → ${meta.end}`,
    subtitle: `Breakdown by ${dimLabel}.`,
    badges: [`Dimension: ${dimLabel}`],
    kpis: [
      {
        label: 'Active users',
        value: formatMetricValue(sums.activeUsers),
        delta: metricDelta(sums.activeUsers, prevSums?.activeUsers)
      },
      {
        label: 'Sessions',
        value: formatMetricValue(sums.sessions),
        delta: metricDelta(sums.sessions, prevSums?.sessions)
      },
      {
        label: 'Views',
        value: formatMetricValue(sums.screenPageViews),
        delta: metricDelta(sums.screenPageViews, prevSums?.screenPageViews)
      },
      {
        label: 'Event count',
        value: formatMetricValue(sums.eventCount),
        delta: metricDelta(sums.eventCount, prevSums?.eventCount)
      }
    ],
    sparklineValues: series,
    sparklineLabel: `${gaMetricLabel(metric)} trend`,
    tableSections: [gaReportTableSection('Detailed breakdown', currData)].filter(Boolean),
    barSections: [gaReportBarSection(`Breakdown by ${dimLabel}`, currData, metric)].filter(Boolean)
  }));

  gaSetExport(`ga4-${meta.dim}-${meta.start}-${meta.end}.csv`, gaToCSV(currData));
}
function renderGaKeyEventsReport(currBundle, meta, prevBundle){
  const summarySource = gaPickSummaryReport(currBundle);
  if (!summarySource){
    gaResetExport();
    renderHtml('gaResult', `<div class="card">No data for ${meta.start} → ${meta.end}.</div>`);
    return;
  }

  const prevSummarySource = gaPickSummaryReport(prevBundle);
  const sums = gaSummarizeReport(summarySource);
  const prevSums = prevSummarySource ? gaSummarizeReport(prevSummarySource) : null;
  const series = gaMetricSeries(currBundle.trend, 'keyEvents');
  const selectionLabel = meta.eventNames.length === 1 ? meta.eventNames[0] : `${meta.eventNames.length} events selected`;
  const breakdownLabel = GA_DIM_LABELS[meta.breakdown] || meta.breakdown;
  renderHtml('gaResult', buildInsightStage({
    eyebrow: 'GA4',
    title: 'Key events',
    rangeLabel: `${meta.start} → ${meta.end}`,
    subtitle: selectionLabel,
    badges: [`Breakdown: ${breakdownLabel}`],
    kpis: [
      {
        label: 'Key events',
        value: formatMetricValue(sums.keyEvents),
        delta: metricDelta(sums.keyEvents, prevSums?.keyEvents)
      },
      {
        label: 'Event count',
        value: formatMetricValue(sums.eventCount),
        delta: metricDelta(sums.eventCount, prevSums?.eventCount)
      },
      {
        label: 'Active users',
        value: formatMetricValue(sums.activeUsers),
        delta: metricDelta(sums.activeUsers, prevSums?.activeUsers)
      },
      {
        label: 'Sessions',
        value: formatMetricValue(sums.sessions),
        delta: metricDelta(sums.sessions, prevSums?.sessions)
      }
    ],
    sparklineValues: series,
    sparklineLabel: series.length ? 'Key events over time' : '',
    tableSections: [gaReportTableSection('Per-event totals', currBundle.eventTotals)].filter(Boolean),
    barSections: [gaReportBarSection(`Breakdown by ${breakdownLabel}`, currBundle.breakdown, 'keyEvents')].filter(Boolean)
  }));

  gaSetExport(`ga4-key-events-${meta.breakdown}-${meta.start}-${meta.end}.csv`, gaToCSV(currBundle.breakdown));
}
function gaReportTableSection(title, data){
  if (!gaHasRows(data)) return null;
  return {
    title,
    columns: (data.dimensionHeaders || []).map(header => ({
      label: GA_DIM_LABELS[header.name] || header.name
    })).concat((data.metricHeaders || []).map(header => ({
      label: gaMetricLabel(header.name),
      numeric: true
    }))),
    rows: data.rows.map(row => (
      (row.dimensionValues || []).map(value => value.value || '—')
        .concat((row.metricValues || []).map(value => gaNf(value.value || 0)))
    ))
  };
}
function gaReportBarSection(title, data, metricName){
  if (!gaHasRows(data)) return null;
  const metricIndex = Object.fromEntries((data.metricHeaders || []).map((header, index) => [header.name, index]))[metricName]
    ?? Object.fromEntries((data.metricHeaders || []).map((header, index) => [header.name, index]))[data.metricHeaders?.[0]?.name];
  if (metricIndex == null) return null;
  return {
    title,
    items: data.rows.slice(0, 8).map(row => {
      const rawValue = Number(row.metricValues?.[metricIndex]?.value || 0);
      const label = row.dimensionValues?.map(value => value.value || '—').filter(Boolean).join(' · ') || '—';
      return {
        label,
        value: rawValue,
        displayValue: gaNf(rawValue)
      };
    })
  };
}
function gaSummarizeReport(report){
  const sums = {};
  for (const row of (report?.rows || [])){
    row.metricValues?.forEach((mv, index) => {
      const key = report.metricHeaders?.[index]?.name;
      if (!key) return;
      sums[key] = (sums[key] || 0) + Number(mv.value || 0);
    });
  }
  return sums;
}
function gaMetricSeries(report, metricName){
  const metricIndex = Object.fromEntries((report?.metricHeaders || []).map((h, i) => [h.name, i]))[metricName];
  if (metricIndex == null) return [];
  return (report?.rows || []).map(row => Number(row.metricValues?.[metricIndex]?.value || 0));
}
function gaPickSummaryReport(bundle){
  if (gaHasRows(bundle?.eventTotals)) return bundle.eventTotals;
  if (gaHasRows(bundle?.trend)) return bundle.trend;
  if (gaHasRows(bundle?.breakdown)) return bundle.breakdown;
  return null;
}
function gaKpi(label, key, sums, prevSums){
  const val = sums[key] || 0;
  const prev = prevSums ? (prevSums[key] || 0) : null;
  const d = gaPctDelta(val, prev);
  return `<div class="kpi">
    <h5>${escapeHtml(label)}</h5>
    <span class="val">${gaNf(val)}</span>
    <span class="delta ${d.cls}">${d.text}</span>
  </div>`;
}
function gaBuildTableCard(title, data){
  if (!gaHasRows(data)){
    return `
      <div class="card">
        <h4>${escapeHtml(title)}</h4>
        <p style="margin:0;color:var(--muted)">No data available for this selection.</p>
      </div>
    `;
  }
  const header = (data.dimensionHeaders || []).map(h => GA_DIM_LABELS[h.name] || h.name)
    .concat((data.metricHeaders || []).map(h => gaMetricLabel(h.name)));
  const rows = data.rows.map(row => {
    const dims = (row.dimensionValues || []).map(v => `<td>${escapeHtml(v.value || '')}</td>`);
    const mets = (row.metricValues || []).map(v => `<td style="text-align:right">${gaNf(v.value || 0)}</td>`);
    return `<tr>${dims.join('')}${mets.join('')}</tr>`;
  }).join('');
  const thead = `<tr>${header.map(x => `<th>${escapeHtml(x)}</th>`).join('')}</tr>`;
  return `
    <div class="card">
      <h4>${escapeHtml(title)}</h4>
      <div style="max-height:260px;overflow:auto;border:1px solid var(--border);border-radius:8px">
        <table class="table-compact"><thead>${thead}</thead><tbody>${rows}</tbody></table>
      </div>
    </div>
  `;
}
function gaNf(n){ return Number(n || 0).toLocaleString(); }
function gaPctDelta(curr, prev){
  if (prev == null || prev === 0) return { text:"—", cls:"" };
  const d = ((curr - prev) / prev) * 100;
  return { text: (d > 0 ? "+" : "") + d.toFixed(1) + "%", cls: d >= 0 ? "up" : "down" };
}
function gaSparklineSVG(vals){
  const w = 120, h = 28, p = 2;
  if (!vals || !vals.length) return "";
  const min = Math.min(...vals), max = Math.max(...vals);
  const sx = i => p + (i * (w - 2 * p) / Math.max(1, vals.length - 1));
  const sy = v => max === min ? h / 2 : p + (h - 2 * p) * (1 - (v - min) / (max - min));
  let d = "";
  vals.forEach((v, i) => { d += (i ? " L" : "M") + sx(i).toFixed(1) + " " + sy(v).toFixed(1); });
  return `<svg class="spark" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}"><path d="${d}" fill="none" stroke="currentColor" stroke-width="1.5"/></svg>`;
}
function gaToCSV(data){
  const dimH = (data?.dimensionHeaders || []).map(h => h.name);
  const metH = (data?.metricHeaders || []).map(h => h.name);
  const head = dimH.concat(metH);
  const lines = [ head.join(",") ];
  for (const r of (data?.rows || [])){
    const dims = (r.dimensionValues || []).map(v => `"${String(v.value || "").replace(/"/g,'""')}"`);
    const mets = (r.metricValues || []).map(v => String(v.value || "0"));
    lines.push(dims.concat(mets).join(","));
  }
  return lines.join("\n");
}


// Ends GA4

// ===== CallRail =====
const CR = {
  accounts: [],
  companies: [],
  lastRows: null,
  lastMeta: null,
  inited: false,
  accountCache: null,
  companyCache: null,
  reportCache: null
};

function crIso(d){
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
}
function isoAddDays(iso, delta){
  const d = new Date(`${iso}T00:00:00`);
  d.setDate(d.getDate() + delta);
  return crIso(d);
}
function monthStartISO(d=new Date()){
  const x = new Date(d);
  x.setDate(1);
  return crIso(x);
}
function monthEndISO(d=new Date()){
  const x = new Date(d);
  // last day of month
  x.setMonth(x.getMonth()+1);
  x.setDate(0);
  return crIso(x);
}

function crSetStatus(msg, isError=false){
  const el = $('crStatus');
  if (el) el.innerHTML = isError ? `❌ ${escapeHtml(msg)}` : escapeHtml(msg);
  const panel = $('crPanelStatus');
  if (panel) panel.innerHTML = isError ? `❌ ${escapeHtml(msg)}` : escapeHtml(msg);
}
function crRenderListCacheNote(){
  setCacheNote('crListCacheStatus', combineCacheMeta([CR.accountCache, CR.companyCache]), {
    network: 'Lists refreshed',
    cached: 'Cached lists',
    mixed: 'Mixed list cache',
    stale: 'Stale list cache'
  });
}
function crRenderReportCacheNote(){
  setCacheNote('crReportCacheStatus', CR.reportCache, {
    network: 'Report refreshed',
    cached: 'Cached report',
    mixed: 'Mixed report cache',
    stale: 'Stale report cache'
  });
}

async function crGetStored(){
  return new Promise(resolve => {
    chrome.storage.local.get([
      'callrailApiKey','callrailAccountNumericId','callrailCompanyId',
      'callrailRange','callrailStart','callrailEnd','callrailGroupBy',
      'callrailDevice','callrailLeadStatus','callrailFirstTime','callrailMinDur','callrailMaxDur'
    ], resolve);
  });
}
async function crSetStored(obj){
  return new Promise(resolve => chrome.storage.local.set(obj, resolve));
}

function crFillSelect(selId, items, {placeholder="Select…", valueKey="value", labelKey="label", allowEmpty=false, emptyLabel="All"}={}){
  const sel = $(selId); if(!sel) return;
  sel.innerHTML = '';
  if (allowEmpty){
    const opt = document.createElement('option');
    opt.value = '';
    opt.textContent = emptyLabel;
    sel.appendChild(opt);
  }
  if (!items?.length){
    const opt = document.createElement('option');
    opt.value = '';
    opt.textContent = placeholder;
    sel.appendChild(opt);
    return;
  }
  for (const it of items){
    const opt = document.createElement('option');
    opt.value = it[valueKey];
    opt.textContent = it[labelKey];
    sel.appendChild(opt);
  }
}

function crComputeDates(range){
  const today = todayISO();
  const d = new Date();
  if (range === 'today') return {start: today, end: today};
  if (range === 'yesterday'){
    const y = isoAddDays(today, -1);
    return {start: y, end: y};
  }
  if (range === 'recent7') return {start: isoAddDays(today, -7), end: today};
  if (range === 'last7') return {start: isoAddDays(today, -7), end: isoAddDays(today, -1)};
  if (range === 'last30') return {start: isoAddDays(today, -30), end: isoAddDays(today, -1)};
  if (range === 'thisMonth') return {start: monthStartISO(d), end: today};
  if (range === 'lastMonth'){
    const prev = new Date(); prev.setMonth(prev.getMonth()-1);
    return {start: monthStartISO(prev), end: monthEndISO(prev)};
  }
  // custom
  return {start: '', end: ''};
}

function crRowsToCSV(rows, meta){
  const head = ['Source','Total Calls','Answered Calls','Missed Calls','Voicemails','Returning Callers','First-Time Callers','Average Duration'];
  const lines = [head.join(',')];
  for (const r of (rows||[])){
    const line = [
      r.key,
      r.total_calls,
      r.answered_calls,
      r.missed_calls,
      r.voicemails,
      r.returning_callers,
      r.first_time_callers,
      r.formatted_average_duration
    ].map(v => {
      const s = String(v ?? '');
      return /[",\n]/.test(s) ? `"${s.replace(/"/g,'""')}"` : s;
    }).join(',');
    lines.push(line);
  }
  const prefix = meta ? `# ${meta.companyName||''} | ${meta.start}..${meta.end} | group_by=${meta.groupBy}\n` : '';
  return prefix + lines.join('\n');
}

async function crFetchSummary(payload){
  const response = await send(Object.assign({ type:'callrailCallSummary' }, payload));
  if (!response.ok) throw new Error(response.error || 'CallRail error');
  return {
    data: response.data || {},
    cache: response.cache || null
  };
}
function crSummarizeRows(rows){
  const summary = (rows || []).reduce((acc, row) => {
    const totalCalls = Number(row.total_calls || 0);
    const avgDuration = Number(row.average_duration || 0);
    acc.total_calls += totalCalls;
    acc.answered_calls += Number(row.answered_calls || 0);
    acc.missed_calls += Number(row.missed_calls || 0);
    acc.voicemails += Number(row.voicemails || 0);
    acc.returning_callers += Number(row.returning_callers || 0);
    acc.first_time_callers += Number(row.first_time_callers || 0);
    acc.duration_weighted += avgDuration * totalCalls;
    return acc;
  }, {
    total_calls: 0,
    answered_calls: 0,
    missed_calls: 0,
    voicemails: 0,
    returning_callers: 0,
    first_time_callers: 0,
    duration_weighted: 0
  });
  summary.average_duration = summary.total_calls ? (summary.duration_weighted / summary.total_calls) : 0;
  summary.formatted_average_duration = formatDurationShort(summary.average_duration);
  return summary;
}
function crRenderTable(rows, meta, prevRows=null){
  const box = $('crResult'); if(!box) return;
  if (!rows?.length){
    renderHtml('crResult', `<div class="card">No call data found for the selected range/filters.</div>`);
    return;
  }
  const totals = crSummarizeRows(rows);
  const prevTotals = prevRows?.length ? crSummarizeRows(prevRows) : null;
  const groupLabel = meta.groupByLabel || 'Source';
  const sparklineValues = rows.slice(0, 8).map(row => Number(row.total_calls || 0));

  renderHtml('crResult', buildInsightStage({
    eyebrow: 'CallRail',
    title: 'Attribution',
    rangeLabel: `${meta.start} → ${meta.end}`,
    subtitle: meta.companyName || 'All companies',
    badges: [`Group: ${groupLabel}`],
    kpis: [
      {
        label: 'Total calls',
        value: formatMetricValue(totals.total_calls),
        delta: metricDelta(totals.total_calls, prevTotals?.total_calls)
      },
      {
        label: 'Answered calls',
        value: formatMetricValue(totals.answered_calls),
        delta: metricDelta(totals.answered_calls, prevTotals?.answered_calls)
      },
      {
        label: 'Missed calls',
        value: formatMetricValue(totals.missed_calls),
        delta: metricDelta(totals.missed_calls, prevTotals?.missed_calls, { inverse:true })
      },
      {
        label: 'Avg duration',
        value: totals.formatted_average_duration,
        delta: metricDelta(totals.average_duration, prevTotals?.average_duration)
      }
    ],
    sparklineValues,
    sparklineLabel: sparklineValues.length ? `${groupLabel} distribution` : '',
    tableSections: [{
      title: `${groupLabel} totals`,
      columns: [
        { label: groupLabel },
        { label: 'Total calls', numeric:true },
        { label: 'Answered', numeric:true },
        { label: 'Missed', numeric:true },
        { label: 'First-time', numeric:true },
        { label: 'Avg duration', numeric:true }
      ],
      rows: rows.slice(0, 12).map(row => [
        row.key || '—',
        formatMetricValue(row.total_calls),
        formatMetricValue(row.answered_calls),
        formatMetricValue(row.missed_calls),
        formatMetricValue(row.first_time_callers),
        row.formatted_average_duration || formatDurationShort(row.average_duration)
      ])
    }],
    barSections: [{
      title: `Breakdown by ${groupLabel}`,
      items: rows.slice(0, 8).map(row => ({
        label: row.key || '—',
        value: Number(row.total_calls || 0),
        displayValue: formatMetricValue(row.total_calls)
      }))
    }]
  }));
}

async function crLoadAccounts({ forceRefresh=false } = {}){
  crSetStatus('Connecting to CallRail…');
  const r = await send({ type: 'callrailListAccounts', forceRefresh: !!forceRefresh });
  if (!r.ok) throw new Error(r.error || 'CallRail error');
  CR.accountCache = r.cache || null;
  CR.accounts = (r.data?.accounts || []).map(a => ({
    id: a.id,
    numeric_id: a.numeric_id,
    name: a.name
  }));

  // prefer numeric_id for subsequent endpoints
  const items = CR.accounts.map(a => ({ value: String(a.numeric_id || a.id || ''), label: `${a.name} • ${a.numeric_id || a.id}` }));
  crFillSelect('crAccount', items, {placeholder:'Select account', valueKey:'value', labelKey:'label'});
  const stored = await crGetStored();
  const sel = $('crAccount');
  if (sel){
    const preferred = stored.callrailAccountNumericId;
    if (preferred && Array.from(sel.options).some(o=>o.value===String(preferred))) sel.value = String(preferred);
    else if (sel.options.length) sel.selectedIndex = 0;
  }
  await crSetStored({ callrailAccountNumericId: $('crAccount')?.value || '' });
  await crLoadCompanies({ forceRefresh });
  crRenderListCacheNote();
  crSetStatus('Connected ✅');
}

async function crLoadCompanies({ forceRefresh=false } = {}){
  const accountId = $('crAccount')?.value;
  if (!accountId) return;
  const r = await send({ type:'callrailListCompanies', accountId, forceRefresh: !!forceRefresh });
  if (!r.ok) throw new Error(r.error || 'Failed to list companies');
  CR.companyCache = r.cache || null;
  CR.companies = (r.data?.companies || []).map(c => ({ id:c.id, name:c.name }));
  const items = CR.companies.map(c => ({ value: c.id, label: c.name }));
  crFillSelect('crCompany', items, {placeholder:'All companies', valueKey:'value', labelKey:'label', allowEmpty:true, emptyLabel:'All companies'});
  const stored = await crGetStored();
  const sel = $('crCompany');
  if (sel && stored.callrailCompanyId && Array.from(sel.options).some(o=>o.value===stored.callrailCompanyId)){
    sel.value = stored.callrailCompanyId;
  }
  crRenderListCacheNote();
}

async function crLoadSummary({ forceRefresh=false } = {}){
  const accountId = $('crAccount')?.value;
  if (!accountId) return crSetStatus('Pick an account.', true);
  const companyId = $('crCompany')?.value || '';
  const companyName = $('crCompany')?.selectedOptions?.[0]?.textContent || '';
  const range = $('crRange')?.value || 'recent7';
  const groupBy = $('crGroupBy')?.value || 'source';
  const groupByLabel = $('crGroupBy')?.selectedOptions?.[0]?.textContent || groupBy;
  const device = $('crDevice')?.value || 'all';
  const leadStatus = $('crLeadStatus')?.value || '';
  const firstTime = $('crFirstTime')?.value; // '', 'true', 'false'
  const minDur = $('crMinDur')?.value;
  const maxDur = $('crMaxDur')?.value;

  let start, end;
  if (range === 'custom'){
    start = $('crStart')?.value;
    end = $('crEnd')?.value || todayISO();
    if (!start) return crSetStatus('Pick a start date.', true);
  }else{
    const d = crComputeDates(range);
    start = d.start; end = d.end;
  }

  await crSetStored({
    callrailAccountNumericId: accountId,
    callrailCompanyId: companyId,
    callrailRange: range,
    callrailStart: start,
    callrailEnd: end,
    callrailGroupBy: groupBy,
    callrailDevice: device,
    callrailLeadStatus: leadStatus,
    callrailFirstTime: firstTime ?? '',
    callrailMinDur: minDur ?? '',
    callrailMaxDur: maxDur ?? ''
  });

  crSetStatus(forceRefresh ? 'Refreshing…' : 'Loading…');
  renderHtml('crResult', `<div class="card">Loading…</div>`);
  const basePayload = {
    accountId,
    companyId,
    companyName,
    group_by: groupBy,
    groupByLabel,
    device,
    lead_status: leadStatus,
    first_time_callers: firstTime,
    min_duration: minDur,
    max_duration: maxDur,
    forceRefresh: !!forceRefresh
  };
  const prevRange = gaPreviousRange(start, end);

  try{
    const [currentResult, prevResult] = await Promise.allSettled([
      crFetchSummary(Object.assign({}, basePayload, {
        start_date: start,
        end_date: end
      })),
      crFetchSummary(Object.assign({}, basePayload, {
        start_date: prevRange.start,
        end_date: prevRange.end
      }))
    ]);

    if (currentResult.status !== 'fulfilled') throw currentResult.reason;

    const rows = currentResult.value.data?.rows || [];
    const meta = currentResult.value.data?.meta || {};
    const prevRows = prevResult.status === 'fulfilled' ? (prevResult.value.data?.rows || []) : null;
    CR.reportCache = combineCacheMeta([
      currentResult.value.cache,
      prevResult.status === 'fulfilled' ? prevResult.value.cache : null
    ]);
    CR.lastRows = rows;
    CR.lastMeta = meta;
    crRenderTable(rows, meta, prevRows);
    crRenderReportCacheNote();
    crSetStatus('Loaded.');
  }catch(e){
    crSetStatus(e?.message || String(e), true);
  }
}

async function crEnsureInit(){
  if (CR.inited) return;
  CR.inited = true;

  // restore saved values
  const stored = await crGetStored();
  const hasKey = !!stored.callrailApiKey;
  $('crDisconnect')?.setAttribute('style', hasKey ? '' : 'opacity:.6; pointer-events:none');
  if (hasKey){
    $('crApiKey').value = '••••••••••';
  }

  // Restore ranges/filters
  if (stored.callrailRange) $('crRange').value = stored.callrailRange;
  if (stored.callrailGroupBy) $('crGroupBy').value = stored.callrailGroupBy;
  if (stored.callrailDevice) $('crDevice').value = stored.callrailDevice;
  if (stored.callrailLeadStatus != null) $('crLeadStatus').value = stored.callrailLeadStatus;
  if (stored.callrailFirstTime != null) $('crFirstTime').value = stored.callrailFirstTime;
  if (stored.callrailMinDur != null) $('crMinDur').value = stored.callrailMinDur;
  if (stored.callrailMaxDur != null) $('crMaxDur').value = stored.callrailMaxDur;

  const range = $('crRange').value;
  $('crCustom').classList.toggle('hidden', range !== 'custom');
  if (stored.callrailStart) $('crStart').value = stored.callrailStart;
  if (stored.callrailEnd) $('crEnd').value = stored.callrailEnd;

  // wire events
  on('crToggleFilters','click', ()=> $('crFilters')?.classList.toggle('hidden'));
  on('crRange','change', ()=>{
    const isCustom = $('crRange').value === 'custom';
    $('crCustom').classList.toggle('hidden', !isCustom);
    if (!isCustom){
      const d = crComputeDates($('crRange').value);
      if ($('crStart')) $('crStart').value = d.start;
      if ($('crEnd')) $('crEnd').value = d.end;
    }
  });
  on('crAccount','change', async ()=>{ await crSetStored({ callrailAccountNumericId: $('crAccount').value }); await crLoadCompanies(); });
  on('crCompany','change', ()=> crSetStored({ callrailCompanyId: $('crCompany').value||'' }));
  on('crRefreshLists','click', async ()=>{
    try{
      await crLoadAccounts({ forceRefresh:true });
    }catch(e){ crSetStatus(e.message || String(e), true); }
  });
  on('settingsRefreshCallrail','click', async ()=>{
    try{
      await crLoadAccounts({ forceRefresh:true });
    }catch(e){ crSetStatus(e.message || String(e), true); }
  });

  on('crSaveKey','click', async ()=>{
    try{
      const val = $('crApiKey')?.value?.trim();
      if (!val || val === '••••••••••'){
        return crSetStatus('Paste an API key.', true);
      }
      await crSetStored({ callrailApiKey: val });
      await send({ type:'callrailInvalidateCache' }).catch(()=>null);
      CR.accountCache = null;
      CR.companyCache = null;
      CR.reportCache = null;
      crRenderListCacheNote();
      crRenderReportCacheNote();
      $('crApiKey').value = '••••••••••';
      $('crDisconnect')?.setAttribute('style','');
      await crLoadAccounts({ forceRefresh:true });
    }catch(e){ crSetStatus(e.message || String(e), true); }
  });
  on('crDisconnect','click', async ()=>{
    await crSetStored({ callrailApiKey:'', callrailAccountNumericId:'', callrailCompanyId:'' });
    await send({ type:'callrailInvalidateCache' }).catch(()=>null);
    CR.accountCache = null;
    CR.companyCache = null;
    CR.reportCache = null;
    $('crApiKey').value = '';
    $('crAccount').innerHTML = '<option value="">Select account</option>';
    $('crCompany').innerHTML = '<option value="">All companies</option>';
    $('crResult').innerHTML = '';
    $('crDisconnect')?.setAttribute('style','opacity:.6; pointer-events:none');
    crRenderListCacheNote();
    crRenderReportCacheNote();
    crSetStatus('Disconnected.');
  });

  on('crLoad','click', ()=> crLoadSummary({ forceRefresh:false }));
  on('crRefreshData','click', ()=> crLoadSummary({ forceRefresh:true }));
  on('crExport','click', ()=>{
    if (!CR.lastRows?.length) return;
    const csv = crRowsToCSV(CR.lastRows, CR.lastMeta);
    const blob = new Blob([csv], {type:'text/csv'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `callrail-${(CR.lastMeta?.groupBy||'source')}-${(CR.lastMeta?.start||'')}-${(CR.lastMeta?.end||'')}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  });

  // If key already stored, auto-connect + load accounts once
  if (hasKey){
    try{ await crLoadAccounts(); }
    catch(e){ crSetStatus(e.message || String(e), true); }
  }else{
    crSetStatus('Add an API key in Settings.');
    crFillSelect('crAccount', [], {placeholder:'Add API key'});
    crFillSelect('crCompany', [], {placeholder:'All companies', allowEmpty:true, emptyLabel:'All companies'});
    crRenderListCacheNote();
    crRenderReportCacheNote();
  }
}

// initialize CallRail when tab opened
on('navCallRail','click', ()=>{ crEnsureInit(); });
on('navSettings','click', ()=>{ crEnsureInit(); });

// Ends CallRail


/* ---------- Active tab helpers ---------- */
async function getActiveTab(){ const [tab] = await chrome.tabs.query({ active:true, currentWindow:true }); return tab; }
async function getActiveTabUrl(){
  try{ const tab = await getActiveTab(); const url = tab?.url || ''; return /^https?:/i.test(url) ? url : ''; }
  catch{ return ''; }
}
async function collectActivePageDiagnostics(options = {}){
  const mode = options.mode || 'onpage';
  const includeFetch = !!options.includeFetch;
  const includeTags = mode === 'tags' || !!options.includeTags;
  const frameLabel = window.top === window ? 'top frame' : `iframe: ${location.href}`;
  const uniq = (values) => Array.from(new Set((values || []).filter(Boolean)));
  const meta = (selector, attr='content') => (document.querySelector(selector)?.getAttribute(attr) || '').trim();
  const abs = (value) => { try { return new URL(value, location.href).href; } catch { return ''; } };
  const collectMatches = (sources, pattern) => {
    const out = new Set();
    (sources || []).forEach(source => {
      const text = String(source || '');
      if (!text) return;
      const regex = new RegExp(pattern.source, pattern.flags.includes('g') ? pattern.flags : `${pattern.flags}g`);
      let match;
      while ((match = regex.exec(text)) !== null) out.add((match[1] || match[0] || '').trim());
    });
    return Array.from(out).filter(Boolean);
  };

  const scriptEls = Array.from(document.scripts || []);
  const scriptUrls = uniq(scriptEls.map(script => script.src || script.getAttribute('src') || '').map(url => url.trim()).filter(Boolean));
  const inlineScripts = scriptEls.map(script => script.textContent || '').filter(Boolean);
  const noscripts = Array.from(document.querySelectorAll('noscript')).map(node => node.textContent || '').filter(Boolean);
  const iframeSources = uniq(Array.from(document.querySelectorAll('iframe[src]')).map(frame => frame.getAttribute('src') || '').map(abs).filter(Boolean));
  const resourceUrls = (() => {
    try { return uniq((performance.getEntriesByType?.('resource') || []).map(entry => entry.name).filter(Boolean)); }
    catch { return []; }
  })();
  const textSources = [...inlineScripts, ...noscripts];
  const urlSources = [...scriptUrls, ...resourceUrls, ...iframeSources];
  const allSources = [...textSources, ...urlSources];

  const diagnostics = {
    url: location.href,
    origin: location.origin,
    hostname: location.hostname,
    protocol: location.protocol,
    frame: frameLabel,
    title: (document.title || '').trim(),
    metaDesc: meta('meta[name="description"]') || meta('meta[name="Description"]'),
    robotsMeta: (meta('meta[name="robots"]') || meta('meta[name="ROBOTS"]')).toLowerCase(),
    canonical: abs(document.querySelector('link[rel="canonical"]')?.getAttribute('href') || ''),
    canonicalCrossDomain: false,
    language: document.documentElement?.lang || '',
    charset: meta('meta[charset]', 'charset') || document.characterSet || '',
    viewport: meta('meta[name="viewport"]'),
    doctype: document.doctype ? `<!DOCTYPE ${document.doctype.name}>` : '',
    h1Texts: [],
    h1Count: 0,
    headingCounts: {},
    headingSequence: [],
    headingSkips: 0,
    wordCount: 0,
    internalLinks: 0,
    externalLinks: 0,
    nofollowLinks: 0,
    weakAnchorCount: 0,
    emptyAnchorCount: 0,
    weakAnchorSamples: [],
    imgCount: 0,
    imgMissingAlt: 0,
    iframeCount: document.querySelectorAll('iframe').length,
    ldTypes: [],
    openGraph: {
      title: meta('meta[property="og:title"]'),
      description: meta('meta[property="og:description"]'),
      image: meta('meta[property="og:image"]'),
      type: meta('meta[property="og:type"]'),
      url: meta('meta[property="og:url"]')
    },
    twitterCard: {
      card: meta('meta[name="twitter:card"]'),
      title: meta('meta[name="twitter:title"]'),
      description: meta('meta[name="twitter:description"]'),
      image: meta('meta[name="twitter:image"]')
    },
    robotsTxt: { checked: false, ok: false, status: 0, url: '', error: '' },
    sitemap: { found: false, entries: [], probeUrl: '' },
    tags: []
  };

  try {
    if (diagnostics.canonical) {
      const canonicalHost = new URL(diagnostics.canonical).hostname.replace(/^www\./, '');
      const pageHost = location.hostname.replace(/^www\./, '');
      diagnostics.canonicalCrossDomain = !!canonicalHost && canonicalHost !== pageHost;
    }
  } catch {}

  const headingNodes = Array.from(document.querySelectorAll('h1,h2,h3,h4,h5,h6')).map(node => ({
    level: Number(node.tagName.slice(1)),
    text: (node.textContent || '').replace(/\s+/g, ' ').trim()
  })).filter(node => node.text);
  diagnostics.h1Texts = headingNodes.filter(node => node.level === 1).map(node => node.text);
  diagnostics.h1Count = diagnostics.h1Texts.length;
  ['H1','H2','H3','H4','H5','H6'].forEach(level => { diagnostics.headingCounts[level] = 0; });
  headingNodes.forEach(node => {
    diagnostics.headingCounts[`H${node.level}`] = (diagnostics.headingCounts[`H${node.level}`] || 0) + 1;
    diagnostics.headingSequence.push(`H${node.level}: ${node.text}`);
  });
  for (let index = 1; index < headingNodes.length; index += 1) {
    if ((headingNodes[index].level - headingNodes[index - 1].level) > 1) diagnostics.headingSkips += 1;
  }

  const bodyText = (document.body?.innerText || '').replace(/\s+/g, ' ').trim();
  diagnostics.wordCount = bodyText ? bodyText.split(/\s+/).filter(word => /\w/.test(word)).length : 0;

  const weakPatterns = [/^click here$/i, /^read more$/i, /^learn more$/i, /^more$/i, /^here$/i, /^link$/i, /^view more$/i];
  Array.from(document.querySelectorAll('a[href]')).forEach(anchor => {
    const href = abs(anchor.getAttribute('href') || '');
    if (!href) return;
    let anchorHost = '';
    try { anchorHost = new URL(href).hostname.replace(/^www\./, ''); } catch {}
    const pageHost = location.hostname.replace(/^www\./, '');
    if (anchorHost === pageHost) diagnostics.internalLinks += 1;
    else diagnostics.externalLinks += 1;
    if ((anchor.getAttribute('rel') || '').toLowerCase().includes('nofollow')) diagnostics.nofollowLinks += 1;
    const anchorText = ((anchor.textContent || '').replace(/\s+/g, ' ').trim() || anchor.getAttribute('aria-label') || '').trim();
    if (!anchorText) diagnostics.emptyAnchorCount += 1;
    else if (weakPatterns.some(pattern => pattern.test(anchorText))) {
      diagnostics.weakAnchorCount += 1;
      if (diagnostics.weakAnchorSamples.length < 6) diagnostics.weakAnchorSamples.push(anchorText);
    }
  });

  const images = Array.from(document.querySelectorAll('img'));
  diagnostics.imgCount = images.length;
  diagnostics.imgMissingAlt = images.filter(image => !image.hasAttribute('alt') || String(image.getAttribute('alt')).trim() === '').length;

  Array.from(document.querySelectorAll('script[type="application/ld+json"]')).forEach(script => {
    try {
      const walk = (value) => {
        if (!value) return;
        if (Array.isArray(value)) return value.forEach(walk);
        if (typeof value !== 'object') return;
        if (Array.isArray(value['@graph'])) value['@graph'].forEach(walk);
        const types = value['@type'];
        if (typeof types === 'string') diagnostics.ldTypes.push(types);
        if (Array.isArray(types)) types.forEach(type => diagnostics.ldTypes.push(type));
      };
      walk(JSON.parse(script.textContent || 'null'));
    } catch {}
  });
  diagnostics.ldTypes = uniq(diagnostics.ldTypes);

  if (includeFetch) {
    const robotsUrl = `${location.origin.replace(/\/$/, '')}/robots.txt`;
    diagnostics.robotsTxt.url = robotsUrl;
    diagnostics.robotsTxt.checked = true;
    try {
      const response = await fetch(robotsUrl, { credentials: 'omit', cache: 'no-store' });
      diagnostics.robotsTxt.ok = response.ok;
      diagnostics.robotsTxt.status = response.status;
      const text = response.ok ? await response.text() : '';
      const sitemapEntries = text
        .split(/\r?\n/)
        .map(line => line.match(/^\s*sitemap:\s*(.+)$/i)?.[1]?.trim() || '')
        .filter(Boolean);
      diagnostics.sitemap.entries = uniq([...diagnostics.sitemap.entries, ...sitemapEntries]);
      diagnostics.sitemap.found = diagnostics.sitemap.entries.length > 0;
    } catch (error) {
      diagnostics.robotsTxt.error = String(error?.message || error);
    }
    diagnostics.sitemap.probeUrl = `${location.origin.replace(/\/$/, '')}/sitemap.xml`;
    if (!diagnostics.sitemap.found) {
      try {
        let response = await fetch(diagnostics.sitemap.probeUrl, { method: 'HEAD', credentials: 'omit', cache: 'no-store' });
        if (!response.ok || response.status === 405) response = await fetch(diagnostics.sitemap.probeUrl, { credentials: 'omit', cache: 'no-store' });
        if (response.ok) {
          diagnostics.sitemap.found = true;
          diagnostics.sitemap.entries = uniq([...diagnostics.sitemap.entries, diagnostics.sitemap.probeUrl]);
        }
      } catch {}
    }
  }

  if (includeTags) {
    const tagHits = [];
    const addHit = (vendor, { ids = [], evidence = [], confidence = 'medium', notes = [] } = {}) => {
      const cleanIds = uniq(ids.map(id => String(id).trim()).filter(Boolean));
      const cleanEvidence = uniq(evidence.map(item => String(item).trim()).filter(Boolean));
      const cleanNotes = uniq(notes.map(item => String(item).trim()).filter(Boolean));
      if (!cleanIds.length && !cleanEvidence.length) return;
      tagHits.push({ vendor, status: 'detected', ids: cleanIds, evidence: cleanEvidence, frame: frameLabel, confidence, notes: cleanNotes });
    };
    const hasUrl = (pattern) => urlSources.some(source => pattern.test(String(source)));
    const hasText = (pattern) => textSources.some(source => pattern.test(String(source)));
    const dataLayerDump = (() => { try { return JSON.stringify(window.dataLayer || []); } catch { return ''; } })();
    const gtmKeys = (() => { try { return Object.keys(window.google_tag_manager || {}); } catch { return []; } })();

    const gtmIds = uniq([
      ...collectMatches(allSources, /(GTM-[A-Z0-9]{4,})/i),
      ...gtmKeys.filter(key => /^GTM-[A-Z0-9]{4,}$/i.test(key))
    ]);
    const googleIds = uniq([
      ...collectMatches(allSources, /((?:G|AW|DC)-[A-Z0-9-]{4,})/i),
      ...collectMatches([dataLayerDump], /((?:G|AW|DC)-[A-Z0-9-]{4,})/i)
    ]);
    const metaIds = uniq([
      ...collectMatches(textSources, /fbq\s*\(\s*['"]init['"]\s*,\s*['"](\d{5,})['"]/i),
      ...collectMatches(allSources, /facebook\.com\/tr\?id=(\d{5,})/i)
    ]);
    const uetIds = uniq(collectMatches(allSources, /(?:\bti\s*[:=]\s*['"]?|\btagid['"]?\s*:\s*['"]?)(\d{5,})/i));
    const clarityIds = uniq(collectMatches(allSources, /clarity\.ms\/tag\/([a-z0-9]+)/i));
    const hotjarIds = uniq([
      ...collectMatches(allSources, /hotjar-(\d+)\.js/i),
      ...collectMatches(allSources, /\bhjid\s*[:=]\s*(\d+)/i)
    ]);
    const redditIds = uniq(collectMatches(allSources, /rdt\s*\(\s*['"]init['"]\s*,\s*['"]([a-zA-Z0-9_:-]+)['"]/i));
    const quoraIds = uniq(collectMatches(allSources, /qp\s*\(\s*['"]init['"]\s*,\s*['"]([a-zA-Z0-9_-]+)['"]/i));
    const linkedinIds = uniq(collectMatches(allSources, /_linkedin_partner_id\s*=\s*['"](\d+)['"]/i));
    const pinterestIds = uniq(collectMatches(allSources, /pintrk\s*\(\s*['"]load['"]\s*,\s*['"]([a-zA-Z0-9]+)['"]/i));
    const tiktokIds = uniq(collectMatches(allSources, /ttq\.load\(\s*['"]([a-zA-Z0-9]+)['"]/i));
    const twitterIds = uniq(collectMatches(allSources, /twq\s*\(\s*['"]config['"]\s*,\s*['"]([a-zA-Z0-9]+)['"]/i));
    const snapIds = uniq(collectMatches(allSources, /snaptr\s*\(\s*['"]init['"]\s*,\s*['"]([a-zA-Z0-9-]+)['"]/i));

    if (gtmIds.length || hasUrl(/googletagmanager\.com\/gtm\.js/i) || hasUrl(/googletagmanager\.com\/ns\.html/i)) {
      addHit('Google Tag Manager', { ids: gtmIds, evidence: ['script src', hasUrl(/googletagmanager\.com\/ns\.html/i) ? 'iframe' : ''].filter(Boolean), confidence: gtmIds.length ? 'high' : 'medium' });
    }
    if (googleIds.length || hasUrl(/googletagmanager\.com\/gtag\/js/i) || typeof window.gtag === 'function') {
      addHit('Google tag / gtag.js', {
        ids: googleIds,
        evidence: ['script src', typeof window.gtag === 'function' ? 'global object' : '', googleIds.length ? 'dataLayer' : ''].filter(Boolean),
        confidence: googleIds.length ? 'high' : 'medium'
      });
    }
    if (googleIds.some(id => /^G-/i.test(id))) addHit('GA4', { ids: googleIds.filter(id => /^G-/i.test(id)), evidence: ['script src', dataLayerDump ? 'dataLayer' : ''].filter(Boolean), confidence: 'high' });
    if (googleIds.some(id => /^AW-/i.test(id))) addHit('Google Ads', { ids: googleIds.filter(id => /^AW-/i.test(id)), evidence: ['script src', dataLayerDump ? 'dataLayer' : ''].filter(Boolean), confidence: 'high' });
    if (googleIds.some(id => /^DC-/i.test(id))) addHit('DoubleClick', { ids: googleIds.filter(id => /^DC-/i.test(id)), evidence: ['script src', dataLayerDump ? 'dataLayer' : ''].filter(Boolean), confidence: 'high' });
    if (metaIds.length || hasUrl(/connect\.facebook\.net\/.*fbevents\.js/i) || typeof window.fbq === 'function') {
      addHit('Meta Pixel', { ids: metaIds, evidence: ['script src', typeof window.fbq === 'function' ? 'global object' : '', hasText(/fbq\s*\(/i) ? 'inline init' : ''].filter(Boolean), confidence: metaIds.length ? 'high' : 'medium' });
    }
    if (uetIds.length || hasUrl(/bat\.bing\.com\/bat\.js/i) || typeof window.uetq !== 'undefined') {
      addHit('Microsoft Ads / UET', { ids: uetIds, evidence: ['script src', typeof window.uetq !== 'undefined' ? 'global object' : '', hasText(/UET\s*\(/i) ? 'inline init' : ''].filter(Boolean), confidence: uetIds.length ? 'high' : 'medium' });
    }
    if (clarityIds.length || hasUrl(/clarity\.ms\/tag\//i) || typeof window.clarity === 'function') {
      addHit('Microsoft Clarity', { ids: clarityIds, evidence: ['script src', typeof window.clarity === 'function' ? 'global object' : ''].filter(Boolean), confidence: clarityIds.length ? 'high' : 'medium' });
    }
    if (hotjarIds.length || hasUrl(/hotjar/i) || typeof window.hj === 'function') {
      addHit('Hotjar', { ids: hotjarIds, evidence: ['script src', typeof window.hj === 'function' ? 'global object' : '', hasText(/hjid/i) ? 'inline init' : ''].filter(Boolean), confidence: hotjarIds.length ? 'high' : 'medium' });
    }
    if (redditIds.length || hasUrl(/redditstatic\.com\/ads\/pixel/i) || typeof window.rdt === 'function') {
      addHit('Reddit Pixel', { ids: redditIds, evidence: ['script src', typeof window.rdt === 'function' ? 'global object' : '', hasText(/rdt\s*\(/i) ? 'inline init' : ''].filter(Boolean), confidence: redditIds.length ? 'high' : 'medium' });
    }
    if (quoraIds.length || hasUrl(/quora\.com\/qevents/i) || typeof window.qp === 'function') {
      addHit('Quora Pixel', { ids: quoraIds, evidence: ['script src', typeof window.qp === 'function' ? 'global object' : '', hasText(/qp\s*\(/i) ? 'inline init' : ''].filter(Boolean), confidence: quoraIds.length ? 'high' : 'medium' });
    }
    if (linkedinIds.length || hasUrl(/licdn\.com\/li\.lms-analytics\/insight/i)) {
      addHit('LinkedIn Insight', { ids: linkedinIds, evidence: ['script src', hasText(/linkedin_partner_id/i) ? 'inline init' : ''].filter(Boolean), confidence: linkedinIds.length ? 'high' : 'medium' });
    }
    if (pinterestIds.length || hasUrl(/s\.pinimg\.com\/ct\/core\.js/i) || typeof window.pintrk === 'function') {
      addHit('Pinterest', { ids: pinterestIds, evidence: ['script src', typeof window.pintrk === 'function' ? 'global object' : '', hasText(/pintrk\s*\(/i) ? 'inline init' : ''].filter(Boolean), confidence: pinterestIds.length ? 'high' : 'medium' });
    }
    if (tiktokIds.length || hasUrl(/analytics\.tiktok\.com/i) || typeof window.ttq === 'object') {
      addHit('TikTok', { ids: tiktokIds, evidence: ['script src', typeof window.ttq === 'object' ? 'global object' : '', hasText(/ttq\./i) ? 'inline init' : ''].filter(Boolean), confidence: tiktokIds.length ? 'high' : 'medium' });
    }
    if (twitterIds.length || hasUrl(/static\.ads-twitter\.com\/uwt\.js/i) || typeof window.twq === 'function') {
      addHit('X / Twitter', { ids: twitterIds, evidence: ['script src', typeof window.twq === 'function' ? 'global object' : '', hasText(/twq\s*\(/i) ? 'inline init' : ''].filter(Boolean), confidence: twitterIds.length ? 'high' : 'medium' });
    }
    if (snapIds.length || hasUrl(/sc-static\.net\/scevent\.min\.js/i) || typeof window.snaptr === 'function') {
      addHit('Snap', { ids: snapIds, evidence: ['script src', typeof window.snaptr === 'function' ? 'global object' : '', hasText(/snaptr\s*\(/i) ? 'inline init' : ''].filter(Boolean), confidence: snapIds.length ? 'high' : 'medium' });
    }

    const otherVendors = [];
    if (hasUrl(/segment\.com|cdn\.segment\.com/i)) otherVendors.push('Segment');
    if (hasUrl(/js\.agent\.rudderstack\.com|cdn\.rudderlabs\.com/i)) otherVendors.push('RudderStack');
    if (hasUrl(/taboola\.com/i)) otherVendors.push('Taboola');
    if (hasUrl(/outbrain\.com/i)) otherVendors.push('Outbrain');
    if (hasUrl(/adroll\.com/i)) otherVendors.push('AdRoll');
    if (hasUrl(/criteo\.com/i)) otherVendors.push('Criteo');
    if (otherVendors.length) {
      addHit('Other marketing tags', {
        ids: otherVendors,
        evidence: ['script src'],
        confidence: 'low',
        notes: ['Matched additional marketing or analytics vendor domains.']
      });
    }

    diagnostics.tags = tagHits;
  }

  return diagnostics;
}
async function runActivePageDiagnostics(options = {}, execOptions = {}){
  const tab = await getActiveTab();
  if (!tab || !/^https?:/i.test(tab.url || '')) throw new Error('Open a public page.');
  const params = {
    target: execOptions.allFrames ? { tabId: tab.id, allFrames: true } : { tabId: tab.id },
    func: collectActivePageDiagnostics,
    args: [options]
  };
  if (execOptions.world === 'MAIN') params.world = 'MAIN';
  const results = await chrome.scripting.executeScript(params);
  return { tab, results };
}
async function collectIndexingSupplement(inspectedUrl){
  const safe = normalizeUrl(inspectedUrl || '');
  const active = normalizeUrl(await getActiveTabUrl().catch(() => ''));
  if (!safe || !active || safe !== active) return null;
  const { results } = await runActivePageDiagnostics({ mode: 'supplement' });
  return results?.[0]?.result || null;
}
function setPanelLoadState(key, loading){
  if (!state?.ui?.panelLoads) return;
  state.ui.panelLoads[key] = !!loading;
  const buttonId = key === 'tags' ? 'runTags' : key === 'onPage' ? 'runOnPage' : key === 'structuredData' ? 'runStructuredData' : '';
  const button = buttonId ? $(buttonId) : null;
  if (button) button.disabled = !!loading;
}
async function runOnPageAudit({ reason='button' } = {}){
  if (state.ui.panelLoads.onPage) return false;
  setPanelLoadState('onPage', true);
  clearResult('Running audit…', 'onPageResult');
  try{
    const { results } = await runActivePageDiagnostics({ mode: 'onpage', includeFetch: true });
    renderOnPage(results?.[0]?.result || {});
    return true;
  }catch(err){
    clearResult('❌ ' + (err?.message || err), 'onPageResult');
    return false;
  }finally{
    setPanelLoadState('onPage', false);
  }
}
async function runTagsScan({ reason='button' } = {}){
  if (state.ui.panelLoads.tags) return false;
  setPanelLoadState('tags', true);
  clearResult('Scanning…', 'tagResult');
  try{
    const { results } = await runActivePageDiagnostics({ mode: 'tags', includeTags: true }, { allFrames: true, world: 'MAIN' });
    const frameResults = (results || []).map(entry => entry?.result).filter(Boolean);
    const aggregated = aggregateTagHits(frameResults);
    const host = (() => {
      try { return new URL(frameResults[0]?.url || '').hostname.replace(/^www\./, '') || 'Active page'; }
      catch { return 'Active page'; }
    })();
    renderTagAssistant(aggregated, {
      host,
      frameCount: frameResults.length,
      topFrameDetected: frameResults.some(entry => entry?.frame === 'top frame')
    });
    return true;
  }catch(err){
    clearResult('❌ ' + (err?.message || err), 'tagResult');
    return false;
  }finally{
    setPanelLoadState('tags', false);
  }
}
async function runStructuredDataScan({ reason='button' } = {}){
  if (state.ui.panelLoads.structuredData) return false;
  setPanelLoadState('structuredData', true);
  const tab = await getActiveTab().catch(() => null);
  if (!tab || !/^https?:/i.test(tab.url || '')) {
    setPanelLoadState('structuredData', false);
    clearResult('Open a public page.', 'structuredDataResult');
    return false;
  }
  clearResult('Scanning…', 'structuredDataResult');
  try{
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: extractStructuredDataFromPage
    });
    renderStructuredData(result || { url: tab.url || '', items: [], counts: {}, errors: [] });
    return true;
  }catch(err){
    clearResult('❌ ' + (err?.message || err), 'structuredDataResult');
    return false;
  }finally{
    setPanelLoadState('structuredData', false);
  }
}
function chooseBestProperty(sites, pageUrl){
  if(!Array.isArray(sites) || !pageUrl) return null;
  let best = null, bestScore = -1, bestLen = -1;
  let host = ''; try { host = new URL(pageUrl).hostname || ''; } catch{}
  for(const s of sites){
    const site = s.siteUrl; let covers = false, score = 0, len = site.length;
    if(site.startsWith('sc-domain:')){
      const domain = site.split(':')[1];
      if(host === domain || (host && host.endsWith('.'+domain))){ covers = true; score = 1; len = domain.length; }
    } else if(pageUrl.startsWith(site)){ covers = true; score = 2; len = site.length; }
    if(covers){ if(score > bestScore || (score === bestScore && len > bestLen)){ best = site; bestScore = score; bestLen = len; } }
  }
  return best;
}

/* ---------- Renderers ---------- */
function ms(v){ return typeof v==='number' ? `${(v/1000).toFixed(2)}s` : (v||'—'); }
function toTitleCase(value=''){
  return String(value || '')
    .toLowerCase()
    .replace(/\b\w/g, letter => letter.toUpperCase());
}
function humanizeInspectionValue(value){
  if (value == null || value === '') return '—';
  const key = String(value);
  const map = {
    PASS: 'Valid',
    FAIL: 'Issue detected',
    NEUTRAL: 'Excluded',
    PARTIAL: 'Partial',
    VERDICT_UNSPECIFIED: 'Unknown',
    ALLOWED: 'Allowed',
    DISALLOWED: 'Blocked',
    ROBOTS_TXT_STATE_UNSPECIFIED: 'Unknown',
    INDEXING_ALLOWED: 'Allowed',
    BLOCKED_BY_META_TAG: 'Blocked by meta noindex',
    BLOCKED_BY_HTTP_HEADER: 'Blocked by X-Robots-Tag',
    INDEXING_STATE_UNSPECIFIED: 'Unknown',
    SUCCESSFUL: 'Successful',
    SOFT_404: 'Soft 404',
    BLOCKED_ROBOTS_TXT: 'Blocked by robots.txt',
    NOT_FOUND: 'Not found (404)',
    ACCESS_DENIED: 'Unauthorized (401)',
    SERVER_ERROR: 'Server error (5xx)',
    REDIRECT_ERROR: 'Redirect error',
    ACCESS_FORBIDDEN: 'Forbidden (403)',
    BLOCKED_4XX: 'Blocked by 4xx',
    INTERNAL_CRAWL_ERROR: 'Internal crawl error',
    INVALID_URL: 'Invalid URL',
    PAGE_FETCH_STATE_UNSPECIFIED: 'Unknown',
    MOBILE: 'Googlebot smartphone',
    DESKTOP: 'Googlebot desktop',
    CRAWLING_USER_AGENT_UNSPECIFIED: 'Unknown crawler',
    WARNING: 'Warning',
    ERROR: 'Error'
  };
  if (map[key]) return map[key];
  return toTitleCase(key.replace(/_/g, ' '));
}
function formatInspectionDate(value){
  if (!value) return '—';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return escapeHtml(String(value));
  return escapeHtml(date.toLocaleString([], {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: 'numeric',
    minute: '2-digit'
  }));
}
function inspectionBadge(value){
  return stateBadge(humanizeInspectionValue(value));
}
function renderMaybeLink(value, label=''){
  if (!value) return '—';
  try{
    const url = new URL(String(value));
    const text = label || url.href;
    return `<a href="${escapeHtml(url.href)}" target="_blank" rel="noopener">${escapeHtml(text)}</a>`;
  }catch{
    return escapeHtml(String(value));
  }
}
function renderValueList(items, emptyLabel='Nothing detected'){
  if (!Array.isArray(items) || !items.length) return `<p class="inspection-empty">${escapeHtml(emptyLabel)}</p>`;
  return `
    <ul class="inspection-list">
      ${items.map(item => `<li>${renderMaybeLink(item)}</li>`).join('')}
    </ul>
  `;
}
function renderIssueList(issues, emptyLabel='No issues detected'){
  if (!Array.isArray(issues) || !issues.length) return `<p class="inspection-empty">${escapeHtml(emptyLabel)}</p>`;
  return `
    <div class="inspection-issues">
      ${issues.map(issue => `
        <div class="inspection-subcard">
          <div class="inspection-subcard__head">
            <strong>${escapeHtml(issue.issueType ? humanizeInspectionValue(issue.issueType) : (issue.name || 'Issue'))}</strong>
            ${issue.severity ? inspectionBadge(issue.severity) : ''}
          </div>
          <p>${escapeHtml(issue.message || issue.issueMessage || 'This item needs review.')}</p>
        </div>
      `).join('')}
    </div>
  `;
}
function renderRichResultGroups(detectedItems){
  if (!Array.isArray(detectedItems) || !detectedItems.length) {
    return `<p class="inspection-empty">No rich result items detected.</p>`;
  }
  return detectedItems.map(group => {
    const items = Array.isArray(group?.items) ? group.items : [];
    return `
      <div class="inspection-subcard">
        <div class="inspection-subcard__head">
          <strong>${escapeHtml(group.richResultType || 'Rich result')}</strong>
          <span class="badge">${items.length} item${items.length === 1 ? '' : 's'}</span>
        </div>
        ${items.length ? `
          <div class="inspection-issues">
            ${items.map(item => `
              <div class="inspection-subcard inspection-subcard--nested">
                <div class="inspection-subcard__head">
                  <strong>${escapeHtml(item.name || 'Unnamed item')}</strong>
                  <span class="badge">${Array.isArray(item.issues) ? item.issues.length : 0} issue${(item.issues || []).length === 1 ? '' : 's'}</span>
                </div>
                ${renderIssueList(item.issues || [], 'This item has no rich result issues.')}
              </div>
            `).join('')}
          </div>
        ` : `<p class="inspection-empty">No individual items were listed for this rich result type.</p>`}
      </div>
    `;
  }).join('');
}
function auditStatusLabel(status){
  const map = { pass: 'Pass', warning: 'Warning', error: 'Error', info: 'Info' };
  return map[status] || 'Info';
}
function auditStatusClass(status){
  if (status === 'pass') return 'good';
  if (status === 'warning') return 'ok';
  if (status === 'error') return 'bad';
  return '';
}
function createAuditCheck(section, key, status, label, summary, value='', tips=[], details=''){
  return { section, key, status, label, summary, value, tips, details };
}
function summarizeAuditChecks(checks){
  return checks.reduce((acc, check) => {
    acc[check.status] = (acc[check.status] || 0) + 1;
    return acc;
  }, { pass: 0, warning: 0, error: 0, info: 0 });
}
function renderAuditCheck(check){
  const details = Array.isArray(check.details) ? check.details.filter(Boolean) : [check.details].filter(Boolean);
  const tips = Array.isArray(check.tips) ? check.tips.filter(Boolean) : [];
  return `
    <article class="audit-check">
      <div class="audit-check__head">
        <div>
          <strong>${escapeHtml(check.label)}</strong>
          <p>${escapeHtml(check.summary)}</p>
        </div>
        ${badge(auditStatusLabel(check.status), auditStatusClass(check.status))}
      </div>
      ${check.value ? `<div class="audit-check__value">${escapeHtml(String(check.value))}</div>` : ''}
      ${details.length ? `
        <ul class="audit-detail-list">
          ${details.map(detail => `<li>${escapeHtml(String(detail))}</li>`).join('')}
        </ul>
      ` : ''}
      ${tips.length ? `
        <ul class="audit-tip-list">
          ${tips.map(tip => `<li>${escapeHtml(String(tip))}</li>`).join('')}
        </ul>
      ` : ''}
    </article>
  `;
}
function renderIndexing(data){
  const inspection = data?.inspectionResult || data;
  if (!inspection) return clearResult('No data returned.', 'indexResult');

  const idx = inspection.indexStatusResult || {};
  const rich = inspection.richResultsResult || {};
  const mobile = inspection.mobileUsabilityResult || null;
  const livePage = data?.livePage || null;
  const sitemaps = Array.isArray(idx.sitemap) ? idx.sitemap : [];
  const referringUrls = Array.isArray(idx.referringUrls) ? idx.referringUrls : [];
  const richGroups = Array.isArray(rich.detectedItems) ? rich.detectedItems : [];
  const richItemCount = richGroups.reduce((sum, group) => sum + ((group?.items || []).length), 0);
  const mobileIssues = Array.isArray(mobile?.issues) ? mobile.issues : [];
  const cards = [];

  cards.push(`
    <div class="card summary-card">
      <div class="summary-card__header">
        <div>
          <h4>Page indexing</h4>
          <p>Selected URL.</p>
        </div>
        ${inspectionBadge(idx.verdict || 'VERDICT_UNSPECIFIED')}
      </div>
      <div class="meta-line">
        <span class="badge">${escapeHtml(idx.coverageState || 'Coverage unknown')}</span>
        <span class="badge">${escapeHtml(humanizeInspectionValue(idx.pageFetchState || 'PAGE_FETCH_STATE_UNSPECIFIED'))}</span>
        <span class="badge">${escapeHtml(humanizeInspectionValue(idx.crawledAs || 'CRAWLING_USER_AGENT_UNSPECIFIED'))}</span>
      </div>
      <div class="metric-strip">
        <div class="metric-tile"><span>Sitemaps</span><strong>${sitemaps.length.toLocaleString()}</strong></div>
        <div class="metric-tile"><span>Referring URLs</span><strong>${referringUrls.length.toLocaleString()}</strong></div>
        <div class="metric-tile"><span>Rich result items</span><strong>${richItemCount.toLocaleString()}</strong></div>
        <div class="metric-tile"><span>Mobile issues</span><strong>${mobileIssues.length.toLocaleString()}</strong></div>
      </div>
      ${inspection.inspectionResultLink ? `
        <div class="sd-actions">
          <a class="chip chip--accent" href="${escapeHtml(inspection.inspectionResultLink)}" target="_blank" rel="noopener">Open in GSC</a>
        </div>
      ` : ''}
    </div>
  `);

  cards.push(`
    <div class="card">
      <div class="summary-card__header">
        <div>
          <h4>Discovery</h4>
          <p>Known sources.</p>
        </div>
        <span class="badge">${(sitemaps.length + referringUrls.length).toLocaleString()} sources</span>
      </div>
      <div class="inspection-grid">
        <div>
          <h5>Sitemaps</h5>
          ${renderValueList(sitemaps, 'No sitemaps found.')}
        </div>
        <div>
          <h5>Referring pages</h5>
          ${renderValueList(referringUrls, 'No referring pages.')}
        </div>
      </div>
    </div>
  `);

  cards.push(`
    <div class="card">
      <div class="summary-card__header">
        <div>
          <h4>Crawl</h4>
          <p>Fetch and crawl.</p>
        </div>
        ${inspectionBadge(idx.pageFetchState || 'PAGE_FETCH_STATE_UNSPECIFIED')}
      </div>
      ${kv('Last crawl', formatInspectionDate(idx.lastCrawlTime))}
      ${kv('Crawled as', escapeHtml(humanizeInspectionValue(idx.crawledAs || 'CRAWLING_USER_AGENT_UNSPECIFIED')))}
      ${kv('Crawl allowed?', escapeHtml(humanizeInspectionValue(idx.robotsTxtState || 'ROBOTS_TXT_STATE_UNSPECIFIED')))}
      ${kv('Page fetch', escapeHtml(humanizeInspectionValue(idx.pageFetchState || 'PAGE_FETCH_STATE_UNSPECIFIED')))}
      ${kv('Indexing allowed?', escapeHtml(humanizeInspectionValue(idx.indexingState || 'INDEXING_STATE_UNSPECIFIED')))}
      ${kv('Coverage state', escapeHtml(idx.coverageState || '—'))}
    </div>
  `);

  cards.push(`
    <div class="card">
      <div class="summary-card__header">
        <div>
          <h4>Indexing</h4>
          <p>Canonical and index state.</p>
        </div>
        ${inspectionBadge(idx.indexingState || 'INDEXING_STATE_UNSPECIFIED')}
      </div>
      ${kv('User-declared canonical', idx.userCanonical ? renderMaybeLink(idx.userCanonical) : '—')}
      ${kv('Google-selected canonical', idx.googleCanonical ? renderMaybeLink(idx.googleCanonical) : '—')}
      ${kv('Inspection verdict', escapeHtml(humanizeInspectionValue(idx.verdict || 'VERDICT_UNSPECIFIED')))}
      ${kv('Indexing state', escapeHtml(humanizeInspectionValue(idx.indexingState || 'INDEXING_STATE_UNSPECIFIED')))}
    </div>
  `);

  cards.push(`
    <div class="card">
      <div class="summary-card__header">
        <div>
          <h4>Rich results</h4>
          <p>Detected items.</p>
        </div>
        ${inspectionBadge(rich.verdict || 'VERDICT_UNSPECIFIED')}
      </div>
      ${renderRichResultGroups(richGroups)}
    </div>
  `);

  if (mobile) {
    cards.push(`
      <div class="card">
        <div class="summary-card__header">
          <div>
            <h4>Mobile usability</h4>
            <p>Returned by Search Console.</p>
          </div>
          ${inspectionBadge(mobile.verdict || 'VERDICT_UNSPECIFIED')}
        </div>
        ${renderIssueList(mobileIssues, 'No mobile usability issues were returned for this page.')}
      </div>
    `);
  }

  if (livePage) {
    const robotsState = livePage.robotsMeta ? livePage.robotsMeta : 'None';
    cards.push(`
      <div class="card">
        <div class="summary-card__header">
          <div>
            <h4>Live page supplement</h4>
            <p>Current tab only.</p>
          </div>
          ${badge(livePage.protocol === 'https:' ? 'HTTPS' : 'HTTP', livePage.protocol === 'https:' ? 'good' : 'bad')}
        </div>
        ${kv('Protocol', escapeHtml((livePage.protocol || '—').replace(':', '').toUpperCase()))}
        ${kv('Meta robots', escapeHtml(robotsState))}
        ${kv('Canonical tag', livePage.canonical ? renderMaybeLink(livePage.canonical) : 'None')}
        ${kv('Canonical cross-domain?', escapeHtml(livePage.canonicalCrossDomain ? 'Yes' : 'No'))}
        ${kv('Language', escapeHtml(livePage.language || 'Missing'))}
      </div>
    `);
  }

  renderHtml('indexResult', cards.join(''));
}


function aggregateTagHits(frameResults){
  const rank = { low: 1, medium: 2, high: 3 };
  const items = new Map();

  (frameResults || []).forEach(frameResult => {
    (frameResult?.tags || []).forEach(hit => {
      const vendor = hit.vendor || 'Unknown tag';
      if (!items.has(vendor)) {
        items.set(vendor, {
          vendor,
          status: hit.status || 'detected',
          ids: new Set(),
          evidence: new Set(),
          frames: new Set(),
          notes: new Set(),
          confidence: hit.confidence || 'low'
        });
      }
      const entry = items.get(vendor);
      (hit.ids || []).forEach(id => entry.ids.add(id));
      (hit.evidence || []).forEach(ev => entry.evidence.add(ev));
      if (hit.frame) entry.frames.add(hit.frame);
      (hit.notes || []).forEach(note => entry.notes.add(note));
      if ((rank[hit.confidence] || 0) > (rank[entry.confidence] || 0)) entry.confidence = hit.confidence;
    });
  });

  const hasGtm = items.has('Google Tag Manager');
  const directEvidence = new Set(['inline init', 'global object', 'dataLayer']);

  return Array.from(items.values()).map(entry => {
    const evidence = Array.from(entry.evidence);
    const notes = Array.from(entry.notes);
    if (hasGtm && entry.vendor !== 'Google Tag Manager' && !evidence.some(item => directEvidence.has(item))) {
      notes.push('Could be deployed through GTM or another tag manager.');
      if (entry.confidence === 'high') entry.confidence = 'medium';
    }
    if (!entry.ids.size && entry.confidence === 'high') entry.confidence = 'medium';
    return {
      vendor: entry.vendor,
      status: entry.status,
      ids: Array.from(entry.ids),
      evidence,
      frame: Array.from(entry.frames).join(', '),
      confidence: entry.confidence,
      notes: Array.from(new Set(notes))
    };
  }).sort((a, b) => a.vendor.localeCompare(b.vendor));
}
function renderTagAssistant(items, meta={}){
  const vendorCount = items.length;
  const idCount = items.reduce((sum, item) => sum + (item.ids?.length || 0), 0);
  const cards = [`
    <div class="card summary-card">
      <div class="summary-card__header">
        <div>
          <h4>Tag Assistant</h4>
          <p>Active page and frames.</p>
        </div>
        <span class="badge">${escapeHtml(meta.host || 'Active page')}</span>
      </div>
      <div class="metric-strip">
        <div class="metric-tile"><span>Vendors</span><strong>${vendorCount.toLocaleString()}</strong></div>
        <div class="metric-tile"><span>IDs found</span><strong>${idCount.toLocaleString()}</strong></div>
        <div class="metric-tile"><span>Frames scanned</span><strong>${Number(meta.frameCount || 0).toLocaleString()}</strong></div>
        <div class="metric-tile"><span>Top frame</span><strong>${meta.topFrameDetected ? 'Yes' : 'No'}</strong></div>
      </div>
    </div>
  `];

  if (!items.length) {
    cards.push(`
      <div class="card">
        <h4>No tags found</h4>
        <p>No supported tags found.</p>
      </div>
    `);
    return renderHtml('tagResult', cards.join(''));
  }

  items.forEach(item => {
    cards.push(`
      <article class="card tag-card">
        <div class="summary-card__header">
          <div>
            <h4>${escapeHtml(item.vendor)}</h4>
            <p>${item.frame ? escapeHtml(item.frame) : 'Active page.'}</p>
          </div>
          ${badge(toTitleCase(item.confidence || 'medium'), item.confidence === 'high' ? 'good' : item.confidence === 'medium' ? 'ok' : 'bad')}
        </div>
        <div class="tag-meta">
          <div>
            <span>IDs</span>
            <div class="tag-chip-row">
              ${(item.ids || []).length ? item.ids.map(id => `<span class="chip chip--accent">${escapeHtml(id)}</span>`).join('') : '<span class="chip">No ID</span>'}
            </div>
          </div>
          <div>
            <span>Evidence</span>
            <div class="tag-chip-row">
              ${(item.evidence || []).length ? item.evidence.map(evidence => `<span class="chip">${escapeHtml(evidence)}</span>`).join('') : '<span class="chip">No evidence</span>'}
            </div>
          </div>
          ${item.notes?.length ? `
            <div>
              <span>Notes</span>
              <ul class="audit-tip-list">
                ${item.notes.map(note => `<li>${escapeHtml(note)}</li>`).join('')}
              </ul>
            </div>
          ` : ''}
        </div>
      </article>
    `);
  });

  renderHtml('tagResult', cards.join(''));
}

function gscHasRows(report){
  return !!(report && Array.isArray(report.rows) && report.rows.length);
}
function gscSummaryRow(report){
  return (gscHasRows(report) ? report.rows[0] : null) || { clicks:0, impressions:0, ctr:0, position:0 };
}
function gscBreakdownLabel(dimension){
  return dimension === 'page' ? 'Page' : 'Query';
}
function renderPerf(bundle, meta, prevSummary){
  const row = gscSummaryRow(bundle?.summary);
  const prevRow = prevSummary ? gscSummaryRow(prevSummary) : null;
  const scopeLabel = meta.wholeProperty ? 'Whole property' : 'This page';
  const dateLabel = `${meta.start} → ${meta.end}`;
  const breakdownRows = gscHasRows(bundle?.breakdown) ? bundle.breakdown.rows.slice(0, 8) : [];
  const breakdownLabel = gscBreakdownLabel(meta.breakdownDim);
  const clickSeries = gscHasRows(bundle?.trend) ? bundle.trend.rows.map(entry => Number(entry.clicks || 0)) : [];
  const impressionSeries = gscHasRows(bundle?.trend) ? bundle.trend.rows.map(entry => Number(entry.impressions || 0)) : [];
  const sparklineValues = clickSeries.some(value => value > 0) ? clickSeries : impressionSeries;

  renderHtml('perfResult', buildInsightStage({
    eyebrow: 'Search Console',
    title: 'Performance',
    rangeLabel: dateLabel,
    subtitle: meta.wholeProperty ? 'Property-level search visibility.' : 'Page-level search visibility.',
    badges: [scopeLabel, `Breakdown: ${breakdownLabel}`],
    kpis: [
      {
        label: 'Clicks',
        value: formatMetricValue(row.clicks),
        delta: metricDelta(row.clicks, prevRow?.clicks)
      },
      {
        label: 'Impressions',
        value: formatMetricValue(row.impressions),
        delta: metricDelta(row.impressions, prevRow?.impressions)
      },
      {
        label: 'CTR',
        value: formatMetricValue(row.ctr, 'percent', 2),
        delta: metricDelta(row.ctr, prevRow?.ctr)
      },
      {
        label: 'Avg position',
        value: formatMetricValue(row.position, 'decimal', 2),
        delta: metricDelta(row.position, prevRow?.position, { inverse:true })
      }
    ],
    sparklineValues,
    sparklineLabel: sparklineValues.length ? (clickSeries.some(value => value > 0) ? 'Clicks over time' : 'Impressions over time') : '',
    tableSections: breakdownRows.length ? [{
      title: `Top ${breakdownLabel.toLowerCase()}${breakdownRows.length === 1 ? '' : 's'}`,
      columns: [
        { label: breakdownLabel },
        { label: 'Clicks', numeric:true },
        { label: 'Impressions', numeric:true },
        { label: 'CTR', numeric:true },
        { label: 'Position', numeric:true }
      ],
      rows: breakdownRows.map(entry => [
        entry.keys?.[0] || '—',
        formatMetricValue(entry.clicks),
        formatMetricValue(entry.impressions),
        formatMetricValue(entry.ctr, 'percent', 2),
        formatMetricValue(entry.position, 'decimal', 2)
      ])
    }] : [],
    barSections: breakdownRows.length ? [{
      title: `Clicks by top ${breakdownLabel.toLowerCase()}${breakdownRows.length === 1 ? '' : 's'}`,
      items: breakdownRows.map(entry => ({
        label: entry.keys?.[0] || '—',
        value: Number(entry.clicks || 0),
        displayValue: formatMetricValue(entry.clicks)
      }))
    }] : []
  }));
}
function buildOnPageChecks(d){
  const checks = [];
  const add = (section, key, status, label, summary, value='', tips=[], details='') => {
    checks.push(createAuditCheck(section, key, status, label, summary, value, tips, details));
  };

  const title = (d.title || '').trim();
  const titleLength = title.length;
  if (!titleLength) add('URL & snippet', 'title', 'error', 'Title tag', 'The page is missing a title tag.', '', ['Add a unique title tag that targets the primary topic of the page.']);
  else if (titleLength < 15 || titleLength > 65) add('URL & snippet', 'title', 'warning', 'Title tag', `Title length is ${titleLength} characters.`, title, ['Keep titles descriptive and usually within 15-65 characters to avoid truncation or weak relevance.']);
  else add('URL & snippet', 'title', 'pass', 'Title tag', `Title length looks healthy at ${titleLength} characters.`, title);

  const metaDesc = (d.metaDesc || '').trim();
  const metaLength = metaDesc.length;
  if (!metaLength) add('URL & snippet', 'meta-description', 'error', 'Meta description', 'No meta description was found.', '', ['Add a compelling meta description so search snippets have stronger copy to pull from.']);
  else if (metaLength < 70 || metaLength > 160) add('URL & snippet', 'meta-description', 'warning', 'Meta description', `Meta description length is ${metaLength} characters.`, metaDesc, ['Aim for concise descriptions that usually land between 70 and 160 characters.']);
  else add('URL & snippet', 'meta-description', 'pass', 'Meta description', `Meta description length looks solid at ${metaLength} characters.`, metaDesc);

  const urlLength = String(d.url || '').length;
  add('URL & snippet', 'url-length', urlLength > 115 ? 'warning' : 'pass', 'URL length', `The inspected URL is ${urlLength} characters long.`, d.url || '', urlLength > 115 ? ['Shorter URLs are often easier to crawl, share, and read in SERPs.'] : []);

  add('Indexability', 'protocol', d.protocol === 'https:' ? 'pass' : 'error', 'HTTPS', d.protocol === 'https:' ? 'The page is served over HTTPS.' : 'The page is not served over HTTPS.', (d.protocol || '').replace(':', '').toUpperCase(), d.protocol === 'https:' ? [] : ['Serve the page over HTTPS so users and crawlers receive the secure canonical version.']);

  if (d.robotsTxt?.checked) {
    add(
      'Indexability',
      'robots-txt',
      d.robotsTxt.ok ? 'pass' : 'warning',
      'Robots.txt',
      d.robotsTxt.ok ? 'Robots.txt responded successfully.' : 'Robots.txt could not be confirmed from the active page context.',
      d.robotsTxt.url || '',
      d.robotsTxt.ok ? [] : ['Verify that robots.txt is reachable and not blocked by security tooling.'],
      d.robotsTxt.ok ? [`HTTP ${d.robotsTxt.status || 200}`] : [d.robotsTxt.error || `HTTP ${d.robotsTxt.status || 'unknown'}`]
    );
  }

  add(
    'Indexability',
    'sitemap',
    d.sitemap?.found ? 'pass' : 'warning',
    'XML sitemap',
    d.sitemap?.found ? 'At least one sitemap URL was discovered for this origin.' : 'No sitemap reference was confirmed from robots.txt or /sitemap.xml.',
    (d.sitemap?.entries || []).join(', '),
    d.sitemap?.found ? [] : ['Reference your XML sitemap in robots.txt and make sure /sitemap.xml or the preferred sitemap index is reachable.'],
    d.sitemap?.entries?.length ? d.sitemap.entries : (d.sitemap?.probeUrl ? [d.sitemap.probeUrl] : [])
  );

  const robotsMeta = String(d.robotsMeta || '').trim().toLowerCase();
  if (!robotsMeta) add('Canonicals & robots', 'robots-meta', 'pass', 'Robots meta', 'No blocking robots meta tag was found.', 'None');
  else if (robotsMeta.includes('noindex')) add('Canonicals & robots', 'robots-meta', 'error', 'Robots meta', 'A noindex directive is present in the robots meta tag.', robotsMeta, ['Remove the noindex directive if this page should be indexable.']);
  else add('Canonicals & robots', 'robots-meta', 'pass', 'Robots meta', 'Robots meta exists and does not contain noindex.', robotsMeta);

  if (!d.canonical) add('Canonicals & robots', 'canonical', 'warning', 'Canonical tag', 'No canonical tag was found on the page.', '', ['Add a self-referencing canonical when the URL should rank on its own.']);
  else if (d.canonicalCrossDomain) add('Canonicals & robots', 'canonical', 'warning', 'Canonical tag', 'The canonical points to a different hostname.', d.canonical, ['Confirm this cross-domain canonical is intentional and not consolidating the page away accidentally.']);
  else add('Canonicals & robots', 'canonical', 'pass', 'Canonical tag', 'A canonical tag was found on the same hostname.', d.canonical);

  const h1Count = Number(d.h1Count || 0);
  if (h1Count === 1) add('Headings & content', 'h1-count', 'pass', 'H1 usage', 'Exactly one H1 was found.', `${h1Count}`, [], d.h1Texts?.slice(0, 3) || []);
  else if (h1Count === 0) add('Headings & content', 'h1-count', 'error', 'H1 usage', 'No H1 heading was found.', '0', ['Add one clear H1 that matches the page topic.']);
  else add('Headings & content', 'h1-count', 'warning', 'H1 usage', `${h1Count} H1 headings were found.`, `${h1Count}`, ['Use one primary H1 unless the page has a deliberate component-driven structure.'], d.h1Texts?.slice(0, 4) || []);

  const headingCounts = d.headingCounts || {};
  const headingSummary = ['H1','H2','H3','H4','H5','H6'].map(level => `${level}: ${headingCounts[level] || 0}`).join(', ');
  add(
    'Headings & content',
    'heading-structure',
    Number(d.headingSkips || 0) > 0 ? 'warning' : 'pass',
    'Heading structure',
    Number(d.headingSkips || 0) > 0 ? 'Heading levels appear to skip in one or more places.' : 'Heading levels are sequential based on the visible outline.',
    headingSummary,
    Number(d.headingSkips || 0) > 0 ? ['Keep heading levels nested logically so screen readers and crawlers see a clean outline.'] : [],
    Array.isArray(d.headingSequence) ? d.headingSequence.slice(0, 8) : []
  );

  if (Number(d.wordCount || 0) < 150) add('Headings & content', 'word-count', Number(d.wordCount || 0) < 60 ? 'error' : 'warning', 'Content depth', `Approximate body copy count is ${Number(d.wordCount || 0).toLocaleString()} words.`, `${Number(d.wordCount || 0).toLocaleString()} words`, ['Thin pages often need more unique supporting copy unless the page purpose is intentionally minimal.']);
  else add('Headings & content', 'word-count', 'pass', 'Content depth', `Approximate body copy count is ${Number(d.wordCount || 0).toLocaleString()} words.`, `${Number(d.wordCount || 0).toLocaleString()} words`);

  const altMissing = Number(d.imgMissingAlt || 0);
  const imgCount = Number(d.imgCount || 0);
  if (!imgCount) add('Images', 'image-count', 'info', 'Images', 'No images were detected on the page.', '0 images');
  else {
    const missingRatio = imgCount ? altMissing / imgCount : 0;
    const status = altMissing === 0 ? 'pass' : missingRatio > 0.2 ? 'error' : 'warning';
    add('Images', 'alt-text', status, 'Image alt coverage', `${altMissing} of ${imgCount} images are missing alt text.`, `${imgCount - altMissing}/${imgCount} with alt`, altMissing ? ['Add concise descriptive alt text for informative images and empty alt text for decorative images.'] : []);
  }

  add('Links', 'link-balance', Number(d.internalLinks || 0) > 0 ? 'pass' : 'warning', 'Internal links', `Found ${Number(d.internalLinks || 0).toLocaleString()} internal links and ${Number(d.externalLinks || 0).toLocaleString()} external links.`, `${Number(d.internalLinks || 0)} internal / ${Number(d.externalLinks || 0)} external`, Number(d.internalLinks || 0) > 0 ? [] : ['Add relevant internal links so crawlers and users can move through related content.']);
  add('Links', 'nofollow-links', 'info', 'Nofollow links', `Found ${Number(d.nofollowLinks || 0).toLocaleString()} nofollow links on the page.`, `${Number(d.nofollowLinks || 0)}`);
  if (Number(d.weakAnchorCount || 0) > 0 || Number(d.emptyAnchorCount || 0) > 0) {
    add('Links', 'anchor-quality', 'warning', 'Anchor text quality', 'Some anchors are empty or use generic text.', `${Number(d.weakAnchorCount || 0)} generic / ${Number(d.emptyAnchorCount || 0)} empty`, ['Replace weak anchors like "click here" or empty links with descriptive anchor text.'], (d.weakAnchorSamples || []).slice(0, 4));
  } else {
    add('Links', 'anchor-quality', 'pass', 'Anchor text quality', 'No empty or weak anchor text samples were detected.', 'Looks healthy');
  }

  add('Structured data & social meta', 'structured-data', (d.ldTypes || []).length ? 'pass' : 'info', 'Structured data', (d.ldTypes || []).length ? 'Structured data types were detected in JSON-LD.' : 'No JSON-LD structured data types were detected.', (d.ldTypes || []).join(', ') || 'None');
  add('Structured data & social meta', 'open-graph', d.openGraph?.title && d.openGraph?.description && d.openGraph?.image ? 'pass' : 'warning', 'Open Graph', d.openGraph?.title && d.openGraph?.description && d.openGraph?.image ? 'Core Open Graph tags are present.' : 'Open Graph coverage is incomplete.', [d.openGraph?.type || '', d.openGraph?.title || '', d.openGraph?.image || ''].filter(Boolean).join(' | '), d.openGraph?.title && d.openGraph?.description && d.openGraph?.image ? [] : ['Add og:title, og:description, and og:image so link previews stay consistent.']);
  add('Structured data & social meta', 'twitter-card', d.twitterCard?.card ? 'pass' : 'warning', 'Twitter card', d.twitterCard?.card ? 'A Twitter card declaration was found.' : 'No Twitter card declaration was found.', d.twitterCard?.card || 'None', d.twitterCard?.card ? [] : ['Add twitter:card and supporting tags if social previews on X/Twitter matter for this page.']);

  add('Mobile & compliance', 'viewport', d.viewport ? 'pass' : 'error', 'Viewport meta', d.viewport ? 'Viewport meta tag is present.' : 'Viewport meta tag is missing.', d.viewport || 'Missing', d.viewport ? [] : ['Add a responsive viewport meta tag so mobile browsers render the page correctly.']);
  add('Mobile & compliance', 'language', d.language ? 'pass' : 'warning', 'Language declaration', d.language ? 'The html lang attribute is present.' : 'No html lang attribute was found.', d.language || 'Missing', d.language ? [] : ['Add a lang attribute on the html element to help search engines and assistive tech.']);
  add('Mobile & compliance', 'charset', d.charset ? 'pass' : 'warning', 'Charset', d.charset ? 'A character encoding declaration was found.' : 'No character encoding declaration was found.', d.charset || 'Missing', d.charset ? [] : ['Declare a charset such as UTF-8 to avoid rendering ambiguity.']);
  add('Mobile & compliance', 'doctype', d.doctype && /html/i.test(d.doctype) ? 'pass' : 'warning', 'Doctype', d.doctype ? 'A doctype declaration is present.' : 'No doctype declaration was found.', d.doctype || 'Missing');
  add('Mobile & compliance', 'iframes', Number(d.iframeCount || 0) > 3 ? 'warning' : 'info', 'Iframes', `Found ${Number(d.iframeCount || 0).toLocaleString()} iframe${Number(d.iframeCount || 0) === 1 ? '' : 's'} on the page.`, `${Number(d.iframeCount || 0)}`, Number(d.iframeCount || 0) > 3 ? ['Review iframes carefully because heavy embed usage can affect rendering, crawl clarity, and performance.'] : []);

  return checks;
}
function renderOnPage(d){
  const checks = buildOnPageChecks(d);
  const totals = summarizeAuditChecks(checks);
  const groups = checks.reduce((acc, check) => {
    if (!acc[check.section]) acc[check.section] = [];
    acc[check.section].push(check);
    return acc;
  }, {});
  let hostLabel = 'Active page';
  try{ hostLabel = new URL(d.url || 'https://example.com').hostname.replace(/^www\./,'') || 'Active page'; }catch{}

  const cards = [`
    <div class="card summary-card">
      <div class="summary-card__header">
        <div>
          <h4>On-page audit</h4>
          <p>Active page.</p>
        </div>
        <span class="badge">${escapeHtml(hostLabel)}</span>
      </div>
      <div class="metric-strip">
        <div class="metric-tile"><span>Pass</span><strong>${Number(totals.pass || 0).toLocaleString()}</strong></div>
        <div class="metric-tile"><span>Warning</span><strong>${Number(totals.warning || 0).toLocaleString()}</strong></div>
        <div class="metric-tile"><span>Error</span><strong>${Number(totals.error || 0).toLocaleString()}</strong></div>
        <div class="metric-tile"><span>Info</span><strong>${Number(totals.info || 0).toLocaleString()}</strong></div>
      </div>
    </div>
  `];

  Object.entries(groups).forEach(([section, items]) => {
    cards.push(`
      <div class="card audit-group">
        <div class="summary-card__header">
          <div>
            <h4>${escapeHtml(section)}</h4>
            <p>${items.length} check${items.length === 1 ? '' : 's'}.</p>
          </div>
          <span class="badge">${items.length}</span>
        </div>
        <div class="audit-group__body">
          ${items.map(renderAuditCheck).join('')}
        </div>
      </div>
    `);
  });

  renderHtml('onPageResult', cards.join(''));
}


function formatStructuredDate(value){
  if (!value) return '—';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return escapeHtml(String(value));
  return escapeHtml(date.toLocaleDateString([], {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  }));
}
function safeStructuredUrl(url){
  if (!url) return '';
  try{
    return new URL(url).href;
  }catch{
    return '';
  }
}
function extractStringList(value, limit=4){
  const list = [];
  const push = (item)=>{
    if (item == null) return;
    if (typeof item === 'string'){
      const trimmed = item.trim();
      if (trimmed) list.push(trimmed);
      return;
    }
    if (Array.isArray(item)) return item.forEach(push);
    if (typeof item === 'object'){
      if (typeof item.name === 'string' && item.name.trim()) list.push(item.name.trim());
      else if (typeof item['@id'] === 'string' && item['@id'].trim()) list.push(item['@id'].trim());
    }
  };
  push(value);
  return Array.from(new Set(list)).slice(0, limit);
}
function pickStructuredTitle(item){
  return item?.name || item?.headline || (item?.questionCount ? `${item.questionCount} questions` : '') || item?.path || item?.typeLabel || 'Structured data item';
}
function formatMaybeLink(value){
  const safe = safeStructuredUrl(value);
  if (!safe) return escapeHtml(value || '—');
  return `<a href="${escapeHtml(safe)}" target="_blank" rel="noopener">${escapeHtml(safe)}</a>`;
}
function structuredField(label, value){
  if (value == null || value === '' || (Array.isArray(value) && !value.length)) return '';
  const rendered = Array.isArray(value)
    ? value.map(v => {
        const safe = safeStructuredUrl(v);
        return `<span class="chip">${safe ? `<a href="${escapeHtml(safe)}" target="_blank" rel="noopener">${escapeHtml(v)}</a>` : escapeHtml(String(v))}</span>`;
      }).join(' ')
    : value;
  return `<div class="sd-detail"><span>${escapeHtml(label)}</span><strong>${rendered}</strong></div>`;
}
function renderStructuredPreview(item){
  const types = item.types || [];
  const typeSet = new Set(types.map(v => String(v || '').toLowerCase()));
  if (typeSet.has('product')){
    const price = item.price ? `${escapeHtml(item.price)}${item.priceCurrency ? ` ${escapeHtml(item.priceCurrency)}` : ''}` : '';
    return `
      <div class="sd-preview sd-preview--product">
        ${item.image ? `<img src="${escapeHtml(item.image)}" alt="" class="sd-preview__image" />` : `<div class="sd-preview__image sd-preview__image--placeholder">Product</div>`}
        <div class="sd-preview__body">
          <div class="sd-preview__eyebrow">Product</div>
          <h5>${escapeHtml(item.name || 'Untitled product')}</h5>
          ${item.brand ? `<p>${escapeHtml(item.brand)}</p>` : ''}
          <div class="sd-preview__meta">
            ${price ? `<span class="chip chip--accent">${price}</span>` : ''}
            ${item.availability ? `<span class="chip">${escapeHtml(item.availability)}</span>` : ''}
            ${item.ratingValue ? `<span class="chip">★ ${escapeHtml(item.ratingValue)}${item.reviewCount ? ` (${escapeHtml(String(item.reviewCount))})` : ''}</span>` : ''}
          </div>
        </div>
      </div>
    `;
  }
  if (typeSet.has('article') || typeSet.has('blogposting') || typeSet.has('newsarticle')){
    return `
      <div class="sd-preview sd-preview--article">
        ${item.image ? `<img src="${escapeHtml(item.image)}" alt="" class="sd-preview__image" />` : `<div class="sd-preview__image sd-preview__image--placeholder">Article</div>`}
        <div class="sd-preview__body">
          <div class="sd-preview__eyebrow">Article</div>
          <h5>${escapeHtml(item.headline || item.name || 'Untitled article')}</h5>
          <div class="sd-preview__meta">
            ${item.author ? `<span class="chip">${escapeHtml(item.author)}</span>` : ''}
            ${item.datePublished ? `<span class="chip">${formatStructuredDate(item.datePublished)}</span>` : ''}
          </div>
          ${item.description ? `<p>${escapeHtml(item.description)}</p>` : ''}
        </div>
      </div>
    `;
  }
  if (typeSet.has('faqpage')){
    const questions = (item.questions || []).slice(0, 4);
    return `
      <div class="sd-preview sd-preview--list">
        <div class="sd-preview__eyebrow">FAQ</div>
        <h5>${escapeHtml(item.name || 'FAQPage')}</h5>
        <ul class="sd-list">
          ${questions.length ? questions.map(q => `<li>${escapeHtml(q)}</li>`).join('') : '<li>Questions detected, but no readable labels were extracted.</li>'}
        </ul>
      </div>
    `;
  }
  if (typeSet.has('breadcrumblist')){
    return `
      <div class="sd-preview sd-preview--list">
        <div class="sd-preview__eyebrow">Breadcrumbs</div>
        <h5>${escapeHtml(item.name || 'Breadcrumb trail')}</h5>
        <p>${escapeHtml(item.path || 'Breadcrumb items detected')}</p>
      </div>
    `;
  }
  if (typeSet.has('organization') || typeSet.has('localbusiness') || typeSet.has('person')){
    const hostname = (()=>{ try { return item.url ? new URL(item.url).hostname.replace(/^www\./,'') : ''; } catch { return ''; } })();
    return `
      <div class="sd-preview sd-preview--person">
        ${item.image ? `<img src="${escapeHtml(item.image)}" alt="" class="sd-preview__avatar" />` : `<div class="sd-preview__avatar sd-preview__avatar--placeholder">${escapeHtml((item.name || 'S').slice(0,1).toUpperCase())}</div>`}
        <div class="sd-preview__body">
          <div class="sd-preview__eyebrow">${escapeHtml(item.typeLabel || 'Entity')}</div>
          <h5>${escapeHtml(item.name || 'Untitled entity')}</h5>
          ${item.description ? `<p>${escapeHtml(item.description)}</p>` : ''}
          <div class="sd-preview__meta">
            ${hostname ? `<span class="chip">${escapeHtml(hostname)}</span>` : ''}
            ${item.telephone ? `<span class="chip">${escapeHtml(item.telephone)}</span>` : ''}
          </div>
        </div>
      </div>
    `;
  }
  if (typeSet.has('event')){
    return `
      <div class="sd-preview sd-preview--list">
        <div class="sd-preview__eyebrow">Event</div>
        <h5>${escapeHtml(item.name || 'Untitled event')}</h5>
        <div class="sd-preview__meta">
          ${item.startDate ? `<span class="chip">${formatStructuredDate(item.startDate)}</span>` : ''}
          ${item.location ? `<span class="chip">${escapeHtml(item.location)}</span>` : ''}
        </div>
      </div>
    `;
  }
  if (typeSet.has('videoobject')){
    return `
      <div class="sd-preview sd-preview--article">
        ${item.image ? `<img src="${escapeHtml(item.image)}" alt="" class="sd-preview__image" />` : `<div class="sd-preview__image sd-preview__image--placeholder">Video</div>`}
        <div class="sd-preview__body">
          <div class="sd-preview__eyebrow">Video</div>
          <h5>${escapeHtml(item.name || 'Untitled video')}</h5>
          <div class="sd-preview__meta">
            ${item.uploadDate ? `<span class="chip">${formatStructuredDate(item.uploadDate)}</span>` : ''}
            ${item.duration ? `<span class="chip">${escapeHtml(item.duration)}</span>` : ''}
          </div>
        </div>
      </div>
    `;
  }
  return `
    <div class="sd-preview sd-preview--generic">
      <div class="sd-preview__eyebrow">${escapeHtml(item.typeLabel || 'Structured data')}</div>
      <h5>${escapeHtml(pickStructuredTitle(item))}</h5>
      ${item.description ? `<p>${escapeHtml(item.description)}</p>` : '<p>Parsed from markup.</p>'}
    </div>
  `;
}
function renderStructuredItemCard(item){
  const fieldRows = [
    structuredField('Name', escapeHtml(item.name || '')),
    structuredField('Headline', escapeHtml(item.headline || '')),
    structuredField('Description', escapeHtml(item.description || '')),
    structuredField('URL', item.url ? formatMaybeLink(item.url) : ''),
    structuredField('Author', escapeHtml(item.author || '')),
    structuredField('Brand', escapeHtml(item.brand || '')),
    structuredField('Price', item.price ? escapeHtml(`${item.price}${item.priceCurrency ? ` ${item.priceCurrency}` : ''}`) : ''),
    structuredField('Availability', escapeHtml(item.availability || '')),
    structuredField('Rating', item.ratingValue ? escapeHtml(`${item.ratingValue}${item.reviewCount ? ` (${item.reviewCount} reviews)` : ''}`) : ''),
    structuredField('Date published', item.datePublished ? formatStructuredDate(item.datePublished) : ''),
    structuredField('Start date', item.startDate ? formatStructuredDate(item.startDate) : ''),
    structuredField('Location', escapeHtml(item.location || '')),
    structuredField('Breadcrumb path', escapeHtml(item.path || '')),
    structuredField('Questions', (item.questions || []).length ? item.questions.map(v => String(v)) : []),
    structuredField('SameAs', (item.sameAs || []).slice(0, 4).map(v => safeStructuredUrl(v) || v)),
  ].filter(Boolean).join('');
  return `
    <article class="card sd-card">
      <div class="sd-card__head">
        <div>
          <div class="sd-badges">
            <span class="badge">${escapeHtml(item.sourceLabel || item.source || 'Structured data')}</span>
            ${(item.types || []).slice(0, 4).map(type => `<span class="badge badge--type">${escapeHtml(type)}</span>`).join('')}
          </div>
          <h4>${escapeHtml(pickStructuredTitle(item))}</h4>
          <p>${escapeHtml(item.summary || 'Parsed from markup.')}</p>
        </div>
        <span class="badge">${escapeHtml(item.typeLabel || 'Item')}</span>
      </div>
      ${renderStructuredPreview(item)}
      ${fieldRows ? `<div class="sd-detail-grid">${fieldRows}</div>` : ''}
    </article>
  `;
}
function renderStructuredData(data){
  const items = Array.isArray(data?.items) ? data.items : [];
  const counts = data?.counts || {};
  let hostLabel = 'Active page';
  try{ hostLabel = new URL(data?.url || 'https://example.com').hostname.replace(/^www\./,'') || 'Active page'; }catch{}
  const cards = [`
    <div class="card summary-card">
      <div class="summary-card__header">
        <div>
          <h4>Summary</h4>
          <p>Active page.</p>
        </div>
        <span class="badge">${escapeHtml(hostLabel)}</span>
      </div>
      <div class="metric-strip">
        <div class="metric-tile"><span>Total items</span><strong>${items.length.toLocaleString()}</strong></div>
        <div class="metric-tile"><span>JSON-LD</span><strong>${Number(counts.jsonld || 0).toLocaleString()}</strong></div>
        <div class="metric-tile"><span>Microdata</span><strong>${Number(counts.microdata || 0).toLocaleString()}</strong></div>
        <div class="metric-tile"><span>RDFa</span><strong>${Number(counts.rdfa || 0).toLocaleString()}</strong></div>
      </div>
      <div class="sd-actions">
        <button id="openSchemaValidatorResult" class="btn-top">Schema Validator</button>
        <button id="openRichResultsResult" class="btn-top">Rich Results</button>
      </div>
      ${data?.errors?.length ? `<div class="sd-warning">Some items could not be parsed cleanly (${data.errors.length} issue${data.errors.length === 1 ? '' : 's'}).</div>` : ''}
    </div>
  `];
  if (!items.length){
    cards.push(`
      <div class="card">
        <h4>No structured data</h4>
        <p>No JSON-LD, Microdata, or RDFa found.</p>
      </div>
    `);
  } else {
    cards.push(...items.map(renderStructuredItemCard));
  }
  renderHtml('result', cards.join(''));
  on('openSchemaValidatorResult', 'click', ()=>openSchemaValidator(data?.url || ''));
  on('openRichResultsResult', 'click', ()=>openRichResultsTest(data?.url || ''));
}
function openSchemaValidator(url){
  const safe = normalizeUrl(url || '');
  if (!safe) return clearResult('Open a public page.', 'structuredDataResult');
  chrome.tabs.create({ url: `https://validator.schema.org/#url=${encodeURIComponent(safe)}` });
}
function openRichResultsTest(url){
  const safe = normalizeUrl(url || '');
  if (!safe) return clearResult('Open a public page.', 'structuredDataResult');
  chrome.tabs.create({ url: `https://search.google.com/test/rich-results?url=${encodeURIComponent(safe)}` });
}
function extractStructuredDataFromPage(){
  const MAX_ITEMS = 60;
  const result = {
    url: location.href,
    title: document.title || '',
    items: [],
    errors: [],
    counts: { jsonld: 0, microdata: 0, rdfa: 0 }
  };
  const seen = new Set();
  const toText = (value) => {
    if (value == null) return '';
    if (typeof value === 'string') return value.trim();
    if (typeof value === 'number' || typeof value === 'boolean') return String(value);
    if (Array.isArray(value)) {
      const out = value.map(toText).filter(Boolean);
      return out[0] || '';
    }
    if (typeof value === 'object') {
      return String(
        value.name ||
        value.headline ||
        value.text ||
        value.description ||
        value.url ||
        value['@id'] ||
        ''
      ).trim();
    }
    return '';
  };
  const uniqueList = (values, limit=6) => {
    const out = [];
    const add = (value) => {
      if (value == null) return;
      if (Array.isArray(value)) return value.forEach(add);
      const text = toText(value);
      if (!text || out.includes(text)) return;
      out.push(text);
    };
    add(values);
    return out.slice(0, limit);
  };
  const cleanType = (value) => String(value || '').split('/').filter(Boolean).pop() || 'Thing';
  const cleanAvailability = (value) => String(value || '').split('/').filter(Boolean).pop() || String(value || '');
  const getImage = (value) => {
    if (!value) return '';
    if (typeof value === 'string') return value.trim();
    if (Array.isArray(value)) return getImage(value[0]);
    if (typeof value === 'object') {
      return String(value.url || value.contentUrl || value.thumbnailUrl || '').trim();
    }
    return '';
  };
  const getOffer = (value) => {
    if (!value) return null;
    if (Array.isArray(value)) return getOffer(value[0]);
    if (typeof value !== 'object') return null;
    return value;
  };
  const getAddress = (value) => {
    if (!value || typeof value !== 'object') return '';
    return [value.streetAddress, value.addressLocality, value.addressRegion, value.postalCode, value.addressCountry]
      .map(toText)
      .filter(Boolean)
      .join(', ');
  };
  const pushItem = (source, raw, summary) => {
    if (!raw || typeof raw !== 'object') return;
    const types = uniqueList(raw['@type'] || raw.type || summary.types || [], 6).map(cleanType);
    const key = JSON.stringify([source, raw['@id'] || summary.url || summary.name || summary.headline || '', types.join('|')]);
    if (seen.has(key) || result.items.length >= MAX_ITEMS) return;
    seen.add(key);
    const typeLabel = types.join(' · ') || 'Thing';
    result.items.push({
      source,
      sourceLabel: source === 'jsonld' ? 'JSON-LD' : source === 'microdata' ? 'Microdata' : 'RDFa',
      typeLabel,
      types,
      ...summary
    });
    result.counts[source] = Number(result.counts[source] || 0) + 1;
  };
  const summarizeNode = (node) => {
    if (!node || typeof node !== 'object') return null;
    const offer = getOffer(node.offers);
    const aggregateRating = node.aggregateRating && typeof node.aggregateRating === 'object' ? node.aggregateRating : null;
    const questions = Array.isArray(node.mainEntity)
      ? node.mainEntity.map(entity => toText(entity?.name || entity?.headline)).filter(Boolean)
      : [];
    const breadcrumbItems = Array.isArray(node.itemListElement)
      ? node.itemListElement.map(item => toText(item?.name || item?.item?.name || item?.item)).filter(Boolean)
      : [];
    return {
      name: toText(node.name),
      headline: toText(node.headline),
      description: toText(node.description),
      image: getImage(node.image || node.logo || node.thumbnailUrl),
      url: toText(node.url || node.mainEntityOfPage || node.sameAs),
      sameAs: uniqueList(node.sameAs || [], 4),
      author: toText(node.author),
      brand: toText(node.brand || node.manufacturer),
      price: toText(offer?.price),
      priceCurrency: toText(offer?.priceCurrency),
      availability: cleanAvailability(offer?.availability),
      ratingValue: toText(aggregateRating?.ratingValue || node.ratingValue),
      reviewCount: toText(aggregateRating?.reviewCount || aggregateRating?.ratingCount || node.reviewCount),
      datePublished: toText(node.datePublished),
      startDate: toText(node.startDate),
      endDate: toText(node.endDate),
      location: toText(node.location?.name || getAddress(node.location?.address) || node.location),
      telephone: toText(node.telephone),
      duration: toText(node.duration),
      uploadDate: toText(node.uploadDate),
      path: breadcrumbItems.join(' › '),
      questions,
      questionCount: questions.length,
      summary: toText(node.description) || toText(node.headline) || toText(node.name) || '',
    };
  };
  const walkJsonLd = (value) => {
    if (!value || result.items.length >= MAX_ITEMS) return;
    if (Array.isArray(value)) return value.forEach(walkJsonLd);
    if (typeof value !== 'object') return;
    if (Array.isArray(value['@graph'])) value['@graph'].forEach(walkJsonLd);
    if (value['@type'] || value['@id'] || value.name || value.headline) {
      pushItem('jsonld', value, summarizeNode(value) || {});
    }
  };
  const tryParseJsonLd = (text) => {
    try{
      return JSON.parse(text);
    }catch(err){
      try{
        const sanitized = text
          .replace(/^\s*<!--/, '')
          .replace(/-->\s*$/, '')
          .replace(/\/\*[\s\S]*?\*\//g, '')
          .replace(/(^|[^:])\/\/.*$/gm, '$1');
        return JSON.parse(sanitized);
      }catch(secondErr){
        result.errors.push(String(secondErr?.message || err?.message || 'Invalid JSON-LD'));
        return null;
      }
    }
  };

  Array.from(document.querySelectorAll('script[type="application/ld+json"]')).forEach(script => {
    const parsed = tryParseJsonLd(script.textContent || '');
    if (parsed) walkJsonLd(parsed);
  });

  const isNestedMicrodata = (el) => {
    let parent = el.parentElement;
    while (parent) {
      if (parent.hasAttribute('itemscope')) return true;
      parent = parent.parentElement;
    }
    return false;
  };
  const readMicrodataValue = (el) => {
    if (!el) return '';
    const tag = el.tagName.toLowerCase();
    if (el.hasAttribute('content')) return el.getAttribute('content') || '';
    if ((tag === 'a' || tag === 'link') && el.hasAttribute('href')) return el.href || el.getAttribute('href') || '';
    if ((tag === 'img' || tag === 'source') && el.hasAttribute('src')) return el.currentSrc || el.src || el.getAttribute('src') || '';
    if ((tag === 'audio' || tag === 'video') && el.hasAttribute('src')) return el.currentSrc || el.src || el.getAttribute('src') || '';
    if (tag === 'time' && el.hasAttribute('datetime')) return el.getAttribute('datetime') || '';
    return (el.textContent || '').trim();
  };
  Array.from(document.querySelectorAll('[itemscope]')).filter(el => !isNestedMicrodata(el)).forEach(root => {
    const props = {};
    const types = (root.getAttribute('itemtype') || '')
      .split(/\s+/)
      .map(cleanType)
      .filter(Boolean);
    Array.from(root.querySelectorAll('[itemprop]')).forEach(el => {
      const nestedOwner = el.closest('[itemscope]');
      if (nestedOwner && nestedOwner !== root) return;
      const key = (el.getAttribute('itemprop') || '').trim();
      if (!key) return;
      const value = readMicrodataValue(el);
      if (!value) return;
      if (!props[key]) props[key] = [];
      props[key].push(value);
    });
    pushItem('microdata', {
      '@type': types,
      name: props.name?.[0],
      description: props.description?.[0],
      image: props.image?.[0],
      url: props.url?.[0],
      brand: props.brand?.[0],
      price: props.price?.[0],
      priceCurrency: props.priceCurrency?.[0],
      availability: props.availability?.[0],
      author: props.author?.[0],
      itemListElement: props.item?.map(v => ({ name: v })) || []
    }, {
      name: props.name?.[0] || '',
      headline: props.headline?.[0] || '',
      description: props.description?.[0] || '',
      image: props.image?.[0] || '',
      url: props.url?.[0] || '',
      brand: props.brand?.[0] || '',
      price: props.price?.[0] || '',
      priceCurrency: props.priceCurrency?.[0] || '',
      availability: cleanAvailability(props.availability?.[0]),
      author: props.author?.[0] || '',
      path: (props.name || []).slice(0, 8).join(' › '),
      summary: props.description?.[0] || props.name?.[0] || ''
    });
  });

  const isNestedRdfa = (el) => {
    let parent = el.parentElement;
    while (parent) {
      if (parent.hasAttribute('typeof')) return true;
      parent = parent.parentElement;
    }
    return false;
  };
  const readRdfaValue = (el) => {
    if (!el) return '';
    return el.getAttribute('content')
      || el.getAttribute('resource')
      || el.getAttribute('href')
      || el.getAttribute('src')
      || el.getAttribute('datetime')
      || (el.textContent || '').trim();
  };
  Array.from(document.querySelectorAll('[typeof]')).filter(el => !isNestedRdfa(el)).forEach(root => {
    const props = {};
    const types = (root.getAttribute('typeof') || '')
      .split(/\s+/)
      .map(cleanType)
      .filter(Boolean);
    Array.from(root.querySelectorAll('[property]')).forEach(el => {
      const nestedOwner = el.closest('[typeof]');
      if (nestedOwner && nestedOwner !== root) return;
      const key = (el.getAttribute('property') || '').trim();
      if (!key) return;
      const value = readRdfaValue(el);
      if (!value) return;
      if (!props[key]) props[key] = [];
      props[key].push(value);
    });
    pushItem('rdfa', {
      '@type': types,
      name: props.name?.[0] || props.headline?.[0],
      description: props.description?.[0],
      image: props.image?.[0] || props.logo?.[0],
      url: props.url?.[0]
    }, {
      name: props.name?.[0] || '',
      headline: props.headline?.[0] || '',
      description: props.description?.[0] || '',
      image: props.image?.[0] || props.logo?.[0] || '',
      url: props.url?.[0] || '',
      author: props.author?.[0] || '',
      summary: props.description?.[0] || props.name?.[0] || ''
    });
  });

  return result;
}

/* ---------- deep links ---------- */
function openGSCInspect(siteUrl, url){
  const encoded = encodeURIComponent(url);
  const base = 'https://search.google.com/search-console/inspect';
  const qs = `?resource_id=${encodeURIComponent(siteUrl)}&url=${encoded}`;
  chrome.tabs.create({ url: base + qs });
}

/* ---------- messaging ---------- */
async function send(msg){ return await chrome.runtime.sendMessage(msg); }

/* ---------- Dates ---------- */
function toISO(daysAgo){ const d = new Date(Date.now() - daysAgo*86400000); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; }
function todayISO(){ const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; }

/* ---------- Account label ---------- */
// safe JWT payload decoder (no deprecated escape())
function parseIdToken(idToken){
  try{
    const base64Url = idToken.split('.')[1];            // JWT payload
    const base64 = base64Url.replace(/-/g,'+').replace(/_/g,'/'); // base64url -> base64
    const bin = atob(base64);                           // binary string
    const bytes = Uint8Array.from(bin, c => c.charCodeAt(0));
    const json = new TextDecoder().decode(bytes);       // UTF-8 decode
    return JSON.parse(json);
  }catch{
    return null;
  }
}

async function setAccountLabel(){
  try{
    const r = await send({ type:'getAccount' });
    const idToken = r?.data || null;
    const payload = idToken ? parseIdToken(idToken) : null;
    const email = payload?.email || '';
    const label = $('accountLabel'); if (label) label.textContent = email ? email : '';
    const mini = $('accountMini'); if (mini) mini.textContent = email ? email : '—';
    const settingsEmail = $('settingsAccountEmail'); if (settingsEmail) settingsEmail.textContent = email || 'Not connected';
    const settingsHint = $('settingsAccountHint');
    if (settingsHint) settingsHint.textContent = email ? 'Connected.' : 'Sign in when needed.';
  }catch(e){ console.warn(e); }
}

/* ---------- NAV ---------- */
const navMap = {
  navIndex:     "panelIndex",
  navTags:      "panelTags",
  navAnalytics: "panelAnalytics",
  navPerf:      "panelPerf",
  navCallRail:  "panelCallRail",
  navOnPage:    "panelOnPage",
  navStructuredData: "panelStructuredData",
  navSettings:  "panelSettings"
};

function mountNav(){
  const activationMap = {
    navTags: () => runTagsScan({ reason:'tab' }),
    navOnPage: () => runOnPageAudit({ reason:'tab' }),
    navStructuredData: () => runStructuredDataScan({ reason:'tab' })
  };
  const show = (navId)=>{
    Object.values(navMap).forEach(id => { if(id){ const el=$(id); if(el) el.classList.add('hidden'); } });
    const pid = navMap[navId];
    if (pid) {
      const el=$(pid);
      if(el){
        el.classList.remove('hidden');
        animateIn(el);
      }
    }

    // highlight selected
    Object.keys(navMap).forEach(nid => { const b=$(nid); if(b) b.classList.remove('active'); });
    const btn=$(navId); if(btn) btn.classList.add('active');
    setPanelContext(navId);
  };
  Object.keys(navMap).forEach(nid => {
    const b=$(nid);
    if(!b) return;
    b.addEventListener('click', ()=>{
      show(nid);
      setSidebarCollapsed(true, shouldPersistSidebarState());
      activationMap[nid]?.();
    });
  });
  show('navPerf'); // default
}


/* ---------- INIT ---------- */
async function init(){
  await initSidebarUX();
  await gaHydrateState();
  const manifest = chrome.runtime.getManifest();
  const versionText = (manifest.version_name || manifest.version || '0').replace(/\s+-\s+/g, ' · ');
  $('version').textContent = versionText;

  clearResult('Pick a property.');
  mountNav();
  setAccountLabel().catch(()=>{});

  // prefill active tab url
  const tabUrlRaw = await getActiveTabUrl().catch(()=> '');
  const tabUrl = tabUrlRaw ? normalizeUrl(tabUrlRaw) : '';
  if (tabUrl && $('inspectUrl')) $('inspectUrl').value = tabUrl;

  // load sites
  try{
    await loadSites();
    clearResult('');
  }catch(e){
    clearResult('Failed to load properties.');
  }

  // input enables
  $('inspectUrl').addEventListener('input', autoSelectPropertyForUrl);
  $('sites').addEventListener('change', ()=>{ updatePropertyMeta('manual'); setEnabled(); });
  $('sitePickerToggle').addEventListener('click', (e)=>{
    e.preventDefault();
    $('sitePickerMenu')?.classList.contains('hidden') ? openSitePicker() : closeSitePicker();
  });
  $('sitePickerSearch').addEventListener('input', (e)=>{
    state.ui.siteFilter = e.target.value || '';
    renderSitePicker(state.ui.siteFilter);
  });
  $('sitePickerSearch').addEventListener('keydown', (e)=>{
    if (e.key === 'Escape') closeSitePicker();
  });
  document.addEventListener('click', (e)=>{
    const shell = e.target?.closest?.('.property-shell');
    if (!shell) closeSitePicker();
  });

  // Performance pills/scope
  qsa('.pill').forEach(pill => pill.addEventListener('click', ()=>{
    qsa('.pill').forEach(x=>x.classList.remove('active'));
    pill.classList.add('active');
    state.perf.range = pill.dataset.range;
    const isCustom = state.perf.range === 'custom';
    $('customRange').classList.toggle('hidden', !isCustom);
    if(!isCustom){ $('dateStart').value=''; $('dateEnd').value=''; }
    setEnabled();
  }));
  $('scopeSwitch').addEventListener('click', ()=>{
    $('scopeSwitch').classList.toggle('on');
    state.perf.wholeProperty = $('scopeSwitch').classList.contains('on');
    setEnabled();
  });

  // Buttons
  const refreshSites = async ()=>{
    try{
      await loadSites({ forceRefresh:true });
      clearResult('');
    }catch(e){
      clearResult('Failed to load properties.');
    }
  };
  $('refreshSites').onclick = refreshSites;
  $('settingsRefreshSites').onclick = refreshSites;

  $('useActiveUrl').onclick = async ()=>{
    const url = await getActiveTabUrl().catch(()=> '');
    const normalized = url ? normalizeUrl(url) : '';
    if (!normalized) return clearResult('Open a public page.');
    $('inspectUrl').value = normalized;
    autoSelectPropertyForUrl();
  };

  $('inspect').onclick = async ()=>{
    const siteUrl = $('sites')?.value?.trim(); const url = normalizeUrl($('inspectUrl')?.value?.trim() || '');
    if(!url) return clearResult('Enter a valid URL.');
    if(!propertyCoversUrl(siteUrl, url)) return clearResult(`Property doesn't cover this URL.`);
    clearResult('Inspecting…', 'indexResult');
    const r = await send({ type:'inspect', siteUrl, url });
    if(r.ok){
      let livePage = null;
      try { livePage = await collectIndexingSupplement(url); } catch (_) { livePage = null; }
      renderIndexing({ ...(r.data || {}), livePage });
    } else {
      clearResult('❌ ' + r.error, 'indexResult');
    }
  };

  $('openGSC').onclick = ()=>{
    const siteUrl = $('sites')?.value?.trim(); const url = normalizeUrl($('inspectUrl')?.value?.trim() || '');
    if(siteUrl && url) openGSCInspect(siteUrl, url);
  };

  $('loadPerf').onclick = ()=>{ loadPerfReport({ forceRefresh:false }); };
  on('refreshPerf', 'click', ()=>{ loadPerfReport({ forceRefresh:true }); });

  $('runOnPage').onclick = ()=>{ runOnPageAudit({ reason:'button' }); };

  $('runTags').onclick = ()=>{ runTagsScan({ reason:'button' }); };

  $('runStructuredData').onclick = ()=>{ runStructuredDataScan({ reason:'button' }); };

  $('openSchemaValidator').onclick = async ()=>{
    const url = normalizeUrl($('inspectUrl')?.value?.trim() || '') || normalizeUrl(await getActiveTabUrl().catch(()=> ''));
    openSchemaValidator(url || '');
  };

  $('openRichResults').onclick = async ()=>{
    const url = normalizeUrl($('inspectUrl')?.value?.trim() || '') || normalizeUrl(await getActiveTabUrl().catch(()=> ''));
    openRichResultsTest(url || '');
  };

  $('logoutSettings').onclick = async ()=>{
    await send({ type:'logout' });
    state.ui.sitesCache = null;
    state.perf.cache = null;
    setSites([]);
    GA.props = null;
    GA.keyEventsByProperty = {};
    GA.keyEventSelections = {};
    GA.keyEventNotices = {};
    GA.keyEventCacheByProperty = {};
    GA.propCacheMeta = null;
    GA.reportCacheMeta = null;
    GA.generalNotice = '';
    if ($('gaProps')) $('gaProps').innerHTML = '<option value="">Select GA4 property</option>';
    gaRenderKeyEventState();
    gaRenderReportCacheNote();
    setCacheNote('sitesCacheStatus', null);
    setCacheNote('perfCacheStatus', null);
    $('accountLabel').textContent = '';
    $('accountMini').textContent = '—';
    const settingsEmail = $('settingsAccountEmail'); if (settingsEmail) settingsEmail.textContent = 'Not connected';
    const settingsHint = $('settingsAccountHint'); if (settingsHint) settingsHint.textContent = 'Sign in when needed.';
    clearResult('Signed out.');
  };
}

/* ---------- Kick off ---------- */
const start = () => safe(init);
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', start, { once:true });
} else {
  start();
}
