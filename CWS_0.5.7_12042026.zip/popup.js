// popup.js — stable init + visual render; now mirrors signed-in email in sidebar credits.

const $ = id => document.getElementById(id);
const qsa = sel => Array.from(document.querySelectorAll(sel));
// safe binder
const on = (id, evt, fn) => {
  const el = $(id);
  if (el) el.addEventListener(evt, fn);
};


function surfaceError(e){
  console.error(e);
  clearResult(`❌ ${e?.message || e}`);
}
function safe(fn){ try { return fn(); } catch(e){ surfaceError(e); } }


const SIDEBAR_STATE_KEY = 'mc_sidebar_collapsed';
function isCompactPopup(){
  const root = document.documentElement;
  if (!root || root.dataset.mode !== 'popup') return false;
  const width = window.innerWidth || root.clientWidth || 0;
  const height = window.innerHeight || root.clientHeight || 0;
  return width <= 785 && height <= 600;
}
function shouldPersistSidebarState(){
  return !isCompactPopup();
}
function setSidebarCollapsed(collapsed, persist=true){
  const shell = document.querySelector('.shell');
  if(!shell) return;
  shell.classList.toggle('sidebar-collapsed', !!collapsed);
  if(persist && chrome?.storage?.local){ chrome.storage.local.set({[SIDEBAR_STATE_KEY]: !!collapsed}); }
}
async function initSidebarUX(){
  if (isCompactPopup()) {
    setSidebarCollapsed(true, false);
  } else {
    try{
      const v = await chrome.storage.local.get(SIDEBAR_STATE_KEY);
      setSidebarCollapsed(!!v[SIDEBAR_STATE_KEY], false);
    }catch(e){ /* ignore */ }
  }
  on('collapseSidebar','click', ()=> {
    const shell = document.querySelector('.shell');
    setSidebarCollapsed(!shell?.classList.contains('sidebar-collapsed'), shouldPersistSidebarState());
  });
  on('sidebarFab','click', ()=>setSidebarCollapsed(false, shouldPersistSidebarState()));
}

const state = {
  sites: [],
  perf: { range:'30', wholeProperty:false, cache:null },
  callrail: { inited:false, last:null },
  ui: { siteFilter:'', sitesCache:null }
};

function formatRelativeTime(ts){
  const value = Number(ts || 0);
  if (!value) return '';
  const diff = Math.max(0, Date.now() - value);
  if (diff < 45000) return 'just now';
  const minutes = Math.round(diff / 60000);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.round(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.round(hours / 24);
  return `${days}d ago`;
}
function buildCacheText(cache, labels={}){
  if (!cache) return '';
  const when = formatRelativeTime(cache.fetchedAt);
  const suffix = when ? ` ${when}` : '';
  if (cache.stale) return `${labels.stale || 'Refresh failed. Showing cached data'}${suffix}.`;
  if (cache.source === 'cache') return `${labels.cached || 'Using cached data'}${suffix}.`;
  if (cache.source === 'mixed') return `${labels.mixed || 'Using a mix of fresh and cached data'}${suffix}.`;
  return `${labels.network || 'Updated'}${suffix}.`;
}
function setCacheNote(id, cache, labels={}){
  const el = $(id);
  if (!el) return;
  const text = buildCacheText(cache, labels);
  el.textContent = text;
  el.classList.toggle('hidden', !text);
  el.classList.toggle('is-stale', !!cache?.stale);
}
function combineCacheMeta(items){
  const list = (items || []).filter(Boolean);
  if (!list.length) return null;
  const source = list.every(item => item.source === 'network')
    ? 'network'
    : list.every(item => item.source === 'cache')
      ? 'cache'
      : 'mixed';
  const fetchedAt = list.reduce((max, item) => Math.max(max, Number(item?.fetchedAt || 0)), 0);
  return {
    source,
    fetchedAt,
    stale: list.some(item => item.stale)
  };
}

function kv(k,v){ return `<div class="row kv"><div class="k">${k}</div><div>${v}</div></div>`; }
function badge(s, cls=''){ return `<span class="badge ${cls}">${s}</span>`; }
function stateBadge(s){
  const t = String(s||'').toLowerCase();
  if(/(valid|passed|ok|good|on google|submitted|success|100|90)/.test(t)) return badge(s,'good');
  if(/(warning|partial|unknown|needs|medium)/.test(t)) return badge(s,'ok');
  if(/(error|fail|not on google|blocked|denied|slow|poor|noindex)/.test(t)) return badge(s,'bad');
  return badge(s);
}
function escapeHtml(s){
  return String(s).replace(/[&<>"']/g, m => (
    { '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[m]
  ));
}
const MAIN_EMPTY_STATE = `
  <div class="empty-state">
    <span class="empty-state__icon">↗</span>
    <div>
      <strong>Pick a workflow and run a check.</strong>
      <p>Indexing, live tests, performance, and on-page audits render here after each action.</p>
    </div>
  </div>
`;
const PANEL_STATE = {
  navIndex: {
    showSCContext: true
  },
  navLive: {
    showSCContext: true
  },
  navAnalytics: {
    showSCContext: false
  },
  navPerf: {
    showSCContext: true
  },
  navCallRail: {
    showSCContext: false
  },
  navOnPage: {
    showSCContext: false
  },
  navSettings: {
    showSCContext: false
  }
};
const RESULT_TARGETS = {
  navIndex: 'indexResult',
  navLive: 'liveResult',
  navPerf: 'perfResult',
  navOnPage: 'onPageResult',
  navAnalytics: 'gaResult',
  navCallRail: 'crResult'
};
function animateIn(el){
  if (!el) return;
  el.classList.remove('is-entering');
  void el.offsetWidth;
  el.classList.add('is-entering');
}
function inferStatusTone(msg=''){
  const text = String(msg).toLowerCase();
  if (/(❌|error|failed|denied|invalid|could not|not available)/.test(text)) return 'error';
  if (/(⚠️|warning|pick|select|enter|sign in|no data)/.test(text)) return 'warn';
  return 'info';
}
function statusCard(msg){
  const tone = inferStatusTone(msg);
  const icon = tone === 'error' ? '!' : tone === 'warn' ? '•' : 'i';
  return `
    <div class="status-card ${tone}">
      <span class="status-card__icon">${icon}</span>
      <div>
        <strong>${tone === 'error' ? 'Something needs attention' : tone === 'warn' ? 'Action needed' : 'Status update'}</strong>
        <p>${escapeHtml(msg)}</p>
      </div>
    </div>
  `;
}
function renderHtml(targetId, html){
  const resolvedId = targetId === 'result' ? (RESULT_TARGETS[document.querySelector('.nav button.active')?.id || 'navPerf'] || 'perfResult') : targetId;
  const el = $(resolvedId);
  if (!el) return;
  el.innerHTML = html;
  animateIn(el);
}
function setPropertyMatch(title, message){
  const el = $('propertyMatch');
  if (!el) return;
  el.innerHTML = `<strong>${escapeHtml(title)}</strong>${escapeHtml(message)}`;
}
function setPanelContext(navId){
  const copy = PANEL_STATE[navId] || PANEL_STATE.navPerf;
  $('scContext')?.classList.toggle('hidden', !copy.showSCContext);
}
function clearResult(msg, targetId){
  const resolvedId = targetId || RESULT_TARGETS[document.querySelector('.nav button.active')?.id || 'navPerf'] || 'perfResult';
  const el = $(resolvedId); if (!el) return;
  if (!msg) {
    el.innerHTML = '';
  } else {
    el.innerHTML = statusCard(msg);
  }
  animateIn(el);
}

/* ---------- URL & property helpers ---------- */
function normalizeUrl(raw){
  if (!raw) return null;
  let u = String(raw).trim();
  if (!/^https?:\/\//i.test(u)) u = 'https://' + u;
  try {
    const p = new URL(u);
    if (!/^https?:$/.test(p.protocol)) return null;
    p.hash=''; p.username=''; p.password='';
    const host = p.hostname;
    if (host === 'localhost' || host.endsWith('.local') ||
        /^127\./.test(host) || /^10\./.test(host) ||
        /^192\.168\./.test(host) || /^172\.(1[6-9]|2\d|3[0-1])\./.test(host)) return null;
    return p.toString();
  } catch { return null; }
}
function propertyCoversUrl(siteUrl, url){
  try{
    if(siteUrl.startsWith('sc-domain:')){
      const domain = siteUrl.split(':')[1];
      const u = new URL(url);
      return u.hostname === domain || u.hostname.endsWith('.'+domain);
    }
    return url.startsWith(siteUrl);
  }catch{ return false; }
}
function setSites(sites){
  state.sites = sites || [];
  const sel = $('sites'); if(!sel) return;
  sel.innerHTML = '';
  for(const s of state.sites){
    const opt = document.createElement('option');
    opt.value = s.siteUrl;
    opt.textContent = s.siteUrl + (s.permissionLevel ? `  (${s.permissionLevel})` : '');
    sel.appendChild(opt);
  }
  syncSitePickerLabel();
  renderSitePicker();
  autoSelectPropertyForUrl();
}
function syncSitePickerLabel(){
  const label = $('sitePickerLabel');
  const sel = $('sites');
  if (!label || !sel) return;
  label.textContent = sel.options.length ? (sel.selectedOptions?.[0]?.textContent || 'Select a property') : 'No properties loaded';
}
function renderSitePicker(filterText=''){
  const list = $('sitePickerList');
  const sel = $('sites');
  if (!list || !sel) return;
  const current = sel.value || '';
  const needle = String(filterText || state.ui.siteFilter || '').trim().toLowerCase();
  const items = state.sites.filter(site => {
    if (!needle) return true;
    const hay = `${site.siteUrl} ${site.permissionLevel || ''}`.toLowerCase();
    return hay.includes(needle);
  });
  if (!items.length){
    list.innerHTML = `<div class="picker-empty">No properties match this filter.</div>`;
    return;
  }
  list.innerHTML = items.map(site => {
    const active = site.siteUrl === current ? ' active' : '';
    return `
      <button class="picker-option${active}" type="button" data-site-value="${escapeHtml(site.siteUrl)}">
        <span>${escapeHtml(site.siteUrl)}</span>
        <small>${escapeHtml(site.permissionLevel || 'Unknown')}</small>
      </button>
    `;
  }).join('');
  qsa('.picker-option').forEach(btn => {
    btn.addEventListener('click', ()=>{
      const value = btn.dataset.siteValue || '';
      setSelectedSite(value, 'manual');
      closeSitePicker();
    });
  });
}
function openSitePicker(){
  $('sitePickerMenu')?.classList.remove('hidden');
  $('sitePickerToggle')?.setAttribute('aria-expanded', 'true');
  const search = $('sitePickerSearch');
  if (search){
    search.value = state.ui.siteFilter || '';
    search.focus();
    search.select();
  }
}
function closeSitePicker(){
  $('sitePickerMenu')?.classList.add('hidden');
  $('sitePickerToggle')?.setAttribute('aria-expanded', 'false');
}
function setSelectedSite(siteUrl, mode='manual'){
  const sel = $('sites');
  if (!sel || !siteUrl) return;
  sel.value = siteUrl;
  syncSitePickerLabel();
  renderSitePicker(state.ui.siteFilter || '');
  updatePropertyMeta(mode, mode === 'auto' ? siteUrl : '');
  setEnabled();
}
function getPermissionFor(siteUrl){
  const entry = (state.sites || []).find(s => s.siteUrl === siteUrl);
  return entry?.permissionLevel || '';
}
function isOwner(siteUrl){ return /owner/i.test(getPermissionFor(siteUrl)); }
function updatePropertyMeta(mode='auto', matchedSite=''){
  const current = matchedSite || $('sites')?.value || '';
  const permission = getPermissionFor(current) || '—';
  const badge = $('propertyPermission');
  if (badge) badge.textContent = `Permission: ${permission}`;

  const url = normalizeUrl($('inspectUrl')?.value || '');
  if (!url){
    setPropertyMatch('Property matching', 'Enter a public URL to auto-detect the best Search Console property.');
  } else if (matchedSite){
    setPropertyMatch('Auto-detected property', matchedSite);
  } else if (mode === 'auto'){
    setPropertyMatch('No property match', 'No matching Search Console property was found for this URL. Pick one manually if needed.');
  } else if (mode === 'manual' && current){
    setPropertyMatch('Manual selection', current);
  } else {
    setPropertyMatch('No property match', 'No matching Search Console property was found for this URL. Pick one manually if needed.');
  }
}
function autoSelectPropertyForUrl(){
  const sel = $('sites');
  if (!sel) return;
  const url = normalizeUrl($('inspectUrl')?.value || '');
  let matched = '';
  if (url){
    matched = chooseBestProperty(state.sites, url) || '';
    if (matched) setSelectedSite(matched, 'auto');
  }
  if (!matched) {
    syncSitePickerLabel();
    renderSitePicker(state.ui.siteFilter || '');
    updatePropertyMeta('auto', '');
  }
  setEnabled();
}
function setEnabled(){
  const sitesSel = $('sites'); const urlInp = $('inspectUrl');
  if (!sitesSel || !urlInp) return;
  const siteUrl = sitesSel.value || '';
  const url = normalizeUrl(urlInp.value || '');
  const covers = siteUrl && url && propertyCoversUrl(siteUrl, url);
  const owner = isOwner(siteUrl);
  const setDis = (id, on) => { const el = $(id); if (el) el.disabled = on; };
  setDis('inspect', !covers);
  setDis('liveTest', !covers);
  const whole = state.perf.wholeProperty;
  setDis('loadPerf', !(siteUrl && (whole ? true : covers)));
  setDis('runOnPage', false);
  const indexingAllowed = covers && owner;
  setDis('notifyUpdate', !indexingAllowed);
  setDis('notifyRemove', !indexingAllowed);
  setDis('checkStatus', !indexingAllowed);
}

async function loadSites({ forceRefresh=false } = {}){
  const response = await send({ type:'listSites', forceRefresh: !!forceRefresh }).catch(e => ({ ok:false, error:String(e)}));
  if (!response.ok) throw new Error(response.error || 'Failed to load properties');
  state.ui.sitesCache = response.cache || null;
  setSites(response.data || []);
  setCacheNote('sitesCacheStatus', state.ui.sitesCache, {
    network: 'Search Console properties refreshed',
    cached: 'Using cached Search Console properties',
    mixed: 'Using a mix of fresh and cached Search Console properties',
    stale: 'Refresh failed. Showing cached Search Console properties'
  });
  return response.data || [];
}
async function loadPerfReport({ forceRefresh=false } = {}){
  const siteUrl = $('sites')?.value?.trim();
  const whole = state.perf.wholeProperty;
  if(!siteUrl) return clearResult('Select a property.');
  const url = normalizeUrl($('inspectUrl')?.value?.trim() || '');
  if(!whole){
    if(!url) return clearResult('Enter a valid http(s) URL for page-level data.');
    if(!propertyCoversUrl(siteUrl, url)) return clearResult('Selected property does not cover this URL.');
  }
  let startDate, endDate;
  const today = new Date();
  const clampTo = new Date(today.getFullYear(), today.getMonth(), today.getDate() - 2);
  const clampISO = (d)=> `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;

  if(state.perf.range === 'custom'){
    startDate = $('dateStart')?.value || '';
    endDate = $('dateEnd')?.value || clampISO(clampTo);
    if(!startDate) return clearResult('Pick a start date.');
    if(startDate > endDate) return clearResult('Start date must be before end date.');
    if (endDate > clampISO(clampTo)) endDate = clampISO(clampTo);
  } else {
    const days = Number(state.perf.range || 30);
    endDate = clampISO(clampTo);
    startDate = toISO(days + 2);
  }
  clearResult(forceRefresh ? 'Refreshing performance…' : 'Loading performance…');
  const r = await send({ type:'perf', siteUrl, url: whole ? null : url, startDate, endDate, pageOnly: !whole, forceRefresh: !!forceRefresh });
  if(r.ok){
    state.perf.cache = r.cache || null;
    renderPerf(r.data, { start:startDate, end:endDate, wholeProperty:whole });
    setCacheNote('perfCacheStatus', state.perf.cache, {
      network: 'Search Console performance refreshed',
      cached: 'Using cached Search Console performance',
      mixed: 'Using a mix of fresh and cached Search Console performance',
      stale: 'Refresh failed. Showing cached Search Console performance'
    });
  } else {
    clearResult('❌ ' + r.error);
  }
}
// ===== Google Analytics (GA4) =====
const GA_STORAGE_KEYS = {
  selections: 'gaKeyEventSelections',
  mode: 'gaAnalyticsMode',
  breakdown: 'gaKeyEventBreakdown'
};
const GA_OVERVIEW_METRICS = ['activeUsers', 'sessions', 'screenPageViews', 'eventCount'];
const GA_KEY_EVENT_METRICS = ['keyEvents', 'eventCount', 'activeUsers', 'sessions'];
const GA_DEFAULT_BREAKDOWN = 'sessionDefaultChannelGroup';
const GA_DIM_LABELS = {
  date: "Date",
  eventName: "Event name",
  sessionDefaultChannelGroup: "Default Channel Group",
  country: "Country",
  deviceCategory: "Device category",
  pagePathPlusQueryString: "Page"
};
const GA_METRIC_LABELS = {
  activeUsers: "Active users",
  sessions: "Sessions",
  screenPageViews: "Views",
  eventCount: "Event count",
  keyEvents: "Key events"
};
const GA = {
  props: null,
  keyEventsByProperty: {},
  keyEventSelections: {},
  keyEventNotices: {},
  keyEventCacheByProperty: {},
  mode: 'overview',
  breakdown: GA_DEFAULT_BREAKDOWN,
  lastExport: null,
  propFilter: '',
  keyEventFilter: '',
  loadingPropertyId: '',
  propCacheMeta: null,
  reportCacheMeta: null,
  generalNotice: ''
};

async function gaGetStored(){
  return await new Promise(resolve => chrome.storage.local.get([
    GA_STORAGE_KEYS.selections,
    GA_STORAGE_KEYS.mode,
    GA_STORAGE_KEYS.breakdown
  ], resolve));
}
async function gaSetStored(obj){
  return await new Promise(resolve => chrome.storage.local.set(obj, resolve));
}
async function gaHydrateState(){
  const stored = await gaGetStored().catch(() => ({}));
  GA.keyEventSelections = stored?.[GA_STORAGE_KEYS.selections] && typeof stored[GA_STORAGE_KEYS.selections] === 'object'
    ? stored[GA_STORAGE_KEYS.selections]
    : {};
  GA.mode = stored?.[GA_STORAGE_KEYS.mode] === 'keyEvents' ? 'keyEvents' : 'overview';
  GA.breakdown = stored?.[GA_STORAGE_KEYS.breakdown] || GA_DEFAULT_BREAKDOWN;
  const breakdown = $('gaKeyBreakdown');
  if (breakdown) breakdown.value = GA.breakdown;
  gaSyncModeUi();
  gaResetExport();
}
function gaCurrentPropertyId(){
  return $('gaProps')?.value || '';
}
function isoDaysAgo(n){
  const d = new Date();
  d.setDate(d.getDate() - n);
  return d.toISOString().slice(0,10);
}
function ensureLaggedEnd(endIso){
  const t = todayISO();
  return endIso > t ? t : endIso;
}
function gaResolveDateRange(){
  let start, end;
  const rng = $('gaRange')?.value || '28';
  if (rng === 'custom'){
    start = $('gaStart')?.value || '';
    end = $('gaEnd')?.value || todayISO();
    if (!start) throw new Error('Select a custom start date.');
    if (start > end) throw new Error('Start date must be before end date.');
  } else {
    const days = Number(rng);
    end = todayISO();
    start = isoDaysAgo(days);
  }
  return { start, end: ensureLaggedEnd(end) };
}
function gaPreviousRange(start, end){
  const msPerDay = 86400000;
  const s = new Date(start + "T00:00:00");
  const e = new Date(end + "T00:00:00");
  const spanDays = Math.max(1, Math.round((e - s)/msPerDay) + 1);
  const prevEnd = new Date(s.getTime() - msPerDay);
  const prevStart = new Date(prevEnd.getTime() - (spanDays - 1) * msPerDay);
  return {
    start: prevStart.toISOString().slice(0,10),
    end: prevEnd.toISOString().slice(0,10)
  };
}
function gaHasRows(report){
  return !!(report && Array.isArray(report.rows) && report.rows.length);
}
function gaMetricLabel(name){
  return GA_METRIC_LABELS[name] || name;
}
function gaSyncPropPickerLabel(){
  const label = $('gaPropLabel');
  const sel = $('gaProps');
  if (!label || !sel) return;
  label.textContent = sel.options.length ? (sel.selectedOptions?.[0]?.textContent || 'Select a GA4 property') : 'No GA4 properties found';
}
function gaRenderPropPicker(filterText=''){
  const list = $('gaPropList');
  const sel = $('gaProps');
  if (!list || !sel) return;
  if (!(GA.props || []).length){
    list.innerHTML = `<div class="picker-empty">No GA4 properties found.</div>`;
    return;
  }
  const current = sel.value || '';
  const needle = String(filterText || GA.propFilter || '').trim().toLowerCase();
  const items = (GA.props || []).filter(prop => {
    if (!needle) return true;
    const hay = `${prop.account} ${prop.displayName} ${prop.id}`.toLowerCase();
    return hay.includes(needle);
  });
  if (!items.length){
    list.innerHTML = `<div class="picker-empty">No GA4 properties match this filter.</div>`;
    return;
  }
  list.innerHTML = items.map(prop => {
    const active = prop.id === current ? ' active' : '';
    return `
      <button class="picker-option ga-prop-option${active}" type="button" data-ga-prop-value="${escapeHtml(prop.id)}">
        <span>${escapeHtml(`${prop.account} • ${prop.displayName}`)}</span>
        <small>p:${escapeHtml(prop.id)}</small>
      </button>
    `;
  }).join('');
  qsa('#gaPropList [data-ga-prop-value]').forEach(btn => {
    btn.addEventListener('click', async ()=>{
      await gaSetSelectedProperty(btn.dataset.gaPropValue || '');
      gaClosePropPicker();
    });
  });
}
function gaOpenPropPicker(){
  $('gaPropMenu')?.classList.remove('hidden');
  $('gaPropToggle')?.setAttribute('aria-expanded', 'true');
  const search = $('gaPropSearch');
  if (search){
    search.value = GA.propFilter || '';
    search.focus();
    search.select();
  }
}
function gaClosePropPicker(){
  $('gaPropMenu')?.classList.add('hidden');
  $('gaPropToggle')?.setAttribute('aria-expanded', 'false');
}
async function gaSetSelectedProperty(propertyId){
  const sel = $('gaProps');
  if (!sel || !propertyId) return;
  sel.value = propertyId;
  gaSyncPropPickerLabel();
  gaRenderPropPicker(GA.propFilter || '');
  await gaHandlePropertyChange();
}

function gaSetPropertyNotice(propertyId, msg=''){
  if (!propertyId) return;
  if (msg) GA.keyEventNotices[propertyId] = msg;
  else delete GA.keyEventNotices[propertyId];
}
function gaSetGeneralNotice(msg=''){
  GA.generalNotice = msg || '';
}
function gaGetPropertyNotice(propertyId=gaCurrentPropertyId()){
  return propertyId ? (GA.keyEventNotices[propertyId] || '') : (GA.generalNotice || '');
}
function gaGetCurrentKeyEvents(propertyId=gaCurrentPropertyId()){
  return GA.keyEventsByProperty[propertyId] || [];
}
function gaGetSelectedKeyEvents(propertyId=gaCurrentPropertyId()){
  const raw = Array.isArray(GA.keyEventSelections[propertyId]) ? GA.keyEventSelections[propertyId] : [];
  const available = new Set(gaGetCurrentKeyEvents(propertyId).map(item => item.eventName));
  return raw.filter(name => available.has(name));
}
function gaCurrentSelectionLabel(propertyId=gaCurrentPropertyId()){
  if (!propertyId) return 'Choose a GA4 property';
  if (GA.loadingPropertyId === propertyId) return 'Loading key events…';
  const selected = gaGetSelectedKeyEvents(propertyId);
  if (!selected.length){
    return gaGetCurrentKeyEvents(propertyId).length ? 'Select key events' : 'No key events configured';
  }
  if (selected.length === 1) return selected[0];
  return `${selected.length} key events selected`;
}
function gaRenderKeyEventNotice(){
  const el = $('gaKeyEventNotice');
  if (!el) return;
  const msg = gaGetPropertyNotice();
  el.textContent = msg;
  el.classList.toggle('hidden', !msg);
}
function gaRenderPropertyCacheNote(){
  setCacheNote('gaPropCacheStatus', GA.propCacheMeta, {
    network: 'GA4 properties refreshed',
    cached: 'Using cached GA4 properties',
    mixed: 'Using a mix of fresh and cached GA4 properties',
    stale: 'Refresh failed. Showing cached GA4 properties'
  });
}
function gaRenderKeyEventCacheNote(){
  setCacheNote('gaKeyEventCacheStatus', GA.keyEventCacheByProperty[gaCurrentPropertyId()] || null, {
    network: 'Key events refreshed',
    cached: 'Using cached key events',
    mixed: 'Using a mix of fresh and cached key events',
    stale: 'Refresh failed. Showing cached key events'
  });
}
function gaRenderReportCacheNote(){
  setCacheNote('gaReportCacheStatus', GA.reportCacheMeta, {
    network: 'GA4 report refreshed',
    cached: 'Using cached GA4 report',
    mixed: 'Using a mix of fresh and cached GA4 report data',
    stale: 'Refresh failed. Showing cached GA4 report'
  });
}
function gaRenderKeyEventLabel(){
  const label = $('gaKeyEventLabel');
  if (label) label.textContent = gaCurrentSelectionLabel();
}
function gaRenderKeyEventPicker(){
  const list = $('gaKeyEventList');
  const actions = $('gaKeyEventActions');
  if (!list) return;
  const propertyId = gaCurrentPropertyId();
  const available = gaGetCurrentKeyEvents(propertyId);
  const selected = new Set(gaGetSelectedKeyEvents(propertyId));
  const needle = String(GA.keyEventFilter || '').trim().toLowerCase();
  const hideActions = () => {
    if (!actions) return;
    actions.innerHTML = '';
    actions.classList.add('hidden');
  };

  if (!propertyId){
    hideActions();
    list.innerHTML = `<div class="picker-empty">Choose a GA4 property to load key events.</div>`;
    return;
  }
  if (GA.loadingPropertyId === propertyId){
    hideActions();
    list.innerHTML = `<div class="picker-empty">Loading key events…</div>`;
    return;
  }
  if (!available.length){
    hideActions();
    list.innerHTML = `<div class="picker-empty">No key events are configured for this GA4 property yet.</div>`;
    return;
  }

  const items = available.filter(item => item.eventName.toLowerCase().includes(needle));
  if (!items.length){
    hideActions();
    list.innerHTML = `<div class="picker-empty">No key events match this filter.</div>`;
    return;
  }

  const visibleNames = items.map(item => item.eventName);
  const selectedVisibleCount = visibleNames.filter(name => selected.has(name)).length;
  const allVisibleSelected = visibleNames.length > 0 && selectedVisibleCount === visibleNames.length;
  const someVisibleSelected = selectedVisibleCount > 0 && !allVisibleSelected;

  if (actions){
    actions.classList.remove('hidden');
    actions.innerHTML = `
      <label class="ga-picker-bulk">
        <input type="checkbox" data-ga-select-all${allVisibleSelected ? ' checked' : ''}>
        <span>Select all</span>
      </label>
      <button type="button" class="ga-picker-clear" data-ga-clear-events${selected.size ? '' : ' disabled'}>Clear</button>
    `;
  }

  list.innerHTML = items.map(item => {
    const active = selected.has(item.eventName) ? ' active' : '';
    return `
      <label class="picker-option ga-picker-option${active}">
        <input type="checkbox" data-ga-event="${escapeHtml(item.eventName)}"${selected.has(item.eventName) ? ' checked' : ''}>
        <span class="ga-picker-name">${escapeHtml(item.eventName)}</span>
      </label>
    `;
  }).join('');

  const selectAll = actions?.querySelector('[data-ga-select-all]');
  if (selectAll){
    selectAll.indeterminate = someVisibleSelected;
    selectAll.addEventListener('change', async ()=>{
      const current = new Set(gaGetSelectedKeyEvents());
      if (selectAll.checked) visibleNames.forEach(name => current.add(name));
      else visibleNames.forEach(name => current.delete(name));
      await gaSetSelectedKeyEvents(Array.from(current));
    });
  }

  actions?.querySelector('[data-ga-clear-events]')?.addEventListener('click', async ()=>{
    await gaSetSelectedKeyEvents([]);
  });

  qsa('#gaKeyEventList input[data-ga-event]').forEach(input => {
    input.addEventListener('change', async ()=>{
      const name = input.dataset.gaEvent || '';
      if (!name) return;
      const current = new Set(gaGetSelectedKeyEvents());
      if (current.has(name)) current.delete(name);
      else current.add(name);
      await gaSetSelectedKeyEvents(Array.from(current));
    });
  });
}
function gaResetExport(){
  GA.lastExport = null;
  GA.reportCacheMeta = null;
  const btn = $('gaExport');
  if (btn) btn.disabled = true;
  gaRenderReportCacheNote();
}
function gaSetExport(filename, csv){
  GA.lastExport = filename && csv ? { filename, csv } : null;
  const btn = $('gaExport');
  if (btn) btn.disabled = !GA.lastExport;
}
function gaSyncGaActions(){
  const load = $('gaLoad');
  const prop = gaCurrentPropertyId();
  if (load){
    const hasKeySelection = gaGetSelectedKeyEvents().length > 0;
    const hasKeyEvents = gaGetCurrentKeyEvents().length > 0;
    load.disabled = !prop || (GA.mode === 'keyEvents' && (!hasKeySelection || !hasKeyEvents || GA.loadingPropertyId === prop));
    load.textContent = GA.mode === 'keyEvents' ? 'Load Key Events' : 'Load Analytics';
  }
  const refresh = $('gaRefreshData');
  if (refresh) refresh.disabled = !prop;
  const exportBtn = $('gaExport');
  if (exportBtn) exportBtn.disabled = !GA.lastExport;
}
function gaRenderKeyEventState(){
  gaRenderKeyEventLabel();
  gaRenderKeyEventPicker();
  gaRenderKeyEventNotice();
  gaRenderPropertyCacheNote();
  gaRenderKeyEventCacheNote();
  gaSyncGaActions();
}
function gaOpenKeyEventPicker(){
  if (!gaCurrentPropertyId()) return;
  $('gaKeyEventMenu')?.classList.remove('hidden');
  $('gaKeyEventToggle')?.setAttribute('aria-expanded', 'true');
  const search = $('gaKeyEventSearch');
  if (search){
    search.value = GA.keyEventFilter || '';
    search.focus();
    search.select();
  }
}
function gaCloseKeyEventPicker(){
  $('gaKeyEventMenu')?.classList.add('hidden');
  $('gaKeyEventToggle')?.setAttribute('aria-expanded', 'false');
}
function gaSyncModeUi(){
  const isKeyEvents = GA.mode === 'keyEvents';
  qsa('.ga-mode-overview').forEach(el => el.classList.toggle('hidden', isKeyEvents));
  qsa('.ga-mode-keyevents').forEach(el => el.classList.toggle('hidden', !isKeyEvents));
  $('gaModeOverview')?.classList.toggle('active', !isKeyEvents);
  $('gaModeKeyEvents')?.classList.toggle('active', isKeyEvents);
  $('gaModeOverview')?.setAttribute('aria-pressed', String(!isKeyEvents));
  $('gaModeKeyEvents')?.setAttribute('aria-pressed', String(isKeyEvents));
  const breakdown = $('gaKeyBreakdown');
  if (breakdown) breakdown.value = GA.breakdown;
  if (!isKeyEvents) gaCloseKeyEventPicker();
  gaRenderKeyEventState();
}
function gaSetMode(mode){
  GA.mode = mode === 'keyEvents' ? 'keyEvents' : 'overview';
  void gaSetStored({ [GA_STORAGE_KEYS.mode]: GA.mode });
  gaSyncModeUi();
  if (GA.mode === 'keyEvents'){
    const propertyId = gaCurrentPropertyId();
    if (propertyId && !GA.keyEventsByProperty[propertyId]){
      gaLoadKeyEvents(propertyId).catch(e => clearResult('❌ ' + (e?.message || e), 'gaResult'));
    }
  }
}
async function gaSetSelectedKeyEvents(names){
  const propertyId = gaCurrentPropertyId();
  if (!propertyId) return [];
  const order = new Map(gaGetCurrentKeyEvents(propertyId).map((item, index) => [item.eventName, index]));
  const next = Array.from(new Set((names || []).filter(name => order.has(name))))
    .sort((a, b) => (order.get(a) ?? 0) - (order.get(b) ?? 0));
  GA.keyEventSelections[propertyId] = next;
  await gaSetStored({ [GA_STORAGE_KEYS.selections]: GA.keyEventSelections });
  gaRenderKeyEventState();
  return next;
}
async function gaLoadKeyEvents(propertyId, { force=false } = {}){
  if (!propertyId){
    gaRenderKeyEventState();
    return [];
  }
  if (!force && GA.keyEventsByProperty[propertyId]){
    gaRenderKeyEventCacheNote();
    gaRenderKeyEventState();
    return GA.keyEventsByProperty[propertyId];
  }

  GA.loadingPropertyId = propertyId;
  gaRenderKeyEventState();
  try{
    const r = await send({ type:'gaListKeyEvents', propertyId, forceRefresh: !!force });
    if (!r.ok) throw new Error(r.error || 'Failed to load key events');

    const items = (r.data || [])
      .map(item => ({
        eventName: item.eventName || '',
        custom: !!item.custom,
        countingMethod: item.countingMethod || '',
        createTime: item.createTime || ''
      }))
      .filter(item => item.eventName)
      .sort((a, b) => a.eventName.localeCompare(b.eventName));

    GA.keyEventsByProperty[propertyId] = items;
    GA.keyEventCacheByProperty[propertyId] = r.cache || null;
    const raw = Array.isArray(GA.keyEventSelections[propertyId]) ? GA.keyEventSelections[propertyId] : [];
    const available = new Set(items.map(item => item.eventName));
    const next = raw.filter(name => available.has(name));
    const removed = raw.length - next.length;
    GA.keyEventSelections[propertyId] = next;

    if (removed > 0){
      await gaSetStored({ [GA_STORAGE_KEYS.selections]: GA.keyEventSelections });
      gaSetPropertyNotice(propertyId, `Removed ${removed} unavailable saved key event${removed === 1 ? '' : 's'} for this property.`);
    } else if (!items.length){
      gaSetPropertyNotice(propertyId, 'No key events are configured for this GA4 property yet. Configure them in GA4 Admin to use this view.');
    } else {
      gaSetPropertyNotice(propertyId, '');
      gaSetGeneralNotice('');
    }

    return items;
  } catch (e){
    delete GA.keyEventsByProperty[propertyId];
    delete GA.keyEventCacheByProperty[propertyId];
    gaSetPropertyNotice(propertyId, `Failed to load key events: ${e?.message || e}`);
    throw e;
  } finally {
    if (GA.loadingPropertyId === propertyId) GA.loadingPropertyId = '';
    gaRenderKeyEventState();
  }
}
async function gaHandlePropertyChange({ forceReload=false } = {}){
  const propertyId = gaCurrentPropertyId();
  GA.keyEventFilter = '';
  gaSyncPropPickerLabel();
  gaRenderPropPicker(GA.propFilter || '');
  gaCloseKeyEventPicker();
  gaResetExport();
  if (!propertyId){
    gaRenderKeyEventState();
    return;
  }
  gaSetGeneralNotice('');
  try{
    await gaLoadKeyEvents(propertyId, { force: forceReload });
  } catch (e){
    if (GA.mode === 'keyEvents') clearResult('❌ ' + (e?.message || e), 'gaResult');
  }
}
async function loadGaPropsOnce({ forceRefresh=false } = {}){
  const sel = $('gaProps');
  if (!sel) return;
  if (GA.props && sel.options.length && !forceRefresh){
    gaSyncPropPickerLabel();
    gaRenderPropPicker(GA.propFilter || '');
    gaRenderPropertyCacheNote();
    return;
  }

  const currentValue = sel.value || '';
  const r = await send({ type:"gaListProperties", forceRefresh: !!forceRefresh });
  if (!r.ok) throw new Error(r.error || "Failed to list GA properties");
  GA.propCacheMeta = r.cache || null;
  GA.props = r.data || [];
  sel.innerHTML = "";

  const placeholder = document.createElement('option');
  placeholder.value = '';
  placeholder.textContent = GA.props.length ? 'Select a GA4 property' : 'No GA4 properties found';
  sel.appendChild(placeholder);

  GA.props.forEach(p => {
    const opt = document.createElement('option');
    opt.value = p.id;
    opt.textContent = `${p.account} • ${p.displayName} (p:${p.id})`;
    sel.appendChild(opt);
  });

  const hasCurrent = !!currentValue && Array.from(sel.options).some(opt => opt.value === currentValue);
  sel.value = hasCurrent ? currentValue : '';
  if (currentValue && !hasCurrent){
    gaSetGeneralNotice('Previously selected GA4 property is no longer available. Pick another property.');
  } else if (!sel.value && !GA.props.length){
    gaSetGeneralNotice('No GA4 properties are currently available for this account.');
  } else if (sel.value){
    gaSetGeneralNotice('');
  }
  gaSyncPropPickerLabel();
  gaRenderPropPicker();
  gaRenderPropertyCacheNote();
  await gaHandlePropertyChange({ forceReload: !!sel.value && !!forceRefresh });
}
async function gaFetchReport(payload){
  const r = await send(Object.assign({ type:'gaReport' }, payload));
  if (!r.ok) throw new Error(r.error || 'GA4 error');
  return { data: r.data, cache: r.cache || null };
}
async function gaFetchKeyEventBundle({ propertyId, startDate, endDate, eventNames, breakdown, forceRefresh=false }){
  const base = {
    propertyId,
    startDate,
    endDate,
    metrics: GA_KEY_EVENT_METRICS,
    inListFilter: {
      fieldName: 'eventName',
      values: eventNames
    }
  };
  const [eventTotals, trend, breakdownData] = await Promise.all([
    gaFetchReport(Object.assign({}, base, {
      dimensions: ['eventName'],
      rowLimit: Math.max(eventNames.length, 25),
      orderByMetric: 'keyEvents',
      forceRefresh
    })),
    gaFetchReport(Object.assign({}, base, { dimensions: ['date'], forceRefresh })),
    gaFetchReport(Object.assign({}, base, {
      dimensions: [breakdown],
      rowLimit: 50,
      orderByMetric: 'keyEvents',
      forceRefresh
    }))
  ]);
  return {
    eventTotals: eventTotals.data,
    trend: trend.data,
    breakdown: breakdownData.data,
    cache: combineCacheMeta([eventTotals.cache, trend.cache, breakdownData.cache])
  };
}

async function gaLoadActiveReport({ forceRefresh=false } = {}){
  const prop = gaCurrentPropertyId();
  if (!prop) return clearResult("Pick a GA4 property first.", 'gaResult');

  let range;
  try{
    range = gaResolveDateRange();
  }catch(e){
    return clearResult(e?.message || String(e), 'gaResult');
  }

  gaResetExport();
  if (GA.mode === 'keyEvents'){
    const eventNames = gaGetSelectedKeyEvents(prop);
    if (!eventNames.length) return clearResult('Select at least one key event.', 'gaResult');

    clearResult(forceRefresh ? 'Refreshing GA4 key events…' : 'Loading GA4 key events…', 'gaResult');
    try{
      const breakdown = $('gaKeyBreakdown')?.value || GA.breakdown;
      GA.breakdown = breakdown;
      void gaSetStored({ [GA_STORAGE_KEYS.breakdown]: GA.breakdown });
      const currData = await gaFetchKeyEventBundle({
        propertyId: prop,
        startDate: range.start,
        endDate: range.end,
        eventNames,
        breakdown,
        forceRefresh
      });

      let prevData = null;
      const cacheBits = [currData.cache];
      if ($('gaCompare')?.checked){
        const prevRange = gaPreviousRange(range.start, range.end);
        prevData = await gaFetchKeyEventBundle({
          propertyId: prop,
          startDate: prevRange.start,
          endDate: prevRange.end,
          eventNames,
          breakdown,
          forceRefresh
        });
        cacheBits.push(prevData.cache);
      }

      GA.reportCacheMeta = combineCacheMeta(cacheBits);
      renderGaKeyEventsReport(currData, {
        start: range.start,
        end: range.end,
        breakdown,
        prop,
        eventNames
      }, prevData);
      gaRenderReportCacheNote();
    }catch(e){
      clearResult('❌ ' + (e?.message || e), 'gaResult');
    }
    return;
  }

  const dim = $('gaDim')?.value || 'date';
  clearResult(forceRefresh ? 'Refreshing GA4…' : 'Loading GA4…', 'gaResult');
  try{
    const currData = await gaFetchReport({
      propertyId: prop,
      startDate: range.start,
      endDate: range.end,
      dimension: dim,
      forceRefresh
    });

    let prevData = null;
    const cacheBits = [currData.cache];
    if ($('gaCompare')?.checked){
      const prevRange = gaPreviousRange(range.start, range.end);
      prevData = await gaFetchReport({
        propertyId: prop,
        startDate: prevRange.start,
        endDate: prevRange.end,
        dimension: dim,
        forceRefresh
      });
      cacheBits.push(prevData.cache);
    }

    GA.reportCacheMeta = combineCacheMeta(cacheBits);
    renderGaReport(currData.data, { start: range.start, end: range.end, dim, prop }, prevData?.data || null);
    gaRenderReportCacheNote();
  }catch(e){
    clearResult('❌ ' + (e?.message || e), 'gaResult');
  }
}

on('gaModeOverview', 'click', ()=> gaSetMode('overview'));
on('gaModeKeyEvents', 'click', ()=> gaSetMode('keyEvents'));
on('gaProps', 'change', ()=>{ gaHandlePropertyChange().catch(e => clearResult('❌ ' + (e?.message || e), 'gaResult')); });
on('gaPropToggle', 'click', (e)=>{
  e.preventDefault();
  $('gaPropMenu')?.classList.contains('hidden') ? gaOpenPropPicker() : gaClosePropPicker();
});
on('gaPropSearch', 'input', (e)=>{
  GA.propFilter = e.target?.value || '';
  gaRenderPropPicker(GA.propFilter);
});
on('gaPropSearch', 'keydown', (e)=>{
  if (e.key === 'Escape') gaClosePropPicker();
});
on('gaKeyBreakdown', 'change', ()=>{
  GA.breakdown = $('gaKeyBreakdown')?.value || GA_DEFAULT_BREAKDOWN;
  void gaSetStored({ [GA_STORAGE_KEYS.breakdown]: GA.breakdown });
});
on('gaKeyEventToggle', 'click', (e)=>{
  e.preventDefault();
  $('gaKeyEventMenu')?.classList.contains('hidden') ? gaOpenKeyEventPicker() : gaCloseKeyEventPicker();
});
on('gaKeyEventSearch', 'input', (e)=>{
  GA.keyEventFilter = e.target?.value || '';
  gaRenderKeyEventPicker();
});
on('gaKeyEventSearch', 'keydown', (e)=>{
  if (e.key === 'Escape') gaCloseKeyEventPicker();
});
document.addEventListener('click', (e)=>{
  const gaPropShell = e.target?.closest?.('.ga-prop-shell');
  if (!gaPropShell) gaClosePropPicker();
  const shell = e.target?.closest?.('.ga-picker-shell');
  if (!shell) gaCloseKeyEventPicker();
});
on('navAnalytics','click', async ()=>{
  try{
    await loadGaPropsOnce();
    const r = await send({ type: "gaDetectFromTab" });
    if (r.ok && r.data && r.data.propertyId){
      const sel = $('gaProps');
      if (sel && Array.from(sel.options).some(o => o.value === r.data.propertyId)){
        await gaSetSelectedProperty(r.data.propertyId);
        clearResult(`Matched GA4 property via ${r.data.via}: ${r.data.propertyName} (G-ID: ${r.data.measurementId || '—'})`, 'gaResult');
      }
    } else if (r.ok && r.data?.foundGIds?.length){
      clearResult(`Found GA IDs on page: ${r.data.foundGIds.join(', ')} — no matching property found in your account.`, 'gaResult');
    } else {
      await gaHandlePropertyChange();
    }
  }catch(e){
    // non-fatal; keep UI usable
  }
});
$('gaRange').addEventListener('change', ()=>{
  const custom = $('gaRange').value === 'custom';
  $('gaCustom').style.display = custom ? 'grid' : 'none';
});
$('gaLoad').addEventListener('click', ()=>{ gaLoadActiveReport({ forceRefresh:false }); });
on('gaRefreshProps', 'click', async ()=>{
  try{
    await loadGaPropsOnce({ forceRefresh:true });
  }catch(e){
    clearResult('❌ ' + (e?.message || e), 'gaResult');
  }
});
on('settingsRefreshGa', 'click', async ()=>{
  try{
    await loadGaPropsOnce({ forceRefresh:true });
  }catch(e){
    clearResult('❌ ' + (e?.message || e), 'gaResult');
  }
});
on('gaRefreshData', 'click', ()=>{ gaLoadActiveReport({ forceRefresh:true }); });
$('gaExport').addEventListener('click', ()=>{
  if (!GA.lastExport) return clearResult('Load Analytics first.', 'gaResult');
  const blob = new Blob([GA.lastExport.csv], { type:'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = GA.lastExport.filename;
  a.click();
  URL.revokeObjectURL(url);
});

// Renderers
function renderGaReport(currData, meta, prevData){
  if (!gaHasRows(currData)){
    gaResetExport();
    renderHtml('gaResult', `<div class="card">No data for ${meta.start} → ${meta.end}.</div>`);
    return;
  }

  const metricIndexByName = Object.fromEntries((currData.metricHeaders || []).map((h, i) => [h.name, i]));
  const dimLabel = GA_DIM_LABELS[meta.dim] || meta.dim;
  const sums = gaSummarizeReport(currData);
  const prevSums = gaHasRows(prevData) ? gaSummarizeReport(prevData) : null;

  const metric = $('gaMetric')?.value || 'activeUsers';
  const mIdx = metricIndexByName[metric] ?? 0;
  const series = currData.rows.map(r => Number(r.metricValues?.[mIdx]?.value || 0));
  const kpiGrid = `
    <div class="kpi-grid">
      ${gaKpi('Active users', 'activeUsers', sums, prevSums)}
      ${gaKpi('Sessions', 'sessions', sums, prevSums)}
      ${gaKpi('Views', 'screenPageViews', sums, prevSums)}
      ${gaKpi('Event count', 'eventCount', sums, prevSums)}
    </div>
    ${meta.dim === 'date' ? gaSparklineSVG(series) : ''}
  `;

  renderHtml('gaResult', `
    <div class="card"><h4>GA4 Summary (${meta.start} → ${meta.end})</h4>${kpiGrid}</div>
    ${gaBuildTableCard(`Breakdown by ${dimLabel}`, currData)}
  `);

  gaSetExport(`ga4-${meta.dim}-${meta.start}-${meta.end}.csv`, gaToCSV(currData));
}
function renderGaKeyEventsReport(currBundle, meta, prevBundle){
  const summarySource = gaPickSummaryReport(currBundle);
  if (!summarySource){
    gaResetExport();
    renderHtml('gaResult', `<div class="card">No key-event data for ${meta.start} → ${meta.end}.</div>`);
    return;
  }

  const prevSummarySource = gaPickSummaryReport(prevBundle);
  const sums = gaSummarizeReport(summarySource);
  const prevSums = prevSummarySource ? gaSummarizeReport(prevSummarySource) : null;
  const series = gaMetricSeries(currBundle.trend, 'keyEvents');
  const selectionLabel = meta.eventNames.length === 1 ? meta.eventNames[0] : `${meta.eventNames.length} key events selected`;
  const breakdownLabel = GA_DIM_LABELS[meta.breakdown] || meta.breakdown;
  const kpiGrid = `
    <div class="kpi-grid">
      ${gaKpi('Key events', 'keyEvents', sums, prevSums)}
      ${gaKpi('Event count', 'eventCount', sums, prevSums)}
      ${gaKpi('Active users', 'activeUsers', sums, prevSums)}
      ${gaKpi('Sessions', 'sessions', sums, prevSums)}
    </div>
    ${series.length ? gaSparklineSVG(series) : ''}
  `;

  renderHtml('gaResult', `
    <div class="card">
      <h4>Key Event Summary (${meta.start} → ${meta.end})</h4>
      <p style="margin:0 0 12px;color:var(--muted)">${escapeHtml(selectionLabel)}</p>
      ${kpiGrid}
    </div>
    ${gaBuildTableCard('Per-event totals', currBundle.eventTotals)}
    ${gaBuildTableCard(`Breakdown by ${breakdownLabel}`, currBundle.breakdown)}
  `);

  gaSetExport(`ga4-key-events-${meta.breakdown}-${meta.start}-${meta.end}.csv`, gaToCSV(currBundle.breakdown));
}
function gaSummarizeReport(report){
  const sums = {};
  for (const row of (report?.rows || [])){
    row.metricValues?.forEach((mv, index) => {
      const key = report.metricHeaders?.[index]?.name;
      if (!key) return;
      sums[key] = (sums[key] || 0) + Number(mv.value || 0);
    });
  }
  return sums;
}
function gaMetricSeries(report, metricName){
  const metricIndex = Object.fromEntries((report?.metricHeaders || []).map((h, i) => [h.name, i]))[metricName];
  if (metricIndex == null) return [];
  return (report?.rows || []).map(row => Number(row.metricValues?.[metricIndex]?.value || 0));
}
function gaPickSummaryReport(bundle){
  if (gaHasRows(bundle?.eventTotals)) return bundle.eventTotals;
  if (gaHasRows(bundle?.trend)) return bundle.trend;
  if (gaHasRows(bundle?.breakdown)) return bundle.breakdown;
  return null;
}
function gaKpi(label, key, sums, prevSums){
  const val = sums[key] || 0;
  const prev = prevSums ? (prevSums[key] || 0) : null;
  const d = gaPctDelta(val, prev);
  return `<div class="kpi">
    <h5>${escapeHtml(label)}</h5>
    <span class="val">${gaNf(val)}</span>
    <span class="delta ${d.cls}">${d.text}</span>
  </div>`;
}
function gaBuildTableCard(title, data){
  if (!gaHasRows(data)){
    return `
      <div class="card">
        <h4>${escapeHtml(title)}</h4>
        <p style="margin:0;color:var(--muted)">No data available for this selection.</p>
      </div>
    `;
  }
  const header = (data.dimensionHeaders || []).map(h => GA_DIM_LABELS[h.name] || h.name)
    .concat((data.metricHeaders || []).map(h => gaMetricLabel(h.name)));
  const rows = data.rows.map(row => {
    const dims = (row.dimensionValues || []).map(v => `<td>${escapeHtml(v.value || '')}</td>`);
    const mets = (row.metricValues || []).map(v => `<td style="text-align:right">${gaNf(v.value || 0)}</td>`);
    return `<tr>${dims.join('')}${mets.join('')}</tr>`;
  }).join('');
  const thead = `<tr>${header.map(x => `<th>${escapeHtml(x)}</th>`).join('')}</tr>`;
  return `
    <div class="card">
      <h4>${escapeHtml(title)}</h4>
      <div style="max-height:260px;overflow:auto;border:1px solid var(--border);border-radius:8px">
        <table class="table-compact"><thead>${thead}</thead><tbody>${rows}</tbody></table>
      </div>
    </div>
  `;
}
function gaNf(n){ return Number(n || 0).toLocaleString(); }
function gaPctDelta(curr, prev){
  if (prev == null || prev === 0) return { text:"—", cls:"" };
  const d = ((curr - prev) / prev) * 100;
  return { text: (d > 0 ? "+" : "") + d.toFixed(1) + "%", cls: d >= 0 ? "up" : "down" };
}
function gaSparklineSVG(vals){
  const w = 120, h = 28, p = 2;
  if (!vals || !vals.length) return "";
  const min = Math.min(...vals), max = Math.max(...vals);
  const sx = i => p + (i * (w - 2 * p) / Math.max(1, vals.length - 1));
  const sy = v => max === min ? h / 2 : p + (h - 2 * p) * (1 - (v - min) / (max - min));
  let d = "";
  vals.forEach((v, i) => { d += (i ? " L" : "M") + sx(i).toFixed(1) + " " + sy(v).toFixed(1); });
  return `<svg class="spark" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}"><path d="${d}" fill="none" stroke="currentColor" stroke-width="1.5"/></svg>`;
}
function gaToCSV(data){
  const dimH = (data?.dimensionHeaders || []).map(h => h.name);
  const metH = (data?.metricHeaders || []).map(h => h.name);
  const head = dimH.concat(metH);
  const lines = [ head.join(",") ];
  for (const r of (data?.rows || [])){
    const dims = (r.dimensionValues || []).map(v => `"${String(v.value || "").replace(/"/g,'""')}"`);
    const mets = (r.metricValues || []).map(v => String(v.value || "0"));
    lines.push(dims.concat(mets).join(","));
  }
  return lines.join("\n");
}


// Ends GA4

// ===== CallRail =====
const CR = {
  accounts: [],
  companies: [],
  lastRows: null,
  lastMeta: null,
  inited: false,
  accountCache: null,
  companyCache: null,
  reportCache: null
};

function crIso(d){
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
}
function isoAddDays(iso, delta){
  const d = new Date(`${iso}T00:00:00`);
  d.setDate(d.getDate() + delta);
  return crIso(d);
}
function monthStartISO(d=new Date()){
  const x = new Date(d);
  x.setDate(1);
  return crIso(x);
}
function monthEndISO(d=new Date()){
  const x = new Date(d);
  // last day of month
  x.setMonth(x.getMonth()+1);
  x.setDate(0);
  return crIso(x);
}

function crSetStatus(msg, isError=false){
  const el = $('crStatus');
  if (el) el.innerHTML = isError ? `❌ ${escapeHtml(msg)}` : escapeHtml(msg);
  const panel = $('crPanelStatus');
  if (panel) panel.innerHTML = isError ? `❌ ${escapeHtml(msg)}` : escapeHtml(msg);
}
function crRenderListCacheNote(){
  setCacheNote('crListCacheStatus', combineCacheMeta([CR.accountCache, CR.companyCache]), {
    network: 'CallRail lists refreshed',
    cached: 'Using cached CallRail accounts and companies',
    mixed: 'Using a mix of fresh and cached CallRail lists',
    stale: 'Refresh failed. Showing cached CallRail lists'
  });
}
function crRenderReportCacheNote(){
  setCacheNote('crReportCacheStatus', CR.reportCache, {
    network: 'CallRail summary refreshed',
    cached: 'Using cached CallRail summary',
    mixed: 'Using a mix of fresh and cached CallRail summary data',
    stale: 'Refresh failed. Showing cached CallRail summary'
  });
}

async function crGetStored(){
  return new Promise(resolve => {
    chrome.storage.local.get([
      'callrailApiKey','callrailAccountNumericId','callrailCompanyId',
      'callrailRange','callrailStart','callrailEnd','callrailGroupBy',
      'callrailDevice','callrailLeadStatus','callrailFirstTime','callrailMinDur','callrailMaxDur'
    ], resolve);
  });
}
async function crSetStored(obj){
  return new Promise(resolve => chrome.storage.local.set(obj, resolve));
}

function crFillSelect(selId, items, {placeholder="Select…", valueKey="value", labelKey="label", allowEmpty=false, emptyLabel="All"}={}){
  const sel = $(selId); if(!sel) return;
  sel.innerHTML = '';
  if (allowEmpty){
    const opt = document.createElement('option');
    opt.value = '';
    opt.textContent = emptyLabel;
    sel.appendChild(opt);
  }
  if (!items?.length){
    const opt = document.createElement('option');
    opt.value = '';
    opt.textContent = placeholder;
    sel.appendChild(opt);
    return;
  }
  for (const it of items){
    const opt = document.createElement('option');
    opt.value = it[valueKey];
    opt.textContent = it[labelKey];
    sel.appendChild(opt);
  }
}

function crComputeDates(range){
  const today = todayISO();
  const d = new Date();
  if (range === 'today') return {start: today, end: today};
  if (range === 'yesterday'){
    const y = isoAddDays(today, -1);
    return {start: y, end: y};
  }
  if (range === 'recent7') return {start: isoAddDays(today, -7), end: today};
  if (range === 'last7') return {start: isoAddDays(today, -7), end: isoAddDays(today, -1)};
  if (range === 'last30') return {start: isoAddDays(today, -30), end: isoAddDays(today, -1)};
  if (range === 'thisMonth') return {start: monthStartISO(d), end: today};
  if (range === 'lastMonth'){
    const prev = new Date(); prev.setMonth(prev.getMonth()-1);
    return {start: monthStartISO(prev), end: monthEndISO(prev)};
  }
  // custom
  return {start: '', end: ''};
}

function crRowsToCSV(rows, meta){
  const head = ['Source','Total Calls','Answered Calls','Missed Calls','Voicemails','Returning Callers','First-Time Callers','Average Duration'];
  const lines = [head.join(',')];
  for (const r of (rows||[])){
    const line = [
      r.key,
      r.total_calls,
      r.answered_calls,
      r.missed_calls,
      r.voicemails,
      r.returning_callers,
      r.first_time_callers,
      r.formatted_average_duration
    ].map(v => {
      const s = String(v ?? '');
      return /[",\n]/.test(s) ? `"${s.replace(/"/g,'""')}"` : s;
    }).join(',');
    lines.push(line);
  }
  const prefix = meta ? `# ${meta.companyName||''} | ${meta.start}..${meta.end} | group_by=${meta.groupBy}\n` : '';
  return prefix + lines.join('\n');
}

function crRenderTable(rows, meta){
  const box = $('crResult'); if(!box) return;
  if (!rows?.length){
    renderHtml('crResult', `<div class="card">No call data found for the selected range/filters.</div>`);
    return;
  }
  const badges = [
    badge(`${escapeHtml(meta.companyName || 'All companies')}`),
    badge(`${escapeHtml(meta.start)} → ${escapeHtml(meta.end)}`),
    badge(`Group: ${escapeHtml(meta.groupByLabel)}`)
  ].join(' ');

  const total = meta?.total_results?.total_calls ?? rows.reduce((s,r)=>s+(r.total_calls||0),0);
  const metaRow = `
    <div class="cr-meta">
      ${badges}
      <span class="badge">Total calls: <b>${Number(total||0).toLocaleString()}</b></span>
    </div>
  `;

  const body = rows.map(r => `
    <tr>
      <td>${escapeHtml(r.key || '—')}</td>
      <td class="num">${Number(r.total_calls||0).toLocaleString()}</td>
      <td class="num">${Number(r.answered_calls||0).toLocaleString()}</td>
      <td class="num">${Number(r.missed_calls||0).toLocaleString()}</td>
      <td class="num">${Number(r.voicemails||0).toLocaleString()}</td>
      <td class="num">${Number(r.returning_callers||0).toLocaleString()}</td>
      <td class="num">${Number(r.first_time_callers||0).toLocaleString()}</td>
      <td class="num">${escapeHtml(r.formatted_average_duration || (r.average_duration!=null ? (r.average_duration+'s') : '—'))}</td>
    </tr>
  `).join('');

  renderHtml('crResult', `
    <div class="card">${metaRow}
      <table class="cr-table">
        <thead>
          <tr>
            <th>Source</th>
            <th class="num">Total Calls</th>
            <th class="num">Answered Calls</th>
            <th class="num">Missed Calls</th>
            <th class="num">Voicemails</th>
            <th class="num">Returning Callers</th>
            <th class="num">First-Time Callers</th>
            <th class="num">Average Duration</th>
          </tr>
        </thead>
        <tbody>
          ${body}
        </tbody>
      </table>
    </div>
  `);
}

async function crLoadAccounts({ forceRefresh=false } = {}){
  crSetStatus('Connecting to CallRail…');
  const r = await send({ type: 'callrailListAccounts', forceRefresh: !!forceRefresh });
  if (!r.ok) throw new Error(r.error || 'CallRail error');
  CR.accountCache = r.cache || null;
  CR.accounts = (r.data?.accounts || []).map(a => ({
    id: a.id,
    numeric_id: a.numeric_id,
    name: a.name
  }));

  // prefer numeric_id for subsequent endpoints
  const items = CR.accounts.map(a => ({ value: String(a.numeric_id || a.id || ''), label: `${a.name} • ${a.numeric_id || a.id}` }));
  crFillSelect('crAccount', items, {placeholder:'Select account', valueKey:'value', labelKey:'label'});
  const stored = await crGetStored();
  const sel = $('crAccount');
  if (sel){
    const preferred = stored.callrailAccountNumericId;
    if (preferred && Array.from(sel.options).some(o=>o.value===String(preferred))) sel.value = String(preferred);
    else if (sel.options.length) sel.selectedIndex = 0;
  }
  await crSetStored({ callrailAccountNumericId: $('crAccount')?.value || '' });
  await crLoadCompanies({ forceRefresh });
  crRenderListCacheNote();
  crSetStatus('Connected ✅');
}

async function crLoadCompanies({ forceRefresh=false } = {}){
  const accountId = $('crAccount')?.value;
  if (!accountId) return;
  const r = await send({ type:'callrailListCompanies', accountId, forceRefresh: !!forceRefresh });
  if (!r.ok) throw new Error(r.error || 'Failed to list companies');
  CR.companyCache = r.cache || null;
  CR.companies = (r.data?.companies || []).map(c => ({ id:c.id, name:c.name }));
  const items = CR.companies.map(c => ({ value: c.id, label: c.name }));
  crFillSelect('crCompany', items, {placeholder:'All companies', valueKey:'value', labelKey:'label', allowEmpty:true, emptyLabel:'All companies'});
  const stored = await crGetStored();
  const sel = $('crCompany');
  if (sel && stored.callrailCompanyId && Array.from(sel.options).some(o=>o.value===stored.callrailCompanyId)){
    sel.value = stored.callrailCompanyId;
  }
  crRenderListCacheNote();
}

async function crLoadSummary({ forceRefresh=false } = {}){
  const accountId = $('crAccount')?.value;
  if (!accountId) return crSetStatus('Select an account first.', true);
  const companyId = $('crCompany')?.value || '';
  const companyName = $('crCompany')?.selectedOptions?.[0]?.textContent || '';
  const range = $('crRange')?.value || 'recent7';
  const groupBy = $('crGroupBy')?.value || 'source';
  const groupByLabel = $('crGroupBy')?.selectedOptions?.[0]?.textContent || groupBy;
  const device = $('crDevice')?.value || 'all';
  const leadStatus = $('crLeadStatus')?.value || '';
  const firstTime = $('crFirstTime')?.value; // '', 'true', 'false'
  const minDur = $('crMinDur')?.value;
  const maxDur = $('crMaxDur')?.value;

  let start, end;
  if (range === 'custom'){
    start = $('crStart')?.value;
    end = $('crEnd')?.value || todayISO();
    if (!start) return crSetStatus('Select a custom start date.', true);
  }else{
    const d = crComputeDates(range);
    start = d.start; end = d.end;
  }

  await crSetStored({
    callrailAccountNumericId: accountId,
    callrailCompanyId: companyId,
    callrailRange: range,
    callrailStart: start,
    callrailEnd: end,
    callrailGroupBy: groupBy,
    callrailDevice: device,
    callrailLeadStatus: leadStatus,
    callrailFirstTime: firstTime ?? '',
    callrailMinDur: minDur ?? '',
    callrailMaxDur: maxDur ?? ''
  });

  crSetStatus(forceRefresh ? 'Refreshing call summary…' : 'Loading call summary…');
  renderHtml('crResult', `<div class="card">Loading…</div>`);

  const r = await send({
    type:'callrailCallSummary',
    accountId,
    companyId,
    companyName,
    start_date: start,
    end_date: end,
    group_by: groupBy,
    groupByLabel,
    device,
    lead_status: leadStatus,
    first_time_callers: firstTime,
    min_duration: minDur,
    max_duration: maxDur,
    forceRefresh: !!forceRefresh
  });
  if (!r.ok) return crSetStatus(r.error || 'CallRail error', true);

  const rows = r.data?.rows || [];
  const meta = r.data?.meta || {};
  CR.reportCache = r.cache || null;
  CR.lastRows = rows;
  CR.lastMeta = meta;
  crRenderTable(rows, meta);
  crRenderReportCacheNote();
  crSetStatus('Loaded ✅');
}

async function crEnsureInit(){
  if (CR.inited) return;
  CR.inited = true;

  // restore saved values
  const stored = await crGetStored();
  const hasKey = !!stored.callrailApiKey;
  $('crDisconnect')?.setAttribute('style', hasKey ? '' : 'opacity:.6; pointer-events:none');
  if (hasKey){
    $('crApiKey').value = '••••••••••';
  }

  // Restore ranges/filters
  if (stored.callrailRange) $('crRange').value = stored.callrailRange;
  if (stored.callrailGroupBy) $('crGroupBy').value = stored.callrailGroupBy;
  if (stored.callrailDevice) $('crDevice').value = stored.callrailDevice;
  if (stored.callrailLeadStatus != null) $('crLeadStatus').value = stored.callrailLeadStatus;
  if (stored.callrailFirstTime != null) $('crFirstTime').value = stored.callrailFirstTime;
  if (stored.callrailMinDur != null) $('crMinDur').value = stored.callrailMinDur;
  if (stored.callrailMaxDur != null) $('crMaxDur').value = stored.callrailMaxDur;

  const range = $('crRange').value;
  $('crCustom').classList.toggle('hidden', range !== 'custom');
  if (stored.callrailStart) $('crStart').value = stored.callrailStart;
  if (stored.callrailEnd) $('crEnd').value = stored.callrailEnd;

  // wire events
  on('crToggleFilters','click', ()=> $('crFilters')?.classList.toggle('hidden'));
  on('crRange','change', ()=>{
    const isCustom = $('crRange').value === 'custom';
    $('crCustom').classList.toggle('hidden', !isCustom);
    if (!isCustom){
      const d = crComputeDates($('crRange').value);
      if ($('crStart')) $('crStart').value = d.start;
      if ($('crEnd')) $('crEnd').value = d.end;
    }
  });
  on('crAccount','change', async ()=>{ await crSetStored({ callrailAccountNumericId: $('crAccount').value }); await crLoadCompanies(); });
  on('crCompany','change', ()=> crSetStored({ callrailCompanyId: $('crCompany').value||'' }));
  on('crRefreshLists','click', async ()=>{
    try{
      await crLoadAccounts({ forceRefresh:true });
    }catch(e){ crSetStatus(e.message || String(e), true); }
  });
  on('settingsRefreshCallrail','click', async ()=>{
    try{
      await crLoadAccounts({ forceRefresh:true });
    }catch(e){ crSetStatus(e.message || String(e), true); }
  });

  on('crSaveKey','click', async ()=>{
    try{
      const val = $('crApiKey')?.value?.trim();
      if (!val || val === '••••••••••'){
        return crSetStatus('Paste your CallRail API key first.', true);
      }
      await crSetStored({ callrailApiKey: val });
      await send({ type:'callrailInvalidateCache' }).catch(()=>null);
      CR.accountCache = null;
      CR.companyCache = null;
      CR.reportCache = null;
      crRenderListCacheNote();
      crRenderReportCacheNote();
      $('crApiKey').value = '••••••••••';
      $('crDisconnect')?.setAttribute('style','');
      await crLoadAccounts({ forceRefresh:true });
    }catch(e){ crSetStatus(e.message || String(e), true); }
  });
  on('crDisconnect','click', async ()=>{
    await crSetStored({ callrailApiKey:'', callrailAccountNumericId:'', callrailCompanyId:'' });
    await send({ type:'callrailInvalidateCache' }).catch(()=>null);
    CR.accountCache = null;
    CR.companyCache = null;
    CR.reportCache = null;
    $('crApiKey').value = '';
    $('crAccount').innerHTML = '<option value="">Select account</option>';
    $('crCompany').innerHTML = '<option value="">All companies</option>';
    $('crResult').innerHTML = '';
    $('crDisconnect')?.setAttribute('style','opacity:.6; pointer-events:none');
    crRenderListCacheNote();
    crRenderReportCacheNote();
    crSetStatus('Disconnected.');
  });

  on('crLoad','click', ()=> crLoadSummary({ forceRefresh:false }));
  on('crRefreshData','click', ()=> crLoadSummary({ forceRefresh:true }));
  on('crExport','click', ()=>{
    if (!CR.lastRows?.length) return;
    const csv = crRowsToCSV(CR.lastRows, CR.lastMeta);
    const blob = new Blob([csv], {type:'text/csv'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `callrail-${(CR.lastMeta?.groupBy||'source')}-${(CR.lastMeta?.start||'')}-${(CR.lastMeta?.end||'')}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  });

  // If key already stored, auto-connect + load accounts once
  if (hasKey){
    try{ await crLoadAccounts(); }
    catch(e){ crSetStatus(e.message || String(e), true); }
  }else{
    crSetStatus('Save your CallRail API key in Settings to load accounts.');
    crFillSelect('crAccount', [], {placeholder:'Save API key to load accounts'});
    crFillSelect('crCompany', [], {placeholder:'All companies', allowEmpty:true, emptyLabel:'All companies'});
    crRenderListCacheNote();
    crRenderReportCacheNote();
  }
}

// initialize CallRail when tab opened
on('navCallRail','click', ()=>{ crEnsureInit(); });
on('navSettings','click', ()=>{ crEnsureInit(); });

// Ends CallRail


/* ---------- Active tab helpers ---------- */
async function getActiveTab(){ const [tab] = await chrome.tabs.query({ active:true, currentWindow:true }); return tab; }
async function getActiveTabUrl(){
  try{ const tab = await getActiveTab(); const url = tab?.url || ''; return /^https?:/i.test(url) ? url : ''; }
  catch{ return ''; }
}
function chooseBestProperty(sites, pageUrl){
  if(!Array.isArray(sites) || !pageUrl) return null;
  let best = null, bestScore = -1, bestLen = -1;
  let host = ''; try { host = new URL(pageUrl).hostname || ''; } catch{}
  for(const s of sites){
    const site = s.siteUrl; let covers = false, score = 0, len = site.length;
    if(site.startsWith('sc-domain:')){
      const domain = site.split(':')[1];
      if(host === domain || (host && host.endsWith('.'+domain))){ covers = true; score = 1; len = domain.length; }
    } else if(pageUrl.startsWith(site)){ covers = true; score = 2; len = site.length; }
    if(covers){ if(score > bestScore || (score === bestScore && len > bestLen)){ best = site; bestScore = score; bestLen = len; } }
  }
  return best;
}

/* ---------- Renderers ---------- */
function ms(v){ return typeof v==='number' ? `${(v/1000).toFixed(2)}s` : (v||'—'); }
function renderIndexing(data){
  const i = data?.inspectionResult || data; if(!i){ clearResult('No data'); return; }
  const idx = i.indexStatusResult || {};
  const cards = [];
  cards.push(`<div class="card summary-card">
    <div class="summary-card__header">
      <div>
        <h4>Indexing status</h4>
        <p>Coverage and canonical signals for the inspected URL.</p>
      </div>
      ${stateBadge(idx?.verdict || 'UNKNOWN')}
    </div>
    <div class="meta-line">
      <span class="badge">${escapeHtml(idx?.coverageState || 'Unknown')}</span>
      <span class="badge">${escapeHtml(idx?.robotsTxtState || '—')}</span>
      <span class="badge">${escapeHtml(idx?.lastCrawlTime || 'No crawl date')}</span>
    </div>
    ${kv('User canonical', idx?.userCanonical || '—')}
    ${kv('Google canonical', idx?.googleCanonical || '—')}
  </div>`);
  if(i.mobileUsabilityResult){
    cards.push(`<div class="card summary-card">
      <div class="summary-card__header">
        <div>
          <h4>Mobile usability</h4>
          <p>Quick verdict from URL Inspection.</p>
        </div>
        ${stateBadge(i.mobileUsabilityResult.verdict || 'UNKNOWN')}
      </div>
    </div>`);
  }
  renderHtml('result', cards.join(''));
}


function renderPSI(data){
  const lr = data?.lighthouseResult || {};
  const audits = lr.audits || {};
  const cats = lr.categories || {};
  const metrics = audits.metrics?.details?.items?.[0] || {};
  const shot = audits['final-screenshot']?.details?.data || null;

  // Field data (CrUX) containers
  const pageField   = data?.loadingExperience || {};
  const originField = data?.originLoadingExperience || {};

  // Existing badges
  const perf = Math.round((cats.performance?.score ?? 0) * 100);
  const seo  = Math.round((cats.seo?.score ?? 0) * 100);
  const acc  = Math.round((cats.accessibility?.score ?? 0) * 100);
  const bp   = Math.round((cats['best-practices']?.score ?? 0) * 100);

  // helpers
  const pct = (n)=> typeof n === 'number' ? `${Math.round(n)}%` : '—';
  const ms2 = (n)=> ms(n); // keep your existing ms() formatting

  // Build a compact stacked bar for CrUX distributions (inline styles so no CSS edits needed)
  function cruxBar(m, metricKey){
    if (!m || !m.metrics || !m.metrics[metricKey]) return '—';
    const mc = m.metrics[metricKey];
    const dist = mc.distributions || [];
    const p = mc.percentile;
    const cat = mc.category || '';
    const seg = (prop, color) =>
      `<span style="display:inline-block;height:100%;width:${Math.max(1, Math.round((prop||0)*100))}%;background:${color}"></span>`;
    const labelVal = (metricKey.includes('CUMULATIVE_LAYOUT_SHIFT')
      ? (p!=null ? (p/100).toFixed(3) : '—')
      : (p!=null ? `${Math.round(p)} ms` : '—'));

    return `
      <div style="position:relative;height:12px;border-radius:999px;border:1px solid var(--border);overflow:hidden;background:#1b2130">
        ${seg(dist[0]?.proportion, 'rgba(25,195,125,.5)')}
        ${seg(dist[1]?.proportion, 'rgba(245,165,36,.5)')}
        ${seg(dist[2]?.proportion, 'rgba(239,68,68,.5)')}
        <span style="position:absolute;left:8px;top:50%;transform:translateY(-50%);font-size:11px;opacity:.8">
          ${cat} • P${labelVal}
        </span>
      </div>`;
  }

  const cards = [];

  // Summary
  cards.push(`<div class="card summary-card">
    <div class="summary-card__header">
      <div>
        <h4>Mobile audit</h4>
        <p>Lighthouse scores for the live test.</p>
      </div>
      <span class="badge">${escapeHtml(lr?.fetchTime || 'Live')}</span>
    </div>
    <div class="metric-strip">
      <div class="metric-tile"><span>Performance</span><strong>${perf}/100</strong></div>
      <div class="metric-tile"><span>SEO</span><strong>${seo}/100</strong></div>
      <div class="metric-tile"><span>Accessibility</span><strong>${acc}/100</strong></div>
      <div class="metric-tile"><span>Best practices</span><strong>${bp}/100</strong></div>
    </div>
  </div>`);

  // Lab metrics
  cards.push(`<div class="card">
    <h4>Core/Key Metrics (Lab)</h4>
    ${kv('LCP',               ms2(metrics['largest-contentful-paint']))}
    ${kv('TBT (INP proxy)',   ms2(metrics['total-blocking-time']))}
    ${kv('CLS',               (typeof metrics['cumulative-layout-shift']==='number' ? metrics['cumulative-layout-shift'].toFixed(3) : '—'))}
    ${kv('FCP',               ms2(metrics['first-contentful-paint']))}
    ${kv('TTI',               ms2(metrics['interactive']))}
    ${kv('Speed Index',       ms2(metrics['speed-index']))}
  </div>`);

  // CrUX (page)
  const cruxPage =
    kv('FCP (field)', cruxBar(pageField, 'FIRST_CONTENTFUL_PAINT_MS')) +
    kv('LCP (field)', cruxBar(pageField, 'LARGEST_CONTENTFUL_PAINT_MS')) +
    kv('INP (field)', cruxBar(pageField, 'INTERACTION_TO_NEXT_PAINT')) +
    kv('CLS (field)', cruxBar(pageField, 'CUMULATIVE_LAYOUT_SHIFT_SCORE')) +
    kv('TTFB (field)', cruxBar(pageField, 'EXPERIMENTAL_TIME_TO_FIRST_BYTE'));
  if (cruxPage.trim()) {
    cards.push(`<div class="card"><h4>CrUX (This Page)</h4>${cruxPage}</div>`);
  }

  // CrUX (origin)
  const cruxOrigin =
    kv('FCP (origin)', cruxBar(originField, 'FIRST_CONTENTFUL_PAINT_MS')) +
    kv('LCP (origin)', cruxBar(originField, 'LARGEST_CONTENTFUL_PAINT_MS')) +
    kv('INP (origin)', cruxBar(originField, 'INTERACTION_TO_NEXT_PAINT')) +
    kv('CLS (origin)', cruxBar(originField, 'CUMULATIVE_LAYOUT_SHIFT_SCORE')) +
    kv('TTFB (origin)', cruxBar(originField, 'EXPERIMENTAL_TIME_TO_FIRST_BYTE'));
  if (cruxOrigin.trim()) {
    cards.push(`<div class="card"><h4>CrUX (Origin)</h4>${cruxOrigin}</div>`);
  }

  // Opportunities (top 8)
  const opps = Object.values(audits)
    .filter(a => a?.details?.type === 'opportunity')
    .sort((a,b) => (b?.details?.overallSavingsMs||0) - (a?.details?.overallSavingsMs||0))
    .slice(0,8);
  if (opps.length){
    cards.push(`<div class="card">
      <h4>Opportunities</h4>
      <table style="width:100%;border-collapse:collapse">
        <thead>
          <tr>
            <th style="text-align:left;padding:6px 8px;color:var(--muted);font-weight:600;border-top:1px solid var(--border)">Audit</th>
            <th style="text-align:right;padding:6px 8px;color:var(--muted);font-weight:600;border-top:1px solid var(--border)">Est. Savings</th>
          </tr>
        </thead>
        <tbody>
          ${opps.map(o => `
            <tr>
              <td style="padding:6px 8px;border-top:1px solid var(--border)">${o.title || o.id}</td>
              <td style="padding:6px 8px;border-top:1px solid var(--border);text-align:right">${ms2(o?.details?.overallSavingsMs||0)}</td>
            </tr>`).join('')}
        </tbody>
      </table>
    </div>`);
  }

  // Screenshot
  if (shot) {
    cards.push(`<div class="card">
      <h4>Rendered Screenshot</h4>
      <img alt="Final screenshot" src="${shot}" style="width:100%;border-radius:10px;border:1px solid var(--border)" />
    </div>`);
  }

  renderHtml('result', cards.join(''));
}



function renderPerf(data, meta){
  const row = (data?.rows && data.rows[0]) || { clicks:0, impressions:0, ctr:0, position:0 };
  const scopeLabel = meta.wholeProperty ? 'Whole property' : 'This page';
  const dateLabel = `${meta.start} → ${meta.end}`;
  const cards = [`<div class="card">
    <h4>Performance totals</h4>
    <div class="meta-line">
      <span class="badge">${escapeHtml(scopeLabel)}</span>
      <span class="badge">${escapeHtml(dateLabel)}</span>
    </div>
    <div class="metric-strip">
      <div class="metric-tile"><span>Clicks</span><strong>${Number(row.clicks ?? 0).toLocaleString()}</strong></div>
      <div class="metric-tile"><span>Impressions</span><strong>${Number(row.impressions ?? 0).toLocaleString()}</strong></div>
      <div class="metric-tile"><span>CTR</span><strong>${((row.ctr ?? 0)*100).toFixed(2)}%</strong></div>
      <div class="metric-tile"><span>Avg position</span><strong>${(row.position ?? 0).toFixed(2)}</strong></div>
    </div>
  </div>`];
  renderHtml('result', cards.join(''));
}
function renderOnPage(d){
  let hostLabel = 'Active page';
  try{ hostLabel = new URL(d.url || 'https://example.com').hostname.replace(/^www\./,'') || 'Active page'; }catch{}
  const cards = [`<div class="card summary-card">
    <div class="summary-card__header">
      <div>
        <h4>On-page summary</h4>
        <p>Core page signals pulled from the active tab.</p>
      </div>
      <span class="badge">${escapeHtml(hostLabel)}</span>
    </div>
    <div class="metric-strip">
      <div class="metric-tile"><span>H1s</span><strong>${Number(d.h1Count ?? 0).toLocaleString()}</strong></div>
      <div class="metric-tile"><span>Words</span><strong>${Number(d.wordCount ?? 0).toLocaleString()}</strong></div>
      <div class="metric-tile"><span>Links</span><strong>${Number((d.internalLinks ?? 0) + (d.externalLinks ?? 0)).toLocaleString()}</strong></div>
      <div class="metric-tile"><span>Missing alt</span><strong>${Number(d.imgMissingAlt ?? 0).toLocaleString()}</strong></div>
    </div>
    ${kv('Title', d.title || '—')}
    ${kv('Meta description', d.metaDesc || '—')}
    ${kv('Robots meta', d.robotsMeta || '—')}
    ${kv('Canonical', d.canonical || '—')}
    ${kv('Links (internal / external)', `${d.internalLinks ?? 0} / ${d.externalLinks ?? 0}`)}
    ${kv('Images (total)', `${d.imgCount ?? 0}`)}
    ${kv('JSON-LD types', (d.ldTypes || []).join(', ') || '—')}
  </div>`];
  renderHtml('result', cards.join(''));
}

/* ---------- deep links ---------- */
function openGSCInspect(siteUrl, url){
  const encoded = encodeURIComponent(url);
  const base = 'https://search.google.com/search-console/inspect';
  const qs = `?resource_id=${encodeURIComponent(siteUrl)}&url=${encoded}`;
  chrome.tabs.create({ url: base + qs });
}
const openGSCLive = openGSCInspect;

/* ---------- messaging ---------- */
async function send(msg){ return await chrome.runtime.sendMessage(msg); }

/* ---------- Dates ---------- */
function toISO(daysAgo){ const d = new Date(Date.now() - daysAgo*86400000); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; }
function todayISO(){ const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; }

/* ---------- Account label ---------- */
// safe JWT payload decoder (no deprecated escape())
function parseIdToken(idToken){
  try{
    const base64Url = idToken.split('.')[1];            // JWT payload
    const base64 = base64Url.replace(/-/g,'+').replace(/_/g,'/'); // base64url -> base64
    const bin = atob(base64);                           // binary string
    const bytes = Uint8Array.from(bin, c => c.charCodeAt(0));
    const json = new TextDecoder().decode(bytes);       // UTF-8 decode
    return JSON.parse(json);
  }catch{
    return null;
  }
}

async function setAccountLabel(){
  try{
    const r = await send({ type:'getAccount' });
    const idToken = r?.data || null;
    const payload = idToken ? parseIdToken(idToken) : null;
    const email = payload?.email || '';
    const label = $('accountLabel'); if (label) label.textContent = email ? `Signed in as ${email}` : '';
    const mini = $('accountMini'); if (mini) mini.textContent = email ? `Signed in: ${email}` : 'Signed in: —';
    const settingsEmail = $('settingsAccountEmail'); if (settingsEmail) settingsEmail.textContent = email || 'Not connected';
    const settingsHint = $('settingsAccountHint');
    if (settingsHint) settingsHint.textContent = email ? 'Google Search Console and GA4 requests will use this signed-in account.' : 'Sign in is requested automatically when Search Console or GA4 data is needed.';
  }catch(e){ console.warn(e); }
}

/* ---------- NAV ---------- */
const navMap = {
  navIndex:     "panelIndex",
  navLive:      "panelLive",
  navAnalytics: "panelAnalytics",
  navPerf:      "panelPerf",
  navCallRail:  "panelCallRail",
  navOnPage:    "panelOnPage",
  navSettings:  "panelSettings"
};

function mountNav(){
  const show = (navId)=>{
    Object.values(navMap).forEach(id => { if(id){ const el=$(id); if(el) el.classList.add('hidden'); } });
    const pid = navMap[navId];
    if (pid) {
      const el=$(pid);
      if(el){
        el.classList.remove('hidden');
        animateIn(el);
      }
    }

    // highlight selected
    Object.keys(navMap).forEach(nid => { const b=$(nid); if(b) b.classList.remove('active'); });
    const btn=$(navId); if(btn) btn.classList.add('active');
    setPanelContext(navId);
  };
  Object.keys(navMap).forEach(nid => { const b=$(nid); if(b) b.addEventListener('click', ()=>{ show(nid); setSidebarCollapsed(true, shouldPersistSidebarState()); }); });
  show('navPerf'); // default
}


/* ---------- INIT ---------- */
async function init(){
  await initSidebarUX();
  await gaHydrateState();
  const manifest = chrome.runtime.getManifest();
  $('version').textContent = manifest.version_name || manifest.version || '0';

  clearResult('Sign in if prompted, then pick your property.');
  mountNav();
  setAccountLabel().catch(()=>{});

  // prefill active tab url
  const tabUrlRaw = await getActiveTabUrl().catch(()=> '');
  const tabUrl = tabUrlRaw ? normalizeUrl(tabUrlRaw) : '';
  if (tabUrl && $('inspectUrl')) $('inspectUrl').value = tabUrl;

  // load sites
  try{
    await loadSites();
    clearResult('');
  }catch(e){
    clearResult('Failed to load properties: ' + (e?.message || e));
  }

  // input enables
  $('inspectUrl').addEventListener('input', autoSelectPropertyForUrl);
  $('sites').addEventListener('change', ()=>{ updatePropertyMeta('manual'); setEnabled(); });
  $('sitePickerToggle').addEventListener('click', (e)=>{
    e.preventDefault();
    $('sitePickerMenu')?.classList.contains('hidden') ? openSitePicker() : closeSitePicker();
  });
  $('sitePickerSearch').addEventListener('input', (e)=>{
    state.ui.siteFilter = e.target.value || '';
    renderSitePicker(state.ui.siteFilter);
  });
  $('sitePickerSearch').addEventListener('keydown', (e)=>{
    if (e.key === 'Escape') closeSitePicker();
  });
  document.addEventListener('click', (e)=>{
    const shell = e.target?.closest?.('.property-shell');
    if (!shell) closeSitePicker();
  });

  // Performance pills/scope
  qsa('.pill').forEach(pill => pill.addEventListener('click', ()=>{
    qsa('.pill').forEach(x=>x.classList.remove('active'));
    pill.classList.add('active');
    state.perf.range = pill.dataset.range;
    const isCustom = state.perf.range === 'custom';
    $('customRange').classList.toggle('hidden', !isCustom);
    if(!isCustom){ $('dateStart').value=''; $('dateEnd').value=''; }
    setEnabled();
  }));
  $('scopeSwitch').addEventListener('click', ()=>{
    $('scopeSwitch').classList.toggle('on');
    state.perf.wholeProperty = $('scopeSwitch').classList.contains('on');
    setEnabled();
  });

  // Buttons
  const refreshSites = async ()=>{
    try{
      await loadSites({ forceRefresh:true });
      clearResult('');
    }catch(e){
      clearResult('Failed to load properties: ' + (e?.message || e));
    }
  };
  $('refreshSites').onclick = refreshSites;
  $('settingsRefreshSites').onclick = refreshSites;

  $('useActiveUrl').onclick = async ()=>{
    const url = await getActiveTabUrl().catch(()=> '');
    const normalized = url ? normalizeUrl(url) : '';
    if (!normalized) return clearResult('Open a public http(s) page first.');
    $('inspectUrl').value = normalized;
    autoSelectPropertyForUrl();
  };

  $('inspect').onclick = async ()=>{
    const siteUrl = $('sites')?.value?.trim(); const url = normalizeUrl($('inspectUrl')?.value?.trim() || '');
    if(!url) return clearResult('Enter a valid http(s) URL.');
    if(!propertyCoversUrl(siteUrl, url)) return clearResult('Selected property does not cover this URL.');
    clearResult('Inspecting…');
    const r = await send({ type:'inspect', siteUrl, url });
    if(r.ok){ renderIndexing(r.data); } else { clearResult('❌ ' + r.error); }
  };

  $('openGSC').onclick = ()=>{
    const siteUrl = $('sites')?.value?.trim(); const url = normalizeUrl($('inspectUrl')?.value?.trim() || '');
    if(siteUrl && url) openGSCInspect(siteUrl, url);
  };

  $('liveTest').onclick = async ()=>{
    const siteUrl = $('sites')?.value?.trim(); const url = normalizeUrl($('inspectUrl')?.value?.trim() || '');
    if(!url) return clearResult('Live Test needs a publicly reachable http(s) URL.');
    if(!propertyCoversUrl(siteUrl, url)) return clearResult('Live Test available only for verified properties that cover this URL.');
    clearResult('Running Lighthouse mobile audit…');
    const r = await send({ type:'liveTest', siteUrl, url });
    if(r.ok) renderPSI(r.data); else clearResult('❌ ' + r.error);
  };
  $('openLiveGSC').onclick = ()=>{
    const siteUrl = $('sites')?.value?.trim(); const url = normalizeUrl($('inspectUrl')?.value?.trim() || '');
    if(siteUrl && url) openGSCLive(siteUrl, url);
  };

  $('loadPerf').onclick = ()=>{ loadPerfReport({ forceRefresh:false }); };
  on('refreshPerf', 'click', ()=>{ loadPerfReport({ forceRefresh:true }); });

  $('runOnPage').onclick = async ()=>{
    const tab = await getActiveTab();
    if (!tab || !/^https?:/i.test(tab.url || '')) return clearResult('Open a public http(s) page to run On-Page audit.');
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const abs = (href)=>{ try{ return new URL(href, location.href).href; }catch{ return null; } };
        const txt = (sel)=> (document.querySelector(sel)?.getAttribute('content') || '').trim();
        const title = (document.title || '').trim();
        const metaDesc = txt('meta[name="description"]') || txt('meta[name="Description"]') || '';
        const robotsMeta = (txt('meta[name="robots"]') || txt('meta[name="ROBOTS"]')).toLowerCase();
        const xRobotsTag = '';
        const canonical = abs(document.querySelector('link[rel="canonical"]')?.getAttribute('href') || '') || '';
        let canonicalCrossDomain = false;
        try{
          if (canonical) {
            const ch = new URL(canonical).hostname.replace(/^www\./,'');
            const ph = location.hostname.replace(/^www\./,'');
            canonicalCrossDomain = ch && ph && ch !== ph;
          }
        }catch{}
        const h1s = Array.from(document.querySelectorAll('h1')).map(e=>e.textContent.trim()).filter(Boolean);
        const h1Count = h1s.length;
        const bodyText = (document.body?.innerText || '').replace(/\s+/g,' ').trim();
        const wordCount = bodyText ? bodyText.split(/\s+/).filter(w=>/\w/.test(w)).length : 0;
        const aTags = Array.from(document.querySelectorAll('a[href]'));
        let internalLinks = 0, externalLinks = 0;
        aTags.forEach(a=>{
          const u = abs(a.getAttribute('href')); if(!u) return;
          try{
            const uh = new URL(u).hostname.replace(/^www\./,'');
            const ph = location.hostname.replace(/^www\./,'');
            if(uh === ph) internalLinks++; else externalLinks++;
          }catch{}
        });
        const imgs = Array.from(document.querySelectorAll('img'));
        const imgCount = imgs.length;
        const imgMissingAlt = imgs.filter(i => !i.hasAttribute('alt') || String(i.getAttribute('alt')).trim()==='').length;
        const ldTypes = [];
        Array.from(document.querySelectorAll('script[type="application/ld+json"]')).forEach(s=>{
          try{
            const data = JSON.parse(s.textContent || 'null');
            const collect = (obj)=>{
              if(!obj) return;
              if(Array.isArray(obj)) return obj.forEach(collect);
              const t = obj['@type'];
              if(typeof t === 'string') ldTypes.push(t);
              else if(Array.isArray(t)) t.forEach(x=> typeof x==='string' && ldTypes.push(x));
              if (obj['@graph']) collect(obj['@graph']);
            };
            collect(data);
          }catch{}
        });
        return { url: location.href, title, metaDesc, robotsMeta, xRobotsTag,
                 canonical, canonicalCrossDomain, h1Count, wordCount,
                 internalLinks, externalLinks, imgCount, imgMissingAlt,
                 ldTypes: Array.from(new Set(ldTypes)) };
      }
    });
    renderOnPage(result || {});
  };

  $('logoutSettings').onclick = async ()=>{
    await send({ type:'logout' });
    state.ui.sitesCache = null;
    state.perf.cache = null;
    setSites([]);
    GA.props = null;
    GA.keyEventsByProperty = {};
    GA.keyEventSelections = {};
    GA.keyEventNotices = {};
    GA.keyEventCacheByProperty = {};
    GA.propCacheMeta = null;
    GA.reportCacheMeta = null;
    GA.generalNotice = '';
    if ($('gaProps')) $('gaProps').innerHTML = '<option value="">Select a GA4 property</option>';
    gaRenderKeyEventState();
    gaRenderReportCacheNote();
    setCacheNote('sitesCacheStatus', null);
    setCacheNote('perfCacheStatus', null);
    $('accountLabel').textContent = '';
    $('accountMini').textContent = 'Signed in: —';
    const settingsEmail = $('settingsAccountEmail'); if (settingsEmail) settingsEmail.textContent = 'Not connected';
    const settingsHint = $('settingsAccountHint'); if (settingsHint) settingsHint.textContent = 'Sign in is requested automatically when Search Console or GA4 data is needed.';
    clearResult('Signed out. Reload properties to sign in again.');
  };
}

/* ---------- Kick off ---------- */
const start = () => safe(init);
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', start, { once:true });
} else {
  start();
}
