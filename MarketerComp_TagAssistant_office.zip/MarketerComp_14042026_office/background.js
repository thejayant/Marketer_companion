// background.js — MV3 module service worker
// Google auth via chrome.identity.getAuthToken(), GSC, GA4, CallRail

import * as CFG from "./config.js";

const CLIENT_ID = CFG.CLIENT_ID; // kept for diagnostics / manifest parity
const SCOPES = CFG.SCOPES; // kept for diagnostics / manifest parity

const storage = chrome.storage.local;

async function getFromStore(key){ return (await storage.get(key))[key]; }
async function setInStore(obj){ return await storage.set(obj); }
async function delInStore(key){ return await storage.remove(key); }

const CACHE_INDEX_KEY = "__api_cache_index__";
const CACHE_PREFIX = "api_cache:";
const CACHE_VERSION = "v1";
const CACHE_KIND_LIST = "list";
const CACHE_KIND_REPORT = "report";
const CACHE_POLICY_MANUAL = "manual";
const CACHE_POLICY_TTL_1H = "ttl_1h";
const REPORT_CACHE_TTL_MS = 60 * 60 * 1000;
const REPORT_CACHE_LIMIT = 50;
const GOOGLE_CACHE_SCOPE_KEY = "__google_cache_scope__";
const CALLRAIL_CACHE_SCOPE_KEY = "__callrail_cache_scope__";
const ADS_CACHE_SCOPE_KEY = "__ads_cache_scope__";

async function sha256(str){
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(String(str || "")));
  return Array.from(new Uint8Array(digest), b => b.toString(16).padStart(2, "0")).join("");
}
function stableSerialize(value){
  if (Array.isArray(value)) return `[${value.map(stableSerialize).join(",")}]`;
  if (value && typeof value === "object"){
    return `{${Object.keys(value).sort().map(key => `${JSON.stringify(key)}:${stableSerialize(value[key])}`).join(",")}}`;
  }
  return JSON.stringify(value);
}
function cacheNamespace(service, scope, kind){
  return `${CACHE_VERSION}:service:${service}:scope:${scope}:kind:${kind}`;
}
function cacheStorageKey(namespace, digest){
  return `${CACHE_PREFIX}${namespace}:${digest}`;
}
function cacheTtlMs(policy){
  return policy === CACHE_POLICY_TTL_1H ? REPORT_CACHE_TTL_MS : 0;
}
function cacheLimit(kind){
  return kind === CACHE_KIND_REPORT ? REPORT_CACHE_LIMIT : Infinity;
}
async function getCacheIndex(){
  const raw = await getFromStore(CACHE_INDEX_KEY);
  return raw && typeof raw === "object" ? raw : {};
}
async function setCacheIndex(index){
  await setInStore({ [CACHE_INDEX_KEY]: index });
}
async function buildCacheHandle(service, scope, kind, params){
  const namespace = cacheNamespace(service, scope, kind);
  const digest = await sha256(stableSerialize(params || {}));
  return {
    namespace,
    key: cacheStorageKey(namespace, digest)
  };
}
async function pruneNamespace(index, namespace, { ttlMs=0, limit=Infinity } = {}){
  const current = Array.isArray(index[namespace]) ? index[namespace] : [];
  if (!current.length) return false;
  const now = Date.now();
  const keep = [];
  const removeKeys = [];
  const seen = new Set();
  current
    .sort((a, b) => Number(b?.fetchedAt || 0) - Number(a?.fetchedAt || 0))
    .forEach(item => {
      const key = item?.key;
      if (!key || seen.has(key)){
        if (key) removeKeys.push(key);
        return;
      }
      seen.add(key);
      const fetchedAt = Number(item?.fetchedAt || 0);
      const expired = ttlMs > 0 && (!fetchedAt || (now - fetchedAt) > ttlMs);
      if (expired){
        removeKeys.push(key);
        return;
      }
      keep.push({ key, fetchedAt });
    });

  if (Number.isFinite(limit) && keep.length > limit){
    keep.slice(limit).forEach(item => removeKeys.push(item.key));
    keep.length = limit;
  }

  if (removeKeys.length) await storage.remove(removeKeys);
  if (keep.length) index[namespace] = keep;
  else delete index[namespace];
  return removeKeys.length > 0 || keep.length !== current.length;
}
async function upsertCacheIndex(namespace, key, fetchedAt, { ttlMs=0, limit=Infinity } = {}){
  const index = await getCacheIndex();
  const list = Array.isArray(index[namespace]) ? index[namespace].filter(item => item?.key !== key) : [];
  list.unshift({ key, fetchedAt });
  index[namespace] = list;
  await pruneNamespace(index, namespace, { ttlMs, limit });
  await setCacheIndex(index);
}
async function prepareNamespace(namespace, { ttlMs=0, limit=Infinity } = {}){
  const index = await getCacheIndex();
  const changed = await pruneNamespace(index, namespace, { ttlMs, limit });
  if (changed) await setCacheIndex(index);
}
async function clearCacheNamespaces(predicate){
  const index = await getCacheIndex();
  const removeKeys = [];
  let changed = false;
  for (const [namespace, entries] of Object.entries(index)){
    if (!predicate(namespace)) continue;
    changed = true;
    (entries || []).forEach(item => {
      if (item?.key) removeKeys.push(item.key);
    });
    delete index[namespace];
  }
  if (removeKeys.length) await storage.remove(removeKeys);
  if (changed) await setCacheIndex(index);
}
async function clearGoogleCaches(){
  await clearCacheNamespaces(namespace => namespace.includes(":service:gsc-") || namespace.includes(":service:ga-"));
  await clearCacheNamespaces(namespace => namespace.includes(":service:ads-"));
  await delInStore(GOOGLE_CACHE_SCOPE_KEY);
  await delInStore(ADS_CACHE_SCOPE_KEY);
}
async function clearCallrailCaches(){
  await clearCacheNamespaces(namespace => namespace.includes(":service:callrail-"));
  await delInStore(CALLRAIL_CACHE_SCOPE_KEY);
}
async function clearAdsCaches(){
  await clearCacheNamespaces(namespace => namespace.includes(":service:ads-"));
  await delInStore(ADS_CACHE_SCOPE_KEY);
}
async function getGoogleCacheScope(){
  const profile = await getFromStore("accountProfile");
  if (profile?.email) return `google:${String(profile.email).toLowerCase()}`;
  const token = await getFromStore("token");
  if (token?.access_token) return `google-access:${await sha256(String(token.access_token))}`;
  return `google-ext:${chrome.runtime?.id || "unknown"}`;
}
async function ensureGoogleCacheScope(){
  const scope = await getGoogleCacheScope();
  const prev = await getFromStore(GOOGLE_CACHE_SCOPE_KEY);
  if (prev && prev !== scope) await clearGoogleCaches();
  if (prev !== scope) await setInStore({ [GOOGLE_CACHE_SCOPE_KEY]: scope });
  return scope;
}
async function getCallrailCacheScope(){
  const apiKey = await getFromStore("callrailApiKey");
  if (!apiKey) return "callrail:none";
  return `callrail:${await sha256(String(apiKey))}`;
}
async function ensureCallrailCacheScope(){
  const scope = await getCallrailCacheScope();
  const prev = await getFromStore(CALLRAIL_CACHE_SCOPE_KEY);
  if (prev && prev !== scope) await clearCallrailCaches();
  if (prev !== scope) await setInStore({ [CALLRAIL_CACHE_SCOPE_KEY]: scope });
  return scope;
}
async function getAdsCacheScope(){
  const profile = await getFromStore("accountProfile");
  if (profile?.email) return `ads:${String(profile.email).toLowerCase()}`;
  return `ads-ext:${chrome.runtime?.id || "unknown"}`;
}
async function ensureAdsCacheScope(){
  const scope = await getAdsCacheScope();
  const prev  = await getFromStore(ADS_CACHE_SCOPE_KEY);
  if (prev && prev !== scope) await clearCacheNamespaces(ns => ns.includes(":service:ads-"));
  if (prev !== scope) await setInStore({ [ADS_CACHE_SCOPE_KEY]: scope });
  return scope;
}
async function cachedResource({ service, scope, kind, policy, params, forceRefresh=false, fetcher }){
  const ttlMs = cacheTtlMs(policy);
  const limit = cacheLimit(kind);
  const handle = await buildCacheHandle(service, scope, kind, params);
  await prepareNamespace(handle.namespace, { ttlMs, limit });

  const existing = await getFromStore(handle.key);
  const fetchedAt = Number(existing?.fetchedAt || 0);
  const valid = !!existing && existing.scope === scope && existing.kind === kind && (
    policy === CACHE_POLICY_MANUAL || (fetchedAt && (Date.now() - fetchedAt) <= ttlMs)
  );

  if (!forceRefresh && valid){
    return {
      data: existing.value,
      cache: { source: "cache", fetchedAt }
    };
  }

  try{
    const value = await fetcher();
    const nextFetchedAt = Date.now();
    await setInStore({
      [handle.key]: {
        value,
        fetchedAt: nextFetchedAt,
        scope,
        kind
      }
    });
    await upsertCacheIndex(handle.namespace, handle.key, nextFetchedAt, { ttlMs, limit });
    return {
      data: value,
      cache: { source: "network", fetchedAt: nextFetchedAt }
    };
  }catch(err){
    if (existing && typeof existing === "object" && "value" in existing){
      return {
        data: existing.value,
        cache: {
          source: "cache",
          fetchedAt,
          stale: true
        }
      };
    }
    throw err;
  }
}

function b64UrlEncodeUtf8(str){
  const bytes = new TextEncoder().encode(str);
  let binary = "";
  for (const b of bytes) binary += String.fromCharCode(b);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/,"");
}
function buildPseudoIdToken(payload){
  return `x.${b64UrlEncodeUtf8(JSON.stringify(payload || {}))}.x`;
}
function normalizeTokenResult(result){
  if (!result) return "";
  if (typeof result === "string") return result;
  if (typeof result.token === "string") return result.token;
  return "";
}
async function clearCachedGoogleAuth(){
  try { await chrome.identity.clearAllCachedAuthTokens(); } catch(_) {}
  await delInStore("token");
  await delInStore("accountProfile");
}
async function getAccessToken(interactive = false){
  let result;
  try{
    result = await chrome.identity.getAuthToken({ interactive });
  }catch(err){
    const msg = String(err?.message || err || "");
    throw new Error(msg || "Google auth failed.");
  }

  const accessToken = normalizeTokenResult(result);
  if (!accessToken) throw new Error("Google auth failed: no access token returned.");

  const now = Math.floor(Date.now()/1000);
  const token = {
    access_token: accessToken,
    refresh_token: null,
    expires_at: now + 3300,
    id_token: null
  };
  await setInStore({ token });
  return accessToken;
}
async function fetchGoogleAccountProfile(interactive = false){
  let accessToken = await getAccessToken(interactive);
  let res = await fetch("https://www.googleapis.com/oauth2/v3/userinfo", {
    headers: { Authorization: `Bearer ${accessToken}` }
  });

  if (res.status === 401){
    await clearCachedGoogleAuth();
    accessToken = await getAccessToken(true);
    res = await fetch("https://www.googleapis.com/oauth2/v3/userinfo", {
      headers: { Authorization: `Bearer ${accessToken}` }
    });
  }

  if (!res.ok) throw new Error(await res.text());

  const data = await res.json();
  await setInStore({ accountProfile: data });
  return data;
}
async function getToken(){
  let token = await getFromStore("token");
  const now = Math.floor(Date.now()/1000);

  if (token?.access_token && token?.expires_at && token.expires_at > now) return token;

  try{
    const accessToken = await getAccessToken(false);
    token = await getFromStore("token");
    return token || { access_token: accessToken };
  }catch(_){
    const accessToken = await getAccessToken(true);
    token = await getFromStore("token");
    return token || { access_token: accessToken };
  }
}

// ---------- HTTP helpers ----------
async function apiFetch(token, url, opt = {}){
  let accessToken = token?.access_token || (await getToken()).access_token;

  const o = Object.assign({ headers: {} }, opt);
  o.headers["Authorization"] = `Bearer ${accessToken}`;
  if(opt.body && !o.headers["Content-Type"]) o.headers["Content-Type"] = "application/json";

  let r = await fetch(url, o);

  if(r.status === 401){
    await clearCachedGoogleAuth();
    accessToken = await getAccessToken(true);
    o.headers["Authorization"] = `Bearer ${accessToken}`;
    r = await fetch(url, o);
  }

  if(!r.ok){
    const txt = await r.text();
    throw new Error(txt || ("HTTP "+r.status));
  }
  return r;
}

async function withScopeRetry(run) {
  try {
    return await run();
  } catch (e) {
    const txt = String(e && e.message || e);
    if (/ACCESS_TOKEN_SCOPE_INSUFFICIENT|insufficient authentication scopes/i.test(txt)) {
      await clearCachedGoogleAuth();
      await getAccessToken(true);
      return await run();
    }
    throw e;
  }
}

function covers(siteUrl, pageUrl){
  try{
    if(siteUrl.startsWith("sc-domain:")){
      const domain = siteUrl.split(":")[1];
      const u = new URL(pageUrl);
      return u.hostname === domain || u.hostname.endsWith("."+domain);
    }
    return pageUrl.startsWith(siteUrl);
  }catch{ return false; }
}

// ---------- API wrappers ----------
async function listSites(){
  const token = await getToken();
  const res = await apiFetch(token, "https://www.googleapis.com/webmasters/v3/sites");
  const data = await res.json();
  return data?.siteEntry || [];
}
async function inspect(siteUrl, pageUrl){
  const token = await getToken();
  const payload = { inspectionUrl: pageUrl, siteUrl };
  const res = await apiFetch(token, "https://searchconsole.googleapis.com/v1/urlInspection/index:inspect", {
    method:"POST", body: JSON.stringify(payload)
  });
  return await res.json();
}

// ===== GA4 =====

// List GA4 properties across all accounts (displayName + numeric id)
async function gaListProperties(){
  return withScopeRetry(async () => {
    const token = await getToken();
    const accRes = await apiFetch(token, "https://analyticsadmin.googleapis.com/v1beta/accounts");
    const accJson = await accRes.json();
    const accounts = accJson.accounts || [];
    const list = [];
    for (const a of accounts){
      const u = new URL("https://analyticsadmin.googleapis.com/v1beta/properties");
      u.searchParams.set("filter", "parent:" + a.name);
      u.searchParams.set("pageSize", "200");
      const pRes = await apiFetch(token, u.toString());
      const pJson = await pRes.json();
      for (const p of (pJson.properties || [])){
        const id = (p.name||"").split("/")[1];
        list.push({ id, displayName: p.displayName, account: a.displayName });
      }
    }
    list.sort((x,y)=> (x.account+x.displayName).localeCompare(y.account+y.displayName));
    return list;
  });
}

async function gaListKeyEvents(propertyId){
  return withScopeRetry(async () => {
    const token = await getToken();
    const items = [];
    let pageToken = "";

    do {
      const url = new URL(`https://analyticsadmin.googleapis.com/v1alpha/properties/${propertyId}/keyEvents`);
      url.searchParams.set("pageSize", "200");
      if (pageToken) url.searchParams.set("pageToken", pageToken);

      const res = await apiFetch(token, url.toString());
      const data = await res.json();
      items.push(...(data.keyEvents || []));
      pageToken = data.nextPageToken || "";
    } while (pageToken);

    return items
      .map(item => ({
        eventName: item.eventName || (item.name || "").split("/").pop() || "",
        custom: !!item.custom,
        countingMethod: item.countingMethod || "",
        createTime: item.createTime || ""
      }))
      .filter(item => item.eventName)
      .sort((a, b) => a.eventName.localeCompare(b.eventName));
  });
}

// Sync Active Tab to GA Proprty
// --- GA4 detection helpers ---

// List web data streams for a property
async function gaListWebStreams(propertyId){
  const token = await getToken();
  const url = `https://analyticsadmin.googleapis.com/v1beta/properties/${propertyId}/webDataStreams`;
  const res = await apiFetch(token, url);
  return await res.json();
}

// Inject into the active tab and collect GA4 Measurement IDs (G-XXXX…)
// Inject into ALL frames and collect GA4 Measurement IDs (G-XXXX…)
async function sniffGaMeasurementIdsFromTab(tabId, tries = 3, delayMs = 1200){
  const collectOnce = async () => {
    const results = await chrome.scripting.executeScript({
      target: { tabId, allFrames: true },
      world: "MAIN",
      func: () => {
        const ids = new Set();
        const gtms = new Set();
        const push = v => {
          if (typeof v === 'string' && /^(G|GT|AW|FL|GA|DC)-[A-Z0-9]{4,}$/i.test(v.trim())) {
            ids.add(v.trim());
          }
        };

        // 0) If gtag is present now, read known IDs from the queue/state
        try{
          // queued calls: gtag('config','G-XXXX')
          const dl = (window && window.dataLayer) || [];
          if (Array.isArray(dl)) {
            dl.forEach(ev=>{
              if (!ev || typeof ev !== 'object') return;
              // common shapes
              if (ev.measurement_id) push(ev.measurement_id);
              if (ev.send_to){
                if (Array.isArray(ev.send_to)) ev.send_to.forEach(push);
                else push(ev.send_to);
              }
              if (ev.config){
                if (Array.isArray(ev.config)) ev.config.forEach(push);
                else if (typeof ev.config === 'string') push(ev.config);
              }
            });
          }
        }catch(_){}

        // 1) Inline script contents
        document.querySelectorAll('script').forEach(s=>{
          try{
            const t = s.textContent || '';
            (t.match(/\b(?:G|GT|AW|FL|GA|DC)-[A-Z0-9]{4,}\b/gi) || []).forEach(push);
            const src = s.src || s.getAttribute('src') || '';
            const srcLower = String(src).toLowerCase();
            const isGoogleTagScript =
              srcLower.includes('googletagmanager.com/gtag/js') ||
              srcLower.includes('googletagmanager.com/gtm.js') ||
              srcLower.includes('google.com/gtag/js') ||
              srcLower.includes('google.com/gtm.js') ||
              t.includes('google_tags_first_party');
            if (src && isGoogleTagScript) {
              try {
                const idParam = new URL(src, location.href).searchParams.get('id');
                if (idParam) {
                  if (/^(G|GT|AW|FL|GA|DC)-[A-Z0-9]{4,}$/i.test(idParam)) push(idParam);
                  else if (/^GTM-[A-Z0-9]{4,}$/i.test(idParam)) gtms.add(idParam);
                }
              } catch (_) {}
            }
          }catch(_){}
        });

        // First-party server-side tagging snippets
        document.querySelectorAll('script').forEach(s => {
          try {
            const text = s.textContent || '';
            if (!text.includes('google_tags_first_party')) return;
            const single = text.match(/window,'([^&]+)','google_tags_first_party'/);
            if (single && single[1]) push(single[1]);
            const multi = text.match(/window,\[(.*?)\],'google_tags_first_party'/);
            if (multi && multi[1]) {
              (multi[1].match(/'([^']+)'/g) || [])
                .map(match => match.replace(/'/g, ''))
                .forEach(push);
            }
          } catch (_) {}
        });

        // 2) Meta / data attributes
        document.querySelectorAll('[data-measurement-id],meta[content^="G-"],meta[content^="GT-"],meta[content^="AW-"],meta[content^="FL-"],meta[content^="GA-"],meta[content^="DC-"]').forEach(el=>{
          const v = el.getAttribute('data-measurement-id') || el.getAttribute('content') || '';
          push(v);
        });

        // 3) Noscript GTM iframe
        document.querySelectorAll('iframe[src*="googletagmanager.com/ns.html?id="]').forEach(f=>{
          const src = f.getAttribute('src') || '';
          try {
            const idParam = new URL(src, location.href).searchParams.get('id');
            if (/^GTM-[A-Z0-9]{4,}$/i.test(idParam || '')) gtms.add(idParam);
          } catch (_) {}
        });

        return { ids: Array.from(ids), gtms: Array.from(gtms) };
      }
    });

    const set = new Set();
    (results || []).forEach(r => (r?.result?.ids || []).forEach(v => set.add(v)));
    return set;
  };

  let set = await collectOnce();
  while (set.size === 0 && tries-- > 0){
    await new Promise(r => setTimeout(r, delayMs));
    (await collectOnce()).forEach(v => set.add(v));
  }
  return set;
}

// Main: detect property for the active tab
async function gaDetectPropertyFromActiveTab(){
  const [tab] = await chrome.tabs.query({ active:true, currentWindow:true });
  if (!tab || !/^https?:/i.test(tab.url)) throw new Error("No http(s) active tab.");
  const tabHost = new URL(tab.url).host.toLowerCase();

  const gIds = await sniffGaMeasurementIdsFromTab(tab.id, 2, 1200);

  const props = (await gaListPropertiesCached()).data;
  let hostFallback = null;

  for (const p of props){
    const ws = (await gaListWebStreamsCached(p.id)).data;
    for (const stream of (ws.webDataStreams || [])){
      const mId = stream.measurementId;
      const streamName = stream.name || '';
      const streamId = streamName.split('/').pop();
      const uri = (stream.defaultUri || '').toLowerCase();
      const uriHost = (()=>{ try{ return new URL(uri).host.toLowerCase(); }catch{ return ''; } })();

      if (mId && gIds.has(mId)){
        return {
          propertyId: p.id, propertyName: p.displayName,
          measurementId: mId, streamId, defaultUri: uri,
          tabUrl: tab.url, via: "measurementId"
        };
      }

      if (!hostFallback && uriHost && uriHost === tabHost){
        hostFallback = {
          propertyId: p.id, propertyName: p.displayName,
          measurementId: mId || null, streamId, defaultUri: uri,
          tabUrl: tab.url, via: "hostMatch"
        };
      }
    }
  }

  return hostFallback || {
    propertyId: null, propertyName: null, measurementId: null,
    tabUrl: tab.url, via: "none", foundGIds: Array.from(gIds)
  };
}

// End Sync Active tab to GA Property

// Run a simple GA4 report
async function gaRunReport(propertyId, startDate, endDate, dimension, dimensions, metrics, inListFilter, rowLimit, orderByMetric){
  return withScopeRetry(async () => {
    const token = await getToken();
    const url = `https://analyticsdata.googleapis.com/v1beta/properties/${propertyId}:runReport`;
    const metricNames = Array.isArray(metrics) && metrics.length ? metrics : [
      "activeUsers",
      "sessions",
      "screenPageViews",
      "eventCount"
    ];
    const dimensionNames = Array.isArray(dimensions) && dimensions.length ? dimensions : [dimension || "date"];
    const body = {
      dateRanges: [{ startDate, endDate }],
      dimensions: dimensionNames.map(name => ({ name })),
      metrics: metricNames.map(name => ({ name }))
    };
    if (inListFilter?.fieldName && Array.isArray(inListFilter.values) && inListFilter.values.length){
      body.dimensionFilter = {
        filter: {
          fieldName: inListFilter.fieldName,
          inListFilter: {
            values: inListFilter.values,
            caseSensitive: false
          }
        }
      };
    }
    if (Number.isFinite(Number(rowLimit)) && Number(rowLimit) > 0){
      body.limit = String(Math.floor(Number(rowLimit)));
    }
    if (orderByMetric){
      body.orderBys = [{
        metric: { metricName: orderByMetric },
        desc: true
      }];
    }
    const res = await apiFetch(token, url, { method: "POST", body: JSON.stringify(body) });
    return await res.json();
  });
}
// GA4 Ends

async function searchAnalytics(siteUrl, pageUrl, startDate, endDate, pageOnly = true, dimensions = null, rowLimit = null, aggregationType = null){
  const token = await getToken();
  const body = { startDate, endDate, searchType: "web", dataState: "all" };
  const hasDimensions = Array.isArray(dimensions) && dimensions.length > 0;

  if (hasDimensions){
    body.dimensions = dimensions;
  }

  if (pageOnly && pageUrl){
    body.dimensionFilterGroups = [{
      filters: [{ dimension: "page", operator: "equals", expression: pageUrl }]
    }];
  }

  if (aggregationType) {
    body.aggregationType = aggregationType;
  } else if (!pageOnly && !hasDimensions) {
    body.aggregationType = "byProperty";
  }

  if (Number.isFinite(Number(rowLimit)) && Number(rowLimit) > 0){
    body.rowLimit = Math.floor(Number(rowLimit));
  } else if (!hasDimensions){
    body.rowLimit = 1;
  }

  const url = "https://www.googleapis.com/webmasters/v3/sites/" + encodeURIComponent(siteUrl) + "/searchAnalytics/query";
  const res = await apiFetch(token, url, { method:"POST", body: JSON.stringify(body) });
  const data = await res.json();

  if (!hasDimensions && (!data.rows || data.rows.length === 0)) {
    const byDateBody = { ...body, dimensions: ["date"], rowLimit: 1000 };
    const res2 = await apiFetch(token, url, { method:"POST", body: JSON.stringify(byDateBody) });
    const d2 = await res2.json();
    if (Array.isArray(d2.rows) && d2.rows.length) {
      const sums = d2.rows.reduce((acc, r) => {
        acc.clicks += r.clicks || 0;
        acc.impressions += r.impressions || 0;
        acc.positionSum += (typeof r.position === "number" ? r.position : 0);
        return acc;
      }, { clicks:0, impressions:0, positionSum:0 });
      const n = d2.rows.length;
      const ctr = sums.impressions ? (sums.clicks / sums.impressions) : 0;
      const position = n ? (sums.positionSum / n) : 0;
      data.rows = [{ clicks: sums.clicks, impressions: sums.impressions, ctr, position }];
    }
  }
  return data;
}

async function probe(url){
  try{
    const r = await fetch(url, { method:"GET", redirect:"follow" });
    return { status: r.status, finalUrl: r.url || url };
  }catch(e){
    return { error: String(e) };
  }
}

// ---------- CallRail ----------
async function callrailFetch(path, params = {}){
  const apiKey = await getFromStore('callrailApiKey');
  if (!apiKey) throw new Error('CallRail API key is not set. Open the CallRail tab and save a key.');

  const url = new URL(`https://api.callrail.com/v3${path}`);
  for (const [k,v] of Object.entries(params || {})){
    if (v === undefined || v === null || v === '') continue;
    url.searchParams.set(k, String(v));
  }

  const res = await fetch(url.toString(), {
    method: 'GET',
    headers: {
      'Authorization': `Token token=${apiKey}`,
      'Accept': 'application/json'
    }
  });

  const txt = await res.text();
  let data = null;
  try { data = txt ? JSON.parse(txt) : null; } catch { data = txt; }

  if (!res.ok){
    const msg = (data && (data.message || data.error)) ? (data.message || data.error) : (typeof data === 'string' ? data : `HTTP ${res.status}`);
    if (res.status === 401) throw new Error('CallRail: Unauthorized. Check your API key.');
    if (res.status === 429) throw new Error('CallRail: Rate limited. Try again in a bit.');
    throw new Error(`CallRail: ${msg}`);
  }
  return data;
}

async function callrailListAccounts(){
  const data = await callrailFetch('/a.json', { fields: 'numeric_id' });
  return { accounts: data?.accounts || [] };
}

async function callrailListCompanies(accountId){
  const data = await callrailFetch(`/a/${accountId}/companies.json`);
  return { companies: data?.companies || [] };
}

async function callrailCallSummary({ accountId, companyId, start_date, end_date, group_by, device, lead_status, first_time_callers, min_duration, max_duration, companyName, groupByLabel }){
  const baseParams = {
    group_by,
    fields: 'total_calls,missed_calls,answered_calls,first_time_callers,average_duration,formatted_average_duration',
    start_date,
    end_date,
    company_id: companyId,
    device: device && device !== 'all' ? device : '',
    lead_status,
    first_time_callers,
    min_duration,
    max_duration,
    answer_status: 'all'
  };

  const base = await callrailFetch(`/a/${accountId}/calls/summary.json`, baseParams);

  const vmParams = {
    ...baseParams,
    fields: 'total_calls',
    answer_status: 'voicemail'
  };
  const vm = await callrailFetch(`/a/${accountId}/calls/summary.json`, vmParams);

  const vmMap = new Map();
  (vm?.grouped_results || []).forEach(r => vmMap.set(String(r.key), Number(r.total_calls || 0)));

  const rows = (base?.grouped_results || []).map(r => {
    const total = Number(r.total_calls || 0);
    const first = Number(r.first_time_callers || 0);
    const voicemails = vmMap.get(String(r.key)) || 0;
    return {
      key: r.key,
      total_calls: total,
      answered_calls: Number(r.answered_calls || 0),
      missed_calls: Number(r.missed_calls || 0),
      voicemails,
      first_time_callers: first,
      returning_callers: Math.max(0, total - first),
      average_duration: r.average_duration,
      formatted_average_duration: r.formatted_average_duration
    };
  }).sort((a,b) => (b.total_calls||0) - (a.total_calls||0));

  return {
    meta: {
      start: start_date,
      end: end_date,
      groupBy: group_by,
      groupByLabel: groupByLabel || group_by,
      companyId: companyId || '',
      companyName: companyName || '',
      total_results: base?.total_results || null
    },
    rows
  };
}

// ---------- Google Ads ----------
async function adsApiFetch(path, { method = "GET", body = null, loginCustomerId = null } = {}) {
  const token = await getToken();
  const headers = {
    "Authorization":   `Bearer ${token.access_token}`,
    "developer-token": CFG.GOOGLE_ADS_DEVELOPER_TOKEN,
    "Content-Type":    "application/json"
  };
  const mccId = loginCustomerId || CFG.GOOGLE_ADS_MCC_ID;
  if (mccId) headers["login-customer-id"] = String(mccId).replace(/-/g, "");

  const url = `https://googleads.googleapis.com/${CFG.GOOGLE_ADS_API_VERSION}${path}`;
  const opts = { method, headers };
  if (body) opts.body = typeof body === "string" ? body : JSON.stringify(body);

  let res = await fetch(url, opts);

  if (res.status === 401) {
    await clearCachedGoogleAuth();
    const fresh = await getAccessToken(true);
    headers["Authorization"] = `Bearer ${fresh}`;
    res = await fetch(url, { method, headers, body: opts.body });
  }

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    const msg = err?.error?.details?.[0]?.errors?.[0]?.message
              || err?.error?.message
              || (res.status === 404 ? `Google Ads API endpoint not found for ${CFG.GOOGLE_ADS_API_VERSION}. Update GOOGLE_ADS_API_VERSION in config.js.` : "")
              || `Google Ads API error ${res.status}`;
    throw new Error(msg);
  }
  return res.json();
}

async function adsGaqlSearch(customerId, query, loginCustomerId = null) {
  const cleanId = String(customerId).replace(/-/g, "");
  return adsApiFetch(`/customers/${cleanId}/googleAds:search`, {
    method: "POST",
    body: { query: query.replace(/\s+/g, " ").trim() },
    loginCustomerId
  });
}

async function adsGaqlResults(customerId, query, loginCustomerId = null) {
  const data = await adsGaqlSearch(customerId, query, loginCustomerId);
  return data?.results || [];
}

async function adsListAccessibleCustomers() {
  return withScopeRetry(async () => {
    const data = await adsApiFetch("/customers:listAccessibleCustomers");
    const ids = (data.resourceNames || [])
      .map(r => String(r || "").replace("customers/", ""))
      .filter(Boolean);
    const accountsById = new Map(ids.map(id => [id, {
      id,
      name: `Account ${id}`,
      currency: "USD",
      timezone: "",
      isManager: false,
      isTest: false,
      hasDetails: false
    }]));
    const infos = await Promise.allSettled(ids.map(async id => {
      const res = await adsGaqlSearch(id,
        `SELECT customer.id, customer.descriptive_name, customer.currency_code,
                customer.time_zone, customer.manager, customer.test_account
         FROM customer LIMIT 1`
      );
      const row = res?.results?.[0]?.customer;
      if (!row) return null;
      return {
        id:           String(row.id),
        name:         row.descriptiveName || `Account ${row.id}`,
        currency:     row.currencyCode || "USD",
        timezone:     row.timeZone || "",
        isManager:    !!row.manager,
        isTest:       !!row.testAccount,
        hasDetails:   true
      };
    }));
    infos.forEach(r => {
      if (r.status === "fulfilled" && r.value?.id) accountsById.set(String(r.value.id), r.value);
    });
    return Array.from(accountsById.values())
      .sort((a, b) => a.name.localeCompare(b.name));
  });
}

async function adsAccountOverview(customerId, dateRange) {
  return adsGaqlResults(customerId, `
    SELECT
      customer.id, customer.descriptive_name, customer.currency_code,
      metrics.impressions, metrics.clicks, metrics.cost_micros,
      metrics.conversions, metrics.all_conversions,
      metrics.ctr, metrics.average_cpc,
      metrics.conversion_rate, metrics.cost_per_conversion
    FROM customer
    WHERE segments.date DURING ${dateRange}
  `);
}

async function adsCampaigns(customerId, dateRange, statusFilter) {
  const statusClause = statusFilter && statusFilter !== "ALL"
    ? `AND campaign.status = '${statusFilter}'`
    : "AND campaign.status != 'REMOVED'";
  return adsGaqlResults(customerId, `
    SELECT
      campaign.id, campaign.name, campaign.status,
      campaign.advertising_channel_type, campaign.bidding_strategy_type,
      metrics.impressions, metrics.clicks, metrics.cost_micros,
      metrics.conversions, metrics.all_conversions,
      metrics.ctr, metrics.average_cpc,
      metrics.conversion_rate, metrics.cost_per_conversion
    FROM campaign
    WHERE segments.date DURING ${dateRange}
      ${statusClause}
    ORDER BY metrics.cost_micros DESC
    LIMIT 100
  `);
}

async function adsAdGroups(customerId, campaignId, dateRange, statusFilter) {
  const campClause = campaignId ? `AND campaign.id = '${campaignId}'` : "";
  const statusClause = statusFilter && statusFilter !== "ALL"
    ? `AND ad_group.status = '${statusFilter}'`
    : "AND ad_group.status != 'REMOVED'";
  return adsGaqlResults(customerId, `
    SELECT
      ad_group.id, ad_group.name, ad_group.status,
      campaign.id, campaign.name,
      metrics.impressions, metrics.clicks, metrics.cost_micros,
      metrics.conversions, metrics.ctr, metrics.average_cpc
    FROM ad_group
    WHERE segments.date DURING ${dateRange}
      ${campClause}
      ${statusClause}
    ORDER BY metrics.cost_micros DESC
    LIMIT 200
  `);
}

async function adsAds(customerId, campaignId, adGroupId, dateRange, statusFilter) {
  const campClause = campaignId  ? `AND campaign.id = '${campaignId}'`   : "";
  const agClause   = adGroupId   ? `AND ad_group.id = '${adGroupId}'`    : "";
  const statusClause = statusFilter && statusFilter !== "ALL"
    ? `AND ad_group_ad.status = '${statusFilter}'`
    : "AND ad_group_ad.status != 'REMOVED'";
  return adsGaqlResults(customerId, `
    SELECT
      ad_group_ad.ad.id,
      ad_group_ad.ad.type,
      ad_group_ad.ad.responsive_search_ad.headlines,
      ad_group_ad.ad.expanded_text_ad.headline_part1,
      ad_group_ad.ad.final_urls,
      ad_group_ad.status,
      campaign.name, ad_group.name,
      metrics.impressions, metrics.clicks, metrics.cost_micros,
      metrics.conversions, metrics.ctr, metrics.average_cpc
    FROM ad_group_ad
    WHERE segments.date DURING ${dateRange}
      ${campClause}
      ${agClause}
      ${statusClause}
    ORDER BY metrics.impressions DESC
    LIMIT 200
  `);
}

async function adsKeywords(customerId, campaignId, adGroupId, dateRange, statusFilter) {
  const campClause = campaignId ? `AND campaign.id = '${campaignId}'` : "";
  const agClause   = adGroupId  ? `AND ad_group.id = '${adGroupId}'` : "";
  const statusClause = statusFilter && statusFilter !== "ALL"
    ? `AND ad_group_criterion.status = '${statusFilter}'`
    : "AND ad_group_criterion.status != 'REMOVED'";
  return adsGaqlResults(customerId, `
    SELECT
      ad_group_criterion.keyword.text,
      ad_group_criterion.keyword.match_type,
      ad_group_criterion.quality_info.quality_score,
      ad_group_criterion.status,
      campaign.name, ad_group.name,
      metrics.impressions, metrics.clicks, metrics.cost_micros,
      metrics.conversions, metrics.ctr, metrics.average_cpc
    FROM keyword_view
    WHERE segments.date DURING ${dateRange}
      AND campaign.status != 'REMOVED'
      AND ad_group.status != 'REMOVED'
      ${campClause}
      ${agClause}
      ${statusClause}
    ORDER BY metrics.clicks DESC
    LIMIT 200
  `);
}

async function adsListConversionActions(customerId) {
  return adsGaqlResults(customerId, `
    SELECT
      conversion_action.id,
      conversion_action.name,
      conversion_action.category,
      conversion_action.type,
      conversion_action.status,
      conversion_action.counting_type
    FROM conversion_action
    WHERE conversion_action.status != 'REMOVED'
    ORDER BY conversion_action.name ASC
    LIMIT 200
  `);
}

async function adsConversionsReport(customerId, conversionActionIds, dateRange) {
  const idFilter = conversionActionIds?.length
    ? `AND conversion_action.id IN (${conversionActionIds.join(",")})`
    : "";
  return adsGaqlResults(customerId, `
    SELECT
      conversion_action.id,
      conversion_action.name,
      conversion_action.category,
      metrics.conversions,
      metrics.all_conversions,
      metrics.conversions_value,
      metrics.cost_per_conversion,
      metrics.conversion_rate
    FROM customer
    WHERE segments.date DURING ${dateRange}
      ${idFilter}
  `);
}

async function listSitesCached({ forceRefresh=false } = {}){
  const scope = await ensureGoogleCacheScope();
  return await cachedResource({
    service: "gsc-sites",
    scope,
    kind: CACHE_KIND_LIST,
    policy: CACHE_POLICY_MANUAL,
    params: { route: "listSites" },
    forceRefresh,
    fetcher: () => listSites()
  });
}

async function gaListPropertiesCached({ forceRefresh=false } = {}){
  const scope = await ensureGoogleCacheScope();
  const response = await cachedResource({
    service: "ga-properties",
    scope,
    kind: CACHE_KIND_LIST,
    policy: CACHE_POLICY_MANUAL,
    params: { route: "gaListProperties" },
    forceRefresh,
    fetcher: () => gaListProperties()
  });
  if (forceRefresh && response.cache?.source === "network"){
    await clearCacheNamespaces(namespace => namespace.includes(":service:ga-streams:"));
  }
  return response;
}

async function gaListWebStreamsCached(propertyId, { forceRefresh=false } = {}){
  const scope = await ensureGoogleCacheScope();
  return await cachedResource({
    service: "ga-streams",
    scope,
    kind: CACHE_KIND_LIST,
    policy: CACHE_POLICY_MANUAL,
    params: { propertyId },
    forceRefresh,
    fetcher: () => gaListWebStreams(propertyId)
  });
}

async function gaListKeyEventsCached(propertyId, { forceRefresh=false } = {}){
  const scope = await ensureGoogleCacheScope();
  return await cachedResource({
    service: "ga-key-events",
    scope,
    kind: CACHE_KIND_LIST,
    policy: CACHE_POLICY_MANUAL,
    params: { propertyId },
    forceRefresh,
    fetcher: () => gaListKeyEvents(propertyId)
  });
}

async function gaRunReportCached(payload, { forceRefresh=false } = {}){
  const scope = await ensureGoogleCacheScope();
  const params = {
    propertyId: payload.propertyId || "",
    startDate: payload.startDate || "",
    endDate: payload.endDate || "",
    dimension: payload.dimension || "",
    dimensions: Array.isArray(payload.dimensions) ? payload.dimensions : [],
    metrics: Array.isArray(payload.metrics) ? payload.metrics : [],
    inListFilter: payload.inListFilter || null,
    rowLimit: Number.isFinite(Number(payload.rowLimit)) ? Number(payload.rowLimit) : null,
    orderByMetric: payload.orderByMetric || ""
  };
  return await cachedResource({
    service: "ga-report",
    scope,
    kind: CACHE_KIND_REPORT,
    policy: CACHE_POLICY_TTL_1H,
    params,
    forceRefresh,
    fetcher: () => gaRunReport(
      payload.propertyId,
      payload.startDate,
      payload.endDate,
      payload.dimension,
      payload.dimensions,
      payload.metrics,
      payload.inListFilter,
      payload.rowLimit,
      payload.orderByMetric
    )
  });
}

async function searchAnalyticsCached(payload, { forceRefresh=false } = {}){
  const scope = await ensureGoogleCacheScope();
  const params = {
    siteUrl: payload.siteUrl || "",
    url: payload.url || null,
    startDate: payload.startDate || "",
    endDate: payload.endDate || "",
    pageOnly: !!payload.pageOnly,
    dimensions: Array.isArray(payload.dimensions) ? payload.dimensions.join(",") : "",
    rowLimit: Number.isFinite(Number(payload.rowLimit)) ? Math.floor(Number(payload.rowLimit)) : "",
    aggregationType: payload.aggregationType || ""
  };
  return await cachedResource({
    service: "gsc-perf",
    scope,
    kind: CACHE_KIND_REPORT,
    policy: CACHE_POLICY_TTL_1H,
    params,
    forceRefresh,
    fetcher: () => searchAnalytics(
      payload.siteUrl,
      payload.url,
      payload.startDate,
      payload.endDate,
      !!payload.pageOnly,
      payload.dimensions,
      payload.rowLimit,
      payload.aggregationType
    )
  });
}

async function callrailListAccountsCached({ forceRefresh=false } = {}){
  const scope = await ensureCallrailCacheScope();
  return await cachedResource({
    service: "callrail-accounts",
    scope,
    kind: CACHE_KIND_LIST,
    policy: CACHE_POLICY_MANUAL,
    params: { route: "callrailListAccounts" },
    forceRefresh,
    fetcher: () => callrailListAccounts()
  });
}

async function callrailListCompaniesCached(accountId, { forceRefresh=false } = {}){
  const scope = await ensureCallrailCacheScope();
  return await cachedResource({
    service: "callrail-companies",
    scope,
    kind: CACHE_KIND_LIST,
    policy: CACHE_POLICY_MANUAL,
    params: { accountId: String(accountId || "") },
    forceRefresh,
    fetcher: () => callrailListCompanies(accountId)
  });
}

async function callrailCallSummaryCached(payload, { forceRefresh=false } = {}){
  const scope = await ensureCallrailCacheScope();
  const params = {
    accountId: String(payload.accountId || ""),
    companyId: String(payload.companyId || ""),
    start_date: payload.start_date || "",
    end_date: payload.end_date || "",
    group_by: payload.group_by || "",
    device: payload.device || "",
    lead_status: payload.lead_status || "",
    first_time_callers: payload.first_time_callers ?? "",
    min_duration: payload.min_duration ?? "",
    max_duration: payload.max_duration ?? ""
  };
  return await cachedResource({
    service: "callrail-summary",
    scope,
    kind: CACHE_KIND_REPORT,
    policy: CACHE_POLICY_TTL_1H,
    params,
    forceRefresh,
    fetcher: () => callrailCallSummary(payload)
  });
}

const ADS_CACHE_TTL_1H  = CACHE_POLICY_TTL_1H;
const ADS_CACHE_MANUAL  = CACHE_POLICY_MANUAL;

async function adsListCustomersCached({ forceRefresh = false } = {}) {
  const scope = await ensureAdsCacheScope();
  return cachedResource({
    service: "ads-customers", scope, kind: CACHE_KIND_LIST, policy: ADS_CACHE_MANUAL,
    params: { route: "listAccessibleCustomers", fallbackAccounts: true }, forceRefresh,
    fetcher: () => adsListAccessibleCustomers()
  });
}

async function adsAccountOverviewCached(customerId, dateRange, { forceRefresh = false } = {}) {
  const scope = await ensureAdsCacheScope();
  return cachedResource({
    service: "ads-overview", scope, kind: CACHE_KIND_REPORT, policy: ADS_CACHE_TTL_1H,
    params: { customerId, dateRange }, forceRefresh,
    fetcher: () => adsAccountOverview(customerId, dateRange)
  });
}

async function adsCampaignsCached(customerId, dateRange, statusFilter, { forceRefresh = false } = {}) {
  const scope = await ensureAdsCacheScope();
  return cachedResource({
    service: "ads-campaigns", scope, kind: CACHE_KIND_REPORT, policy: ADS_CACHE_TTL_1H,
    params: { customerId, dateRange, statusFilter }, forceRefresh,
    fetcher: () => adsCampaigns(customerId, dateRange, statusFilter)
  });
}

async function adsAdGroupsCached(customerId, campaignId, dateRange, statusFilter, { forceRefresh = false } = {}) {
  const scope = await ensureAdsCacheScope();
  return cachedResource({
    service: "ads-adgroups", scope, kind: CACHE_KIND_REPORT, policy: ADS_CACHE_TTL_1H,
    params: { customerId, campaignId, dateRange, statusFilter }, forceRefresh,
    fetcher: () => adsAdGroups(customerId, campaignId, dateRange, statusFilter)
  });
}

async function adsAdsCached(customerId, campaignId, adGroupId, dateRange, statusFilter, { forceRefresh = false } = {}) {
  const scope = await ensureAdsCacheScope();
  return cachedResource({
    service: "ads-ads", scope, kind: CACHE_KIND_REPORT, policy: ADS_CACHE_TTL_1H,
    params: { customerId, campaignId, adGroupId, dateRange, statusFilter }, forceRefresh,
    fetcher: () => adsAds(customerId, campaignId, adGroupId, dateRange, statusFilter)
  });
}

async function adsKeywordsCached(customerId, campaignId, adGroupId, dateRange, statusFilter, { forceRefresh = false } = {}) {
  const scope = await ensureAdsCacheScope();
  return cachedResource({
    service: "ads-keywords", scope, kind: CACHE_KIND_REPORT, policy: ADS_CACHE_TTL_1H,
    params: { customerId, campaignId, adGroupId, dateRange, statusFilter }, forceRefresh,
    fetcher: () => adsKeywords(customerId, campaignId, adGroupId, dateRange, statusFilter)
  });
}

async function adsConversionActionsCached(customerId, { forceRefresh = false } = {}) {
  const scope = await ensureAdsCacheScope();
  return cachedResource({
    service: "ads-conv-actions", scope, kind: CACHE_KIND_LIST, policy: ADS_CACHE_MANUAL,
    params: { customerId }, forceRefresh,
    fetcher: () => adsListConversionActions(customerId)
  });
}

async function adsConversionsReportCached(customerId, conversionActionIds, dateRange, { forceRefresh = false } = {}) {
  const scope = await ensureAdsCacheScope();
  return cachedResource({
    service: "ads-conversions", scope, kind: CACHE_KIND_REPORT, policy: ADS_CACHE_TTL_1H,
    params: { customerId, ids: (conversionActionIds || []).join(","), dateRange }, forceRefresh,
    fetcher: () => adsConversionsReport(customerId, conversionActionIds, dateRange)
  });
}

// ---------- message router ----------
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    try{
      if (msg.type === "ping") return sendResponse({ ok:true, data:"pong" });

      if(msg.type === "listSites"){
        const result = await listSitesCached({ forceRefresh: !!msg.forceRefresh });
        return sendResponse({ ok:true, data:result.data, cache: result.cache });
      }
      if(msg.type === "inspect"){
        const { siteUrl, url } = msg;
        if(!covers(siteUrl, url)) return sendResponse({ ok:false, error:"Selected property does not cover this URL." });
        const d = await inspect(siteUrl, url); return sendResponse({ ok:true, data:d });
      }
      if(msg.type === "perf"){
        const { siteUrl, url, startDate, endDate, pageOnly, dimensions, rowLimit, aggregationType } = msg;
        if(pageOnly && (!url || !covers(siteUrl, url))) return sendResponse({ ok:false, error:"Performance: selected property must cover the page URL." });
        const result = await searchAnalyticsCached({
          siteUrl,
          url,
          startDate,
          endDate,
          pageOnly: !!pageOnly,
          dimensions,
          rowLimit,
          aggregationType
        }, { forceRefresh: !!msg.forceRefresh });
        return sendResponse({ ok:true, data:result.data, cache: result.cache });
      }
      if(msg.type === "probe"){
        const d = await probe(msg.url); return sendResponse({ ok:true, data:d });
      }
      if(msg.type === "logout"){
        await clearCachedGoogleAuth();
        await clearGoogleCaches();
        return sendResponse({ ok:true });
      }
      if(msg.type === "getAccount"){
        let profile = await getFromStore("accountProfile");
        if (!profile?.email) {
          profile = await fetchGoogleAccountProfile(false).catch(() => null);
        }
        if (!profile?.email) {
          try {
            profile = await fetchGoogleAccountProfile(true);
          } catch (_) {
            profile = null;
          }
        }
        return sendResponse({ ok:true, data: profile?.email ? buildPseudoIdToken({ email: profile.email }) : null });
      }
      if (msg.type === "gaDetectFromTab"){
        const data = await gaDetectPropertyFromActiveTab();
        return sendResponse({ ok:true, data });
      }
      if (msg.type === "gaListProperties"){
        const result = await gaListPropertiesCached({ forceRefresh: !!msg.forceRefresh });
        return sendResponse({ ok:true, data: result.data, cache: result.cache });
      }
      if (msg.type === "gaListKeyEvents"){
        const { propertyId } = msg;
        const result = await gaListKeyEventsCached(propertyId, { forceRefresh: !!msg.forceRefresh });
        return sendResponse({ ok:true, data: result.data, cache: result.cache });
      }
      if (msg.type === "gaReport"){
        const { propertyId, startDate, endDate, dimension, dimensions, metrics, inListFilter, rowLimit, orderByMetric } = msg;
        const result = await gaRunReportCached({ propertyId, startDate, endDate, dimension, dimensions, metrics, inListFilter, rowLimit, orderByMetric }, { forceRefresh: !!msg.forceRefresh });
        return sendResponse({ ok:true, data: result.data, cache: result.cache });
      }

      // CallRail
      if (msg.type === 'callrailListAccounts'){
        const result = await callrailListAccountsCached({ forceRefresh: !!msg.forceRefresh });
        return sendResponse({ ok:true, data: result.data, cache: result.cache });
      }
      if (msg.type === 'callrailListCompanies'){
        const result = await callrailListCompaniesCached(msg.accountId, { forceRefresh: !!msg.forceRefresh });
        return sendResponse({ ok:true, data: result.data, cache: result.cache });
      }
      if (msg.type === 'callrailCallSummary'){
        const result = await callrailCallSummaryCached(msg, { forceRefresh: !!msg.forceRefresh });
        return sendResponse({ ok:true, data: result.data, cache: result.cache });
      }
      if (msg.type === "callrailInvalidateCache"){
        await clearCallrailCaches();
        return sendResponse({ ok:true });
      }

      // Google Ads
      if (msg.type === "adsListCustomers") {
        const result = await adsListCustomersCached({ forceRefresh: !!msg.forceRefresh });
        return sendResponse({ ok: true, data: result.data, cache: result.cache });
      }
      if (msg.type === "adsAccountOverview") {
        const { customerId, dateRange } = msg;
        const result = await adsAccountOverviewCached(customerId, dateRange, { forceRefresh: !!msg.forceRefresh });
        return sendResponse({ ok: true, data: result.data, cache: result.cache });
      }
      if (msg.type === "adsCampaigns") {
        const { customerId, dateRange, statusFilter } = msg;
        const result = await adsCampaignsCached(customerId, dateRange, statusFilter, { forceRefresh: !!msg.forceRefresh });
        return sendResponse({ ok: true, data: result.data, cache: result.cache });
      }
      if (msg.type === "adsAdGroups") {
        const { customerId, campaignId, dateRange, statusFilter } = msg;
        const result = await adsAdGroupsCached(customerId, campaignId, dateRange, statusFilter, { forceRefresh: !!msg.forceRefresh });
        return sendResponse({ ok: true, data: result.data, cache: result.cache });
      }
      if (msg.type === "adsAds") {
        const { customerId, campaignId, adGroupId, dateRange, statusFilter } = msg;
        const result = await adsAdsCached(customerId, campaignId, adGroupId, dateRange, statusFilter, { forceRefresh: !!msg.forceRefresh });
        return sendResponse({ ok: true, data: result.data, cache: result.cache });
      }
      if (msg.type === "adsKeywords") {
        const { customerId, campaignId, adGroupId, dateRange, statusFilter } = msg;
        const result = await adsKeywordsCached(customerId, campaignId, adGroupId, dateRange, statusFilter, { forceRefresh: !!msg.forceRefresh });
        return sendResponse({ ok: true, data: result.data, cache: result.cache });
      }
      if (msg.type === "adsConversionActions") {
        const { customerId } = msg;
        const result = await adsConversionActionsCached(customerId, { forceRefresh: !!msg.forceRefresh });
        return sendResponse({ ok: true, data: result.data, cache: result.cache });
      }
      if (msg.type === "adsConversionsReport") {
        const { customerId, conversionActionIds, dateRange } = msg;
        const result = await adsConversionsReportCached(customerId, conversionActionIds, dateRange, { forceRefresh: !!msg.forceRefresh });
        return sendResponse({ ok: true, data: result.data, cache: result.cache });
      }
      if (msg.type === "adsClearCache") {
        await clearAdsCaches();
        return sendResponse({ ok: true });
      }

      return sendResponse({ ok:false, error:"Unknown message" });
    }catch(e){
      console.error("[SCC] router error", e);
      sendResponse({ ok:false, error: String(e) });
    }
  })();
  return true;
});

console.log("[SCC] Service worker started");
