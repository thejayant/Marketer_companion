// config.js — fill in your OAuth details
export const CLIENT_ID = "1099294114553-snrorkmr7gge9fn2jvd09e0i6etdov1s.apps.googleusercontent.com";
// Leave blank when using a proper Chrome extension OAuth client.
// Do not rely on shipping a web-client secret inside the extension package.
// The Google OAuth client must allow chrome.identity.getRedirectURL()
// for the installed extension ID, or sign-in will fail with redirect_uri_mismatch.
export const CLIENT_SECRET = ""; // e.g. "GOCSPX-xxxxx_your_secret_xxxxx"

export const SCOPES = [
  "openid",
  "email", 
  "https://www.googleapis.com/auth/webmasters.readonly",
  'https://www.googleapis.com/auth/webmasters',          // needed for URL Inspection & sites.list
  "https://www.googleapis.com/auth/analytics.readonly"
].join(" ");

// ─── Google Ads ────────────────────────────────────────────────────────────
export const GOOGLE_ADS_DEVELOPER_TOKEN = "WdOCTVSR83y2VTBoDOhMcg";
export const GOOGLE_ADS_API_VERSION     = "v24";
// If you manage clients through an MCC, set your top-level MCC customer ID here (digits only, no dashes).
// Leave empty string if the authenticated user connects their own account directly.
export const GOOGLE_ADS_MCC_ID = "";
